export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  
  
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      ai_models: {
        Row: {
          created_at: string
          display_name: string
          display_order: number
          id: string
          is_active: boolean
          model_name: string
          provider: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_name: string
          display_order: number
          id?: string
          is_active?: boolean
          model_name: string
          provider: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_name?: string
          display_order?: number
          id?: string
          is_active?: boolean
          model_name?: string
          provider?: string
          updated_at?: string
        }
        Relationships: []
      }
      anthropic_service_status: {
        Row: {
          id: string
          last_checked_at: string
          status: string
          updated_at: string
        }
        Insert: {
          id?: string
          last_checked_at?: string
          status: string
          updated_at?: string
        }
        Update: {
          id?: string
          last_checked_at?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      calendar_events: {
        Row: {
          created_at: string
          description: string | null
          end_time: string
          google_event_id: string
          id: string
          is_all_day: boolean
          start_time: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          end_time: string
          google_event_id: string
          id?: string
          is_all_day?: boolean
          start_time: string
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          end_time?: string
          google_event_id?: string
          id?: string
          is_all_day?: boolean
          start_time?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      context_files: {
        Row: {
          anthropic_file_id: string | null
          created_at: string
          description: string | null
          description_compressed: boolean | null
          file_type: string
          filename: string
          google_file_id: string | null
          google_file_type: string | null
          google_file_url: string | null
          id: string
          journal_entry_id: string | null
          status: string
          storage_path: string
          title: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          anthropic_file_id?: string | null
          created_at?: string
          description?: string | null
          description_compressed?: boolean | null
          file_type: string
          filename: string
          google_file_id?: string | null
          google_file_type?: string | null
          google_file_url?: string | null
          id?: string
          journal_entry_id?: string | null
          status: string
          storage_path: string
          title?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          anthropic_file_id?: string | null
          created_at?: string
          description?: string | null
          description_compressed?: boolean | null
          file_type?: string
          filename?: string
          google_file_id?: string | null
          google_file_type?: string | null
          google_file_url?: string | null
          id?: string
          journal_entry_id?: string | null
          status?: string
          storage_path?: string
          title?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "context_files_journal_entry_id_fkey"
            columns: ["journal_entry_id"]
            isOneToOne: false
            referencedRelation: "journal"
            referencedColumns: ["id"]
          },
        ]
      }
      file_editing_sessions: {
        Row: {
          conversation_turn_id: string
          created_at: string
          ended_at: string | null
          google_file_id: string
          id: string
          started_at: string
          task_description: string
          updated_at: string
          user_id: string
        }
        Insert: {
          conversation_turn_id: string
          created_at?: string
          ended_at?: string | null
          google_file_id: string
          id?: string
          started_at?: string
          task_description: string
          updated_at?: string
          user_id: string
        }
        Update: {
          conversation_turn_id?: string
          created_at?: string
          ended_at?: string | null
          google_file_id?: string
          id?: string
          started_at?: string
          task_description?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      journal: {
        Row: {
          boss_message: string
          boss_message_id: string | null
          created_at: string
          id: string
          is_complete: boolean
          is_compressed: boolean
          persona_message_id: string | null
          persona_name: string | null
          persona_response: string | null
          superjournal_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          boss_message: string
          boss_message_id?: string | null
          created_at?: string
          id?: string
          is_complete?: boolean
          is_compressed?: boolean
          persona_message_id?: string | null
          persona_name?: string | null
          persona_response?: string | null
          superjournal_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          boss_message?: string
          boss_message_id?: string | null
          created_at?: string
          id?: string
          is_complete?: boolean
          is_compressed?: boolean
          persona_message_id?: string | null
          persona_name?: string | null
          persona_response?: string | null
          superjournal_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "journal_superjournal_id_fkey"
            columns: ["superjournal_id"]
            isOneToOne: true
            referencedRelation: "superjournal"
            referencedColumns: ["id"]
          },
        ]
      }
      personas: {
        Row: {
          created_at: string
          display_order: number
          id: string
          is_active: boolean
          name: string
          role: string
          storage_filename: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_order: number
          id?: string
          is_active?: boolean
          name: string
          role: string
          storage_filename: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_order?: number
          id?: string
          is_active?: boolean
          name?: string
          role?: string
          storage_filename?: string
          updated_at?: string
        }
        Relationships: []
      }
      received_google_files: {
        Row: {
          context_file_id: string | null
          file_type: string
          google_file_id: string
          google_file_name: string
          id: string
          received_at: string
          user_id: string
        }
        Insert: {
          context_file_id?: string | null
          file_type: string
          google_file_id: string
          google_file_name: string
          id?: string
          received_at?: string
          user_id: string
        }
        Update: {
          context_file_id?: string | null
          file_type?: string
          google_file_id?: string
          google_file_name?: string
          id?: string
          received_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "received_google_files_context_file_id_fkey"
            columns: ["context_file_id"]
            isOneToOne: false
            referencedRelation: "context_files"
            referencedColumns: ["id"]
          },
        ]
      }
      superjournal: {
        Row: {
          boss_message: string
          boss_message_id: string | null
          created_at: string
          id: string
          is_complete: boolean
          persona_message_id: string | null
          persona_name: string | null
          persona_response: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          boss_message: string
          boss_message_id?: string | null
          created_at?: string
          id?: string
          is_complete?: boolean
          persona_message_id?: string | null
          persona_name?: string | null
          persona_response?: string | null
          updated_at?: string
          user_id?: string
        }
        Update: {
          boss_message?: string
          boss_message_id?: string | null
          created_at?: string
          id?: string
          is_complete?: boolean
          persona_message_id?: string | null
          persona_name?: string | null
          persona_response?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      system_messages: {
        Row: {
          created_at: string
          dismissed_at: string | null
          id: string
          link: string | null
          message: string
          user_id: string
        }
        Insert: {
          created_at?: string
          dismissed_at?: string | null
          id?: string
          link?: string | null
          message: string
          user_id: string
        }
        Update: {
          created_at?: string
          dismissed_at?: string | null
          id?: string
          link?: string | null
          message?: string
          user_id?: string
        }
        Relationships: []
      }
      user_settings: {
        Row: {
          created_at: string
          id: string
          selected_model: string
          selected_persona: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          selected_model?: string
          selected_persona?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          selected_model?: string
          selected_persona?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
