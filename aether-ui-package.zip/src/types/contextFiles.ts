export interface ContextFile {
  content?: string;
  filename: string;
  type: string;
  file_id?: string;
}

export interface ContextFilesState {
  files: ContextFile[];
  isLoading: boolean;
  error: string | null;
}

export interface StorageFileMetadata {
  name: string;
  size: number;
  updated_at: string;
  metadata?: Record<string, unknown>;
}

export interface ContextFileRetrievalResult {
  success: boolean;
  files?: ContextFile[];
  error?: string;
}

export type FileStatus = 'processing' | 'active' | 'inactive' | 'deleted' | 'failed';

export interface ContextFileRecord {
  id: string;
  user_id: string;
  filename: string;
  file_type: 'image' | 'pdf' | 'text' | 'code' | 'spreadsheet' | 'other';
  status: FileStatus;
  storage_path: string;
  description: string | null;
  journal_entry_id: string | null;
  title: string | null;
  anthropic_file_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface ActiveFile {
  id: string;
  filename: string;
  title: string | null;
  type: 'image' | 'pdf' | 'text' | 'code' | 'spreadsheet' | 'other';
  status: 'processing' | 'active' | 'failed';
}

export interface InactiveFile {
  id: string;
  filename: string;
  timestamp: string;
}

export type PendingFileSource = 'physical' | 'google';

export type PendingFileStatus = 'uploading' | 'ready';

export interface PendingPhysicalFile {
  localId: string;
  pnrCode?: string;
  filename: string;
  file: File;
  source: 'physical';
  status: PendingFileStatus;
  anthropic_file_id?: string;
  dbId?: string;
}

export interface PendingGoogleFile {
  localId: string;
  displayName: string;
  url: string;
  type: 'docs' | 'sheets' | 'slides';
  documentId: string;
  source: 'google';
  status: PendingFileStatus;
  anthropic_file_id?: string;
  dbId?: string;
}

export type PendingFile = PendingPhysicalFile | PendingGoogleFile;

export interface DisplayFile {
  id: string;
  displayName: string;
  status: 'uploading' | 'ready' | 'processing' | 'active' | 'failed';
  source: 'local' | 'database';
  type?: 'image' | 'pdf' | 'text' | 'code' | 'spreadsheet' | 'other';
  anthropic_file_id?: string;
}