
export interface TodoList {
  id: string;
  user_id: string;
  name: string;
  is_protected: boolean;
  is_collapsed: boolean;
  position: number;
  created_at: string;
}

export interface Todo {
  id: string;
  user_id: string;
  list_id: string | null;
  calendar_date: string | null; 
  text: string;
  date_text: string | null;
  completed: boolean;
  starred: boolean;
  position: number;
  completed_at: string | null; 
  created_at: string;
  updated_at: string;
}

export interface CreateTodoParams {
  user_id: string;
  list_id?: string | null;
  calendar_date?: string | null; 
  text: string;
  date_text?: string | null;
  starred?: boolean;
  position: number;
}

export interface UpdateTodoParams {
  text?: string;
  date_text?: string | null;
  completed?: boolean;
  starred?: boolean;
  position?: number;
  list_id?: string | null;
  calendar_date?: string | null;
  completed_at?: string | null;
}

export interface MoveTodoParams {
  toListId?: string | null;
  toCalendarDate?: string | null;
  position?: number;
}

export interface GetTodosFilters {
  listId?: string;
  calendarDate?: string; 
  includeCompleted?: boolean;
}

export interface CreateTodoListParams {
  user_id: string;
  name: string;
  position: number;
  is_protected?: boolean;
}

export interface UpdateTodoListParams {
  name?: string;
  is_collapsed?: boolean;
}
