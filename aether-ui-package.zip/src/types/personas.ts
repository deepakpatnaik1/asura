export interface PersonaInfo {
  id: string;
  name: string;
  role: string;
  storage_filename: string;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export type PersonaName = string;

export interface PersonaRow {
  id: string;
  name: string;
  role: string;
  storage_filename: string;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}