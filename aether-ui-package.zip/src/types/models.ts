export interface ModelInfo {
  id: string;
  model_name: string;
  display_name: string;
  provider: string;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface ModelRow {
  id: string;
  model_name: string;
  display_name: string;
  provider: string;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}
