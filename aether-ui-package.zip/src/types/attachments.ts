export interface FileAttachment {
  type: 'file';
  file: File;
  id: string;
}

export type Attachment = FileAttachment;
