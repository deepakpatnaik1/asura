export interface SystemMessageType {
  id: string;
  user_id: string;
  message: string;
  link: string | null;
  created_at: string;
  dismissed_at: string | null;
}

export interface SystemMessagesState {
  messages: SystemMessageType[];
  isLoading: boolean;
  error: string | null;
}
