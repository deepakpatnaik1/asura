import React, { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { useTurnMode } from '@/hooks/useTurnMode';
import { API_CONFIG } from '@/config/constants';
import { AppError, createError, getErrorMessage, ERROR_MESSAGES } from '@/utils/errorHandling';
import { validateMessage } from '@/utils/validation';
import { LLMServiceFactory, type ILLMService, type LLMRequest } from '@/services/llm';
import { aggregateAttachmentsToBundle, type ProcessedAttachment } from '@/utils/attachmentAggregation';
import { findMessagesInTurn, constructRethinkPrompt } from '@/utils/rethinkHelpers';
import { detectMimeType, validateFile, generateFileErrorMessage, getFileTypeFromMimeType, type FileTypeValidationResult } from '@/utils/fileTypeManager';
import { getLocalTimestampWithOffset, getTimezoneOffset } from '@/utils/timestampUtils';
import { generatePNRFromFile } from '@/utils/pnrGenerator';
import MessageList from './MessageList';
import InputArea from './InputArea';
import ErrorDisplay from './ErrorDisplay';
import ActiveContextBar from './ActiveContextBar';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { LogOut, Trash2 } from 'lucide-react';
import { Attachment, FileAttachment } from '@/types/attachments';
import { uploadMultipleFiles, triggerModifiedCall2 } from '@/services/fileUpload';
import { useContextFiles } from '@/hooks/useContextFiles';
import { createContextFileRecord, updateFileDescription, updateFileStatus, deleteContextFile, updateAnthropicFileId, findExistingJournalEntry } from '@/services/contextFilesDB';
import { useActiveFiles } from '@/hooks/useActiveFiles';
import { useInactiveFiles } from '@/hooks/useInactiveFiles';
import type { PendingPhysicalFile, PendingGoogleFile } from '@/types/contextFiles';
import { convertGoogleDocToPdf } from '@/services/googleFileService';
import { markGoogleFileAsReceived, unmarkGoogleFileAsReceived } from '@/services/receivedGoogleFilesDB';
import { useSettings } from '@/hooks/useSettings';
import { fetchSystemMessages, subscribeToSystemMessages, deleteSystemMessage } from '@/services/systemMessageService';
import type { SystemMessageType } from '@/types/systemMessages';
import { countTokensForMessage } from '@/services/tokenCountingService';
import { getContextWindowLimit } from '@/config/modelConfig';
import { togglePinMessage } from '@/services/pinMessageService';
import { replaceEmDashes } from '@/utils/textTransforms';

interface Message {
  id: string;
  text: string;
  sender: string;
  dbId?: string;
  timestamp?: string;
  isPinned?: boolean;
}

const ChatInterface: React.FC = () => {
  const { toast } = useToast();
  const { user, session, signOut } = useAuth();
  const { selectedModel, updateModel, selectedPersona } = useSettings();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [shouldAutoScroll, setShouldAutoScroll] = useState(false);
  const [animatingButtons, setAnimatingButtons] = useState<{
    copy: string | null;
  }>({ copy: null });
  const [currentError, setCurrentError] = useState<AppError | null>(null);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [systemMessages, setSystemMessages] = useState<SystemMessageType[]>([]);
  const [tokenPercentage, setTokenPercentage] = useState<number | null>(null);
  const [isGlobalMiniChatOpen, setIsGlobalMiniChatOpen] = useState(false);
  const [globalMiniChatMessages, setGlobalMiniChatMessages] = useState<Array<{sender: 'Boss' | 'Gunnar', text: string}>>([]);
  const [globalMiniChatInput, setGlobalMiniChatInput] = useState('');
  const [isGlobalMiniChatLoading, setIsGlobalMiniChatLoading] = useState(false);

  
  const call2TriggeredIds = React.useRef<Set<string>>(new Set());

  const turnModeState = useTurnMode(messages);
  const { contextFilesForLLM, refreshContextFiles, mergePendingReadyFiles } = useContextFiles();
  const {
    displayFiles,
    refreshActiveFiles,
    addPendingFile,
    removePendingFile,
    updatePendingStatus,
    updatePendingToReady
  } = useActiveFiles();
  const { refreshInactiveFiles } = useInactiveFiles();

                                                          
  const displayFilesRef = useRef(displayFiles);

  useEffect(() => {
    displayFilesRef.current = displayFiles;
  }, [displayFiles]);

  useEffect(() => {
    mergePendingReadyFiles(displayFiles);
  }, [displayFiles, mergePendingReadyFiles]);

  useEffect(() => {
    loadHistoricalMessages();
  }, []);

  useEffect(() => {
    const loadSystemMessages = async () => {
      if (!user?.id) return;

      try {
        const result = await fetchSystemMessages(user.id);
        if (result.success && result.messages) {
          setSystemMessages(result.messages);
        }
      } catch (error) {
        console.error('Failed to load system messages:', error);
      }
    };

    loadSystemMessages();
  }, [user?.id]);

  useEffect(() => {
    if (!user?.id) return;

    const channel = subscribeToSystemMessages(user.id, (newMessage) => {
      setSystemMessages(prev => [...prev, newMessage]);
    });

    return () => {
      channel.unsubscribe();
    };
  }, [user?.id]);

  const loadHistoricalMessages = async () => {
    try {
      const { data: journalEntries, error } = await supabase
        .from('superjournal')
        .select('id, user_id, boss_message, persona_response, persona_name, boss_message_id, persona_message_id, created_at, is_pinned')
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Database error:', error);
        setCurrentError(createError('database', 'Failed to load chat history', error.message));
        return;
      }

      const loadedMessages: Message[] = [];
      journalEntries?.forEach((entry) => {
        const bossTimestamp: string = entry.created_at;
        
        const personaTimestamp: string = new Date(new Date(entry.created_at).getTime() + 1).toISOString();

        if (entry.boss_message) {
          loadedMessages.push({
            id: entry.boss_message_id || `boss-${entry.id}`,
            text: replaceEmDashes(entry.boss_message),
            sender: 'Boss',
            dbId: entry.id,
            timestamp: bossTimestamp,
            isPinned: entry.is_pinned || false
          });
        }

        if (entry.persona_response) {
          loadedMessages.push({
            id: entry.persona_message_id || `persona-${entry.id}`,
            text: replaceEmDashes(entry.persona_response),
            sender: entry.persona_name || 'Gunnar',
            dbId: entry.id,
            timestamp: personaTimestamp,
            isPinned: entry.is_pinned || false
          });
        }
      });

      setMessages(loadedMessages);
    } catch (error) {
      console.error('Error loading historical messages:', error);
      setCurrentError(createError('database', 'Failed to load chat history', getErrorMessage(error)));
    }
  };

  const saveMessageToDatabase = async (
    bossMessage: string,
    personaResponse: string = '',
    personaName: string = 'Gunnar',
    bossMessageId: string,
    personaMessageId: string | null = null
  ) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        throw new Error('User not authenticated');
      }

      const { data, error } = await supabase
        .from('superjournal')
        .insert({
          user_id: user.id,
          boss_message: bossMessage,
          persona_response: personaResponse || null,
          persona_name: personaName,
          boss_message_id: bossMessageId,
          persona_message_id: personaMessageId,
          is_complete: true
        })
        .select()
        .single();

      if (error) throw error;

      if (data && data.id) {
        
        setTimeout(() => {
          triggerCall2Compression(data.id, selectedModel).catch(err => {
            console.warn('Call 2 compression failed (non-blocking):', err);
          });
        }, 2000);
      }
    } catch (error) {
      console.error('Error saving message to database:', error.message);
      setCurrentError(createError('database', 'Failed to save message', getErrorMessage(error)));
    }
  };

  const triggerCall2Compression = async (superjournalId: string, model: string) => {
    try {
      
      if (call2TriggeredIds.current.has(superjournalId)) {
        console.error('🚨 DUPLICATE CALL 2 DETECTED:', superjournalId);
        console.error('This superjournal ID has already triggered Call 2 compression!');
        console.trace('Stack trace for duplicate Call 2:');
        return; 
      }

      
      call2TriggeredIds.current.add(superjournalId);

      console.log('Triggering Call 2 compression for:', superjournalId, 'with model:', model);

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No session for Call 2 trigger');
      }

      const response = await supabase.functions.invoke('call2-compression', {
        body: { superjournalId, model },
        headers: {
          Authorization: `Bearer ${session.access_token}`,
        }
      });

      if (response.error) {
        throw response.error;
      }

      console.log('Call 2 compression triggered successfully');
    } catch (error) {
      console.error('Failed to trigger Call 2 compression:', error);
      throw error;
    }
  };

  const updateMessageInDatabase = async (
    aiMessageId: string,
    newPersonaResponse: string,
    personaName: string
  ) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        throw new Error('User not authenticated');
      }

      const { data: superjournalData, error: superjournalError } = await supabase
        .from('superjournal')
        .update({
          persona_response: newPersonaResponse,
          updated_at: new Date().toISOString()
        })
        .eq('persona_message_id', aiMessageId)
        .select()
        .single();

      if (superjournalError) {
        throw superjournalError;
      }

      if (!superjournalData) {
        throw new Error('Superjournal entry not found');
      }

      console.log('Updated superjournal entry:', superjournalData.id);

      if (superjournalData.id) {
        triggerCall2Compression(superjournalData.id, selectedModel).catch(err => {
          console.warn('Call 2 compression failed (non-blocking):', err);
        });
      }
    } catch (error) {
      console.error('Error updating message in database:', error);
      setCurrentError(createError('database', 'Failed to update message', getErrorMessage(error)));
    }
  };

  const updateBossRethinkInDatabase = async (
    bossMessageId: string,
    aiMessageId: string,
    newBossMessage: string,
    newPersonaResponse: string,
    personaName: string
  ) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        throw new Error('User not authenticated');
      }

      const { data: superjournalData, error: superjournalError } = await supabase
        .from('superjournal')
        .update({
          boss_message: newBossMessage,
          persona_response: newPersonaResponse,
          persona_name: personaName,
          updated_at: new Date().toISOString()
        })
        .eq('boss_message_id', bossMessageId)
        .select()
        .single();

      if (superjournalError) {
        throw superjournalError;
      }

      if (!superjournalData) {
        throw new Error('Superjournal entry not found');
      }

      console.log('Updated superjournal entry (Boss rethink):', superjournalData.id);

      if (superjournalData.id) {
        triggerCall2Compression(superjournalData.id, selectedModel).catch(err => {
          console.warn('Call 2 compression failed (non-blocking):', err);
        });
      }
    } catch (error) {
      console.error('Error updating Boss rethink in database:', error);
      setCurrentError(createError('database', 'Failed to update message', getErrorMessage(error)));
    }
  };

  const uploadFileToAnthropic = async (
    file: File
  ): Promise<{ success: boolean; file_id?: string; error?: string }> => {
    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const authToken = (await supabase.auth.getSession()).data.session?.access_token;

      if (!authToken) {
        throw new Error('No authentication token available');
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 60000);

      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch(`${supabaseUrl}/functions/v1/upload-to-anthropic`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authToken}`,
        },
        body: formData,
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Upload endpoint error:', response.status, errorText);
        return { success: false, error: `HTTP ${response.status}` };
      }

      const result = await response.json();
      return result;

    } catch (error) {
      console.error('Upload request failed:', error);

      if (error instanceof Error && error.name === 'AbortError') {
        return {
          success: false,
          error: 'Upload timeout (file too large or slow network)'
        };
      }

      return {
        success: false,
        error: error instanceof Error ? error.message : 'Network error'
      };
    }
  };

  const handleSendMessage = async () => {
    console.log('📤 handleSendMessage called at:', new Date().toISOString());
    if ((!inputValue.trim() && attachments.length === 0) || isLoading) return;

    
    setShouldAutoScroll(true);

    let currentPersona = 'Gunnar';
    if (user?.id) {
      const { data } = await supabase
        .from('user_settings')
        .select('selected_persona')
        .eq('user_id', user.id)
        .maybeSingle();

      if (data?.selected_persona) {
        currentPersona = data.selected_persona;
      }
    }

    try {
      if (inputValue.trim()) {
        validateMessage({ text: inputValue.trim() });
      }

      for (const attachment of attachments) {
        const fileAttachment = attachment as FileAttachment;
        validateFile({
          name: fileAttachment.file.name,
          size: fileAttachment.file.size,
          type: fileAttachment.file.type,
        });
      }
    } catch (error: unknown) {
      console.error('Validation error:', error instanceof Error ? error.message : "Invalid input provided");
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue.trim(),
      sender: 'Boss',
      timestamp: new Date().toISOString()
    };

    const messageText = userMessage.text;
    const currentAttachments = [...attachments];

    
    setIsLoading(true);
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setAttachments([]);

    const processedAttachments: ProcessedAttachment[] = [];

    

    for (const attachment of currentAttachments) {
      const fileAttachment = attachment as FileAttachment;
        try {
          const currentFile = fileAttachment.file;
          let fileContent = null;

          const MAX_FILE_SIZE = 32 * 1024 * 1024;
          if (currentFile.size > MAX_FILE_SIZE) {
            throw new Error(`File too large. Maximum size allowed: ${MAX_FILE_SIZE / 1024 / 1024}MB`);
          }

          const validationResult: FileTypeValidationResult = validateFile(currentFile);
          if (!validationResult.isValid) {
            console.error('File validation failed:', validationResult.error);
            return;
          }

          try {
            const uploadResult = await uploadFileToAnthropic(currentFile);

            if (uploadResult.success && uploadResult.file_id) {
              processedAttachments.push({
                file_id: uploadResult.file_id,
                filename: currentFile.name,
                type: currentFile.type
              });
              console.log(`File uploaded to Anthropic: ${currentFile.name} → ${uploadResult.file_id}`);
            } else {
              throw new Error(uploadResult.error || 'Upload failed');
            }
          } catch (uploadError) {
            console.error(`Upload failed for ${currentFile.name}:`, uploadError);
            throw uploadError;
          }
        } catch (error) {
          console.error('Error reading file:', error);
          const errorMessage = error instanceof Error && error.message.includes('Unsupported file format')
            ? generateFileErrorMessage(fileAttachment.file.name)
            : `Failed to read attached file: ${fileAttachment.file.name}`;
          setCurrentError(createError('unknown', errorMessage));
          setIsLoading(false);
          return;
        }
    }

                                                                         
                                                     
    if (processedAttachments.length > 0 && user) {
      processedAttachments.forEach(async (processedAttachment) => {
        try {
          const originalFile = currentAttachments.find(
            att => att.file.name === processedAttachment.filename
          )?.file;

          if (!originalFile) {
            console.error(`Could not find original file for ${processedAttachment.filename}`);
            return;
          }

          const fileType = getFileTypeFromMimeType(originalFile.type, originalFile.name);

                                                                                          
          const contextFileRecord = await createContextFileRecord(
            user.id,
            originalFile.name,
            fileType,
            '',                   
            originalFile.name,
            processedAttachment.file_id
          );

          console.log(`Created context_files record: ${contextFileRecord.id} for ${originalFile.name}`);
          refreshActiveFiles();

                                               
          const mimeType = detectMimeType(originalFile.name, originalFile.type);
          triggerModifiedCall2(
            user.id,
            contextFileRecord.id,
            originalFile.name,
            processedAttachment.file_id,
            mimeType,
            selectedModel,
            selectedPersona,
            contextFileRecord.journal_entry_id
          ).then((modifiedCall2Result) => {
            if (modifiedCall2Result.success) {
              console.log(`Modified-Call2 successful for ${originalFile.name}`);
              refreshActiveFiles();
            } else {
              console.error(`Modified-Call2 failed for ${originalFile.name}:`, modifiedCall2Result.error);
              refreshActiveFiles();
            }
          }).catch(error => {
            console.error(`Modified-Call2 exception for ${originalFile.name}:`, error);
            refreshActiveFiles();
          });

        } catch (error) {
          console.error('Error creating context file record:', error);
        }
      });
    }

    const aiMessageId = (Date.now() + 1).toString();

    setMessages(prev => [...prev, {
      id: aiMessageId,
      text: 'Thinking...',
      sender: currentPersona,
      timestamp: new Date().toISOString()
    }]);

                                                               
    const waitForPendingFiles = async () => {
      return new Promise<void>((resolve) => {
        const checkFiles = () => {
                                                         
          const currentDisplayFiles = displayFilesRef.current;
          const pendingFiles = currentDisplayFiles.filter(f =>
            f.status === 'uploading' || f.status === 'processing'
          );

          if (pendingFiles.length === 0) {
            console.log('✅ All files ready - proceeding with AI response');
            resolve();
          } else {
            console.log(`⏳ Waiting for ${pendingFiles.length} file(s) to finish processing...`);
            setTimeout(checkFiles, 500);
          }
        };
        checkFiles();
      });
    };

    await waitForPendingFiles();

    try {
      if (!session) {
        throw new Error('User not authenticated');
      }

      const service = LLMServiceFactory.create();
      const aggregatedAttachment = aggregateAttachmentsToBundle(
        contextFilesForLLM,
        processedAttachments
      );

      
      const timestamp = getLocalTimestampWithOffset();
      const timezoneOffset = getTimezoneOffset();
      const messageWithTimestamp = `[${timestamp}]\n${messageText}`;

      const request: LLMRequest = {
        message: messageWithTimestamp,
        model: selectedModel,
        attachment: aggregatedAttachment,
        authToken: session.access_token,
        apiKey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        personaName: currentPersona,
        timezoneOffset: timezoneOffset
      };

      let aiResponse = '';

      for await (const response of service.sendMessage(request)) {
        if (response.error) {
          throw new Error(response.error);
        }

        if (response.content) {
          aiResponse = response.content;

          setMessages(prev =>
            prev.map(msg =>
              msg.id === aiMessageId
                ? { ...msg, text: aiResponse }
                : msg
            )
          );
        }

        if (response.isComplete) {
          break;
        }
      }

      if (!aiResponse.trim()) {
        throw new Error('No content received from LLM service');
      }

      await saveMessageToDatabase(messageText, aiResponse, currentPersona, userMessage.id, aiMessageId);

      
      
      const contextWindowLimit = getContextWindowLimit(selectedModel);
      console.log('🔢 Starting token count...', {
        messageCount: messages.length + 2, 
        contextFilesCount: contextFilesForLLM.length,
        selectedModel,
        contextWindowLimit
      });

      const tokenResult = await countTokensForMessage(
        '', 
        [...messages, userMessage, { id: aiMessageId, text: aiResponse, sender: 'Gunnar' }], 
        contextFilesForLLM, 
        selectedModel,
        currentPersona,
        contextWindowLimit
      );

      if (tokenResult.success && tokenResult.percentage !== undefined) {
        setTokenPercentage(tokenResult.percentage);
        console.log(`✅ Token usage: ${tokenResult.tokenCount} tokens (${tokenResult.percentage}% of ${contextWindowLimit})`);
      } else {
        console.error('❌ Token counting failed:', tokenResult.error);
      }

    } catch (error) {
      console.error('Chat AI error:', error);

      const errorMessage = 'Error: Unable to process request.';

      setMessages(prev =>
        prev.map(msg =>
          msg.id === aiMessageId
            ? { ...msg, text: errorMessage }
            : msg
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleRethink = async (
    messageId: string,
    corrections: Array<{text: string; feedback: string}>
  ) => {
    if (isLoading) {
      console.log('Cannot rethink while another operation is in progress');
      return;
    }

    const turn = findMessagesInTurn(messageId, messages);

    if (!turn) {
      console.error('Could not find messages in turn');
      setCurrentError(createError('unknown', 'Failed to find message turn'));
      return;
    }

    const { bossMessage, aiMessage } = turn;

    const formattedCorrections = corrections.map(c => ({
      highlightedText: c.text,
      feedback: c.feedback
    }));

    const rethinkPrompt = constructRethinkPrompt(
      bossMessage.text,
      aiMessage.text,
      formattedCorrections
    );

    setIsLoading(true);

    setMessages(prev =>
      prev.map(msg =>
        msg.id === messageId
          ? { ...msg, text: 'Rethinking...' }
          : msg
      )
    );

    try {
      if (!session) {
        throw new Error('User not authenticated');
      }

      let currentPersona = 'Gunnar';
      if (user?.id) {
        const { data } = await supabase
          .from('user_settings')
          .select('selected_persona')
          .eq('user_id', user.id)
          .maybeSingle();

        if (data?.selected_persona) {
          currentPersona = data.selected_persona;
        }
      }

      const service = LLMServiceFactory.create();

      const aggregatedAttachment = aggregateAttachmentsToBundle(
        contextFilesForLLM,
        []
      );

      
      const timestamp = getLocalTimestampWithOffset();
      const timezoneOffset = getTimezoneOffset();
      const rethinkPromptWithTimestamp = `[${timestamp}]\n${rethinkPrompt}`;

      const request: LLMRequest = {
        message: rethinkPromptWithTimestamp,
        model: selectedModel,
        attachment: aggregatedAttachment,
        authToken: session.access_token,
        apiKey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        personaName: currentPersona,
        timezoneOffset: timezoneOffset
      };

      let newAiResponse = '';

      for await (const response of service.sendMessage(request)) {
        if (response.error) {
          throw new Error(response.error);
        }

        if (response.content) {
          newAiResponse = response.content;

          setMessages(prev =>
            prev.map(msg =>
              msg.id === messageId
                ? { ...msg, text: newAiResponse }
                : msg
            )
          );
        }

        if (response.isComplete) {
          break;
        }
      }

      if (!newAiResponse.trim()) {
        throw new Error('No content received from LLM service');
      }

      console.log('Rethink successful, new response generated');

      await updateMessageInDatabase(messageId, newAiResponse, currentPersona);

      
      const contextWindowLimit = getContextWindowLimit(selectedModel);
      const tokenResult = await countTokensForMessage(
        '', 
        messages, 
        contextFilesForLLM, 
        selectedModel,
        currentPersona,
        contextWindowLimit
      );

      if (tokenResult.success && tokenResult.percentage !== undefined) {
        setTokenPercentage(tokenResult.percentage);
        console.log(`✅ Token usage after AI rethink: ${tokenResult.tokenCount} tokens (${tokenResult.percentage}% of ${contextWindowLimit})`);
      } else {
        console.error('❌ Token counting failed after AI rethink:', tokenResult.error);
      }

    } catch (error) {
      console.error('Rethink error:', error);

      const errorMessage = 'Error: Unable to regenerate response.';
      setCurrentError(createError('unknown', 'Failed to regenerate response', getErrorMessage(error)));

      setMessages(prev =>
        prev.map(msg =>
          msg.id === messageId
            ? { ...msg, text: aiMessage.text }
            : msg
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleBossRethink = async (
    messageId: string,
    newQuery: string
  ) => {
    if (isLoading) {
      console.log('Cannot rethink while another operation is in progress');
      return;
    }

    const turn = findMessagesInTurn(messageId, messages);

    if (!turn) {
      console.error('Could not find messages in turn for Boss rethink');
      setCurrentError(createError('unknown', 'Failed to find message turn'));
      return;
    }

    const { bossMessage, aiMessage } = turn;

    const oldBossText = bossMessage.text;
    const oldAiText = aiMessage.text;

    console.log('Boss rethink initiated:', {
      bossMessageId: bossMessage.id,
      aiMessageId: aiMessage.id,
      oldQuery: oldBossText,
      newQuery
    });

    setIsLoading(true);

    setMessages(prev =>
      prev.map(msg =>
        msg.id === bossMessage.id
          ? { ...msg, text: newQuery }
          : msg
      )
    );

    setMessages(prev =>
      prev.map(msg =>
        msg.id === aiMessage.id
          ? { ...msg, text: 'Thinking...' }
          : msg
      )
    );

    try {
      if (!session) {
        throw new Error('User not authenticated');
      }

      let currentPersona = 'Gunnar';
      if (user?.id) {
        const { data } = await supabase
          .from('user_settings')
          .select('selected_persona')
          .eq('user_id', user.id)
          .maybeSingle();

        if (data?.selected_persona) {
          currentPersona = data.selected_persona;
        }
      }

      const service = LLMServiceFactory.create();

      const aggregatedAttachment = aggregateAttachmentsToBundle(
        contextFilesForLLM,
        []
      );

      
      const timestamp = getLocalTimestampWithOffset();
      const timezoneOffset = getTimezoneOffset();
      const newQueryWithTimestamp = `[${timestamp}]\n${newQuery}`;

      const request: LLMRequest = {
        message: newQueryWithTimestamp,
        model: selectedModel,
        attachment: aggregatedAttachment,
        authToken: session.access_token,
        apiKey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        personaName: currentPersona,
        timezoneOffset: timezoneOffset
      };

      let newAiResponse = '';

      for await (const response of service.sendMessage(request)) {
        if (response.error) {
          throw new Error(response.error);
        }

        if (response.content) {
          newAiResponse = response.content;

          setMessages(prev =>
            prev.map(msg =>
              msg.id === aiMessage.id
                ? { ...msg, text: newAiResponse }
                : msg
            )
          );
        }

        if (response.isComplete) {
          break;
        }
      }

      if (!newAiResponse.trim()) {
        throw new Error('No content received from LLM service');
      }

      console.log('Boss rethink successful, new AI response generated');

      await updateBossRethinkInDatabase(
        bossMessage.id,
        aiMessage.id,
        newQuery,
        newAiResponse,
        currentPersona
      );

      
      const contextWindowLimit = getContextWindowLimit(selectedModel);
      const tokenResult = await countTokensForMessage(
        '', 
        messages, 
        contextFilesForLLM, 
        selectedModel,
        currentPersona,
        contextWindowLimit
      );

      if (tokenResult.success && tokenResult.percentage !== undefined) {
        setTokenPercentage(tokenResult.percentage);
        console.log(`✅ Token usage after rethink: ${tokenResult.tokenCount} tokens (${tokenResult.percentage}% of ${contextWindowLimit})`);
      } else {
        console.error('❌ Token counting failed after rethink:', tokenResult.error);
      }

    } catch (error) {
      console.error('Boss rethink error:', error);

      const errorMessage = 'Error: Unable to regenerate response.';
      setCurrentError(createError('unknown', 'Failed to regenerate response', getErrorMessage(error)));

      setMessages(prev =>
        prev.map(msg => {
          if (msg.id === bossMessage.id) {
            return { ...msg, text: oldBossText };
          }
          if (msg.id === aiMessage.id) {
            return { ...msg, text: oldAiText };
          }
          return msg;
        })
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (messageId: string) => {
    const turn = findMessagesInTurn(messageId, messages);

    if (!turn) {
      console.error('Could not find messages in turn');
      return;
    }

    const { bossMessage, aiMessage } = turn;

    setMessages(prev =>
      prev.filter(msg => msg.id !== bossMessage.id && msg.id !== aiMessage.id)
    );

    try {
      const { error } = await supabase
        .from('superjournal')
        .delete()
        .eq('persona_message_id', aiMessage.id);

      if (error) {
        console.error('Failed to delete from database:', error);
      }
    } catch (error) {
      console.error('Delete error:', error);
    }
  };

  const handleTogglePin = async (messageId: string) => {
    console.log('🔖 Toggle pin requested for message:', messageId);

    
    const message = messages.find(m => m.id === messageId);

    if (!message) {
      console.error('Message not found:', messageId);
      toast({
        title: 'Error',
        description: 'Message not found',
        variant: 'destructive'
      });
      return;
    }

    if (!message.dbId) {
      console.error('Message has no dbId (not saved to database yet)');
      toast({
        title: 'Error',
        description: 'Cannot pin unsaved message',
        variant: 'destructive'
      });
      return;
    }

    
    const originalPinStatus = message.isPinned || false;
    const newPinStatus = !originalPinStatus;

    
    setMessages(prev =>
      prev.map(m => {
        
        if (m.dbId === message.dbId) {
          return { ...m, isPinned: newPinStatus };
        }
        return m;
      })
    );

    console.log(`🔖 Optimistic update: ${originalPinStatus ? 'UNPINNING' : 'PINNING'} message ${messageId}`);

    
    const result = await togglePinMessage(message.dbId);

    
    if (result.success) {
      
      console.log(`✅ Pin toggle confirmed: message ${messageId} is now ${result.isPinned ? 'PINNED' : 'UNPINNED'}`);
    } else {
      
      console.error('❌ Pin toggle failed:', result.error);

      setMessages(prev =>
        prev.map(m => {
          if (m.dbId === message.dbId) {
            return { ...m, isPinned: originalPinStatus }; 
          }
          return m;
        })
      );

      
      toast({
        title: 'Failed to toggle pin',
        description: result.error || 'Please try again',
        variant: 'destructive'
      });
    }
  };

  const handleMiniChat = async (
    messageId: string,
    question: string,
    onResponse: (content: string, isComplete: boolean) => void
  ) => {
    const turn = findMessagesInTurn(messageId, messages);
    if (!turn) {
      console.error('Could not find messages in turn for mini-chat');
      return;
    }

    const { bossMessage, aiMessage } = turn;

    const miniChatPrompt = `Boss's original message: ${bossMessage.text}

Your previous response: ${aiMessage.text}

Boss has a side question: ${question}

Answer this question strictly within 1 paragraph.`;

    try {
      if (!session) {
        throw new Error('User not authenticated');
      }

      let currentPersona = 'Gunnar';
      if (user?.id) {
        const { data } = await supabase
          .from('user_settings')
          .select('selected_persona')
          .eq('user_id', user.id)
          .maybeSingle();

        if (data?.selected_persona) {
          currentPersona = data.selected_persona;
        }
      }

      const service = LLMServiceFactory.create();

      const aggregatedAttachment = aggregateAttachmentsToBundle(
        contextFilesForLLM,
        []
      );

      
      const timestamp = getLocalTimestampWithOffset();
      const timezoneOffset = getTimezoneOffset();
      const miniChatPromptWithTimestamp = `[${timestamp}]\n${miniChatPrompt}`;

      const request: LLMRequest = {
        message: miniChatPromptWithTimestamp,
        model: selectedModel,
        attachment: aggregatedAttachment,
        authToken: session.access_token,
        apiKey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        personaName: currentPersona,
        timezoneOffset: timezoneOffset
      };

      let fullResponse = '';

      for await (const response of service.sendMessage(request)) {
        if (response.error) {
          throw new Error(response.error);
        }

        if (response.content) {
          fullResponse = response.content;
          onResponse(fullResponse, false);
        }

        if (response.isComplete) {
          onResponse(fullResponse, true);
          break;
        }
      }

    } catch (error) {
      console.error('Mini-chat error:', error);
      onResponse('Error: Unable to generate response.', true);
    }
  };

  const handleGlobalMiniChatOpen = () => {
    setIsGlobalMiniChatOpen(true);
  };

  const handleGlobalMiniChatClose = () => {
    setIsGlobalMiniChatOpen(false);
    setGlobalMiniChatMessages([]);
    setGlobalMiniChatInput('');
    setIsGlobalMiniChatLoading(false);
  };

  const handleGlobalMiniChatSend = async () => {
    if (!globalMiniChatInput.trim() || isGlobalMiniChatLoading) return;

    const question = globalMiniChatInput;

    
    const bossMessage = { sender: 'Boss' as const, text: question };
    setGlobalMiniChatMessages(prev => [...prev, bossMessage]);
    setGlobalMiniChatInput('');
    setIsGlobalMiniChatLoading(true);

    
    setGlobalMiniChatMessages(prev => [...prev, { sender: 'Gunnar' as const, text: '' }]);

    try {
      if (!session) {
        throw new Error('User not authenticated');
      }

      let currentPersona = 'Gunnar';
      if (user?.id) {
        const { data } = await supabase
          .from('user_settings')
          .select('selected_persona')
          .eq('user_id', user.id)
          .maybeSingle();

        if (data?.selected_persona) {
          currentPersona = data.selected_persona;
        }
      }

      const service = LLMServiceFactory.create();

      const aggregatedAttachment = aggregateAttachmentsToBundle(
        contextFilesForLLM,
        []
      );

      
      const timestamp = getLocalTimestampWithOffset();
      const timezoneOffset = getTimezoneOffset();
      const miniChatPromptWithTimestamp = `[${timestamp}]\n${question}\n\nAnswer this question strictly within 1 paragraph.`;

      const request: LLMRequest = {
        message: miniChatPromptWithTimestamp,
        model: selectedModel,
        attachment: aggregatedAttachment,
        authToken: session.access_token,
        apiKey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        personaName: currentPersona,
        timezoneOffset: timezoneOffset
      };

      let fullResponse = '';

      for await (const response of service.sendMessage(request)) {
        if (response.error) {
          throw new Error(response.error);
        }

        if (response.content) {
          fullResponse = response.content;
          setGlobalMiniChatMessages(prev => {
            const updated = [...prev];
            updated[updated.length - 1] = { sender: 'Gunnar' as const, text: fullResponse };
            return updated;
          });
        }

        if (response.isComplete) {
          setIsGlobalMiniChatLoading(false);
          break;
        }
      }

    } catch (error) {
      console.error('Global mini-chat error:', error);
      setGlobalMiniChatMessages(prev => {
        const updated = [...prev];
        updated[updated.length - 1] = { sender: 'Gunnar' as const, text: 'Error: Unable to generate response.' };
        return updated;
      });
      setIsGlobalMiniChatLoading(false);
    }
  };

  const handleDismissSystemMessage = async (messageId: string) => {
    console.log('🗑️ Dismissing system message:', messageId);

    
    setSystemMessages(prev => prev.filter(msg => msg.id !== messageId));

    
    const result = await deleteSystemMessage(messageId);
    console.log('🗑️ Delete result:', result);

    if (!result.success) {
      console.error('❌ Failed to delete system message:', result.error);
      
      if (user?.id) {
        const fetchResult = await fetchSystemMessages(user.id);
        if (fetchResult.success && fetchResult.messages) {
          setSystemMessages(fetchResult.messages);
        }
      }
    } else {
      console.log('✅ System message deleted successfully');
    }
  };

  const handleCopyMessage = async (text: string, messageId: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setAnimatingButtons(prev => ({ ...prev, copy: messageId }));
      setTimeout(() => setAnimatingButtons(prev => ({ ...prev, copy: null })), 800);
    } catch (error) {
      console.error('Failed to copy message:', error);
      setCurrentError(createError('clipboard', ERROR_MESSAGES.CLIPBOARD.COPY_FAILED, getErrorMessage(error)));
    }
  };

  const handleRetryLastMessage = () => {
    setCurrentError(null);
  };

  const handleDismissError = () => {
    setCurrentError(null);
  };

  const handleFileSelect = async (file: File) => {
    const validationResult = validateFile(file);

    if (!validationResult.isValid) {
      console.error('File validation failed:', validationResult.error);
      return;
    }

    if (!user) {
      console.error('Authentication error: User must be logged in to upload files');
      return;
    }



    const pnrCode = await generatePNRFromFile(file);
    const localId = `pending-${pnrCode}`;
    const pendingFile: PendingPhysicalFile = {
      localId,
      pnrCode,
      filename: file.name,
      file,
      source: 'physical',
      status: 'uploading'
    };

    addPendingFile(pendingFile);

    try {
      const anthropicUploadResult = await uploadFileToAnthropic(file);

      if (!anthropicUploadResult.success || !anthropicUploadResult.file_id) {
        console.error('Anthropic upload failed:', anthropicUploadResult.error || 'Failed to upload file');
        removePendingFile(localId);
        return;
      }

      console.log(`Anthropic upload successful: ${anthropicUploadResult.file_id}`);

      updatePendingToReady(localId, anthropicUploadResult.file_id);
      console.log(`✅ Flow 1 Complete: Physical file ready with file_id ${anthropicUploadResult.file_id}`);

      const fileType = getFileTypeFromMimeType(file.type, file.name);

                                                        
      const { data: existingFiles } = await supabase
        .from('context_files')
        .select('id, anthropic_file_id')
        .eq('user_id', user.id)
        .eq('filename', file.name)
        .eq('status', 'active')
        .limit(1);

      if (existingFiles && existingFiles.length > 0) {
                                                                              
        const existingFile = existingFiles[0];

                                              
        await supabase
          .from('context_files')
          .update({
            anthropic_file_id: anthropicUploadResult.file_id,
            status: 'processing',
            updated_at: new Date().toISOString()
          })
          .eq('id', existingFile.id);

                                                   
        const mimeType = detectMimeType(file.name, file.type);
        await triggerModifiedCall2(
          user.id,
          existingFile.id,
          file.name,
          anthropicUploadResult.file_id,
          mimeType,
          selectedModel,
          selectedPersona,
          null // No journal_entry_id yet
        );

        toast({
          title: "File Updated",
          description: `Updated existing file: ${file.name}`
        });

                                          
        removePendingFile(localId);
        await refreshActiveFiles();
        return; // Exit early - no new pending file needed
      }

                                                               
                                                        
      (async () => {
        try {
          const contextFileRecord = await createContextFileRecord(
            user.id,
            file.name,
            fileType,
            '',                   
            file.name,
            anthropicUploadResult.file_id
          );

          updatePendingStatus(localId, contextFileRecord.id);
          await refreshActiveFiles();
          console.log(`📊 Flow 2 Step 1: Database record created: ${contextFileRecord.id}`);

          const mimeType = detectMimeType(file.name, file.type);
          const result = await triggerModifiedCall2(
            user.id,
            contextFileRecord.id,
            contextFileRecord.filename,
            anthropicUploadResult.file_id,
            mimeType,
            selectedModel,
            selectedPersona,
            contextFileRecord.journal_entry_id
          );

          if (result.success) {
            console.log(`📊 Flow 2 Step 2: Modified-Call2 successful`);
            await refreshActiveFiles();
          } else {
            console.error(`Flow 2 Modified-Call2 failed:`, result.error);
            await refreshActiveFiles();
          }
        } catch (error) {
          console.error('Flow 2 background processing failed:', error);
        }
      })();

    } catch (error) {
      console.error('File upload error:', error);
      removePendingFile(localId);
    }
  };

  const handleRemoveAttachment = (id: string) => {
    setAttachments(prev => prev.filter(att => att.id !== id));
  };

  const handleGoogleUrlSubmit = async (url: string, type: 'docs' | 'sheets' | 'slides', documentId: string, fileName?: string) => {
    console.log('Google URL submitted:', { url, type, documentId });

    if (!user) {
      console.error('Authentication error: User must be logged in');
      return;
    }

    const localId = `pending-google-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    const typeDisplayName =
      type === 'docs' ? 'Google Docs' :
      type === 'sheets' ? 'Google Sheets' :
      'Google Slides';

    const displayName = fileName || typeDisplayName;

    const pendingFile: PendingGoogleFile = {
      localId,
      displayName: displayName,
      url,
      type,
      documentId,
      source: 'google',
      status: 'uploading'
    };

    addPendingFile(pendingFile);

    try {
      const pdfFilename = `${typeDisplayName}-${documentId}`;
      const pdfResult = await convertGoogleDocToPdf(documentId, type, pdfFilename);

      if (!pdfResult.success || !pdfResult.file_id) {
        throw new Error(pdfResult.error || 'Failed to convert and upload Google Doc');
      }

      console.log(`Google Doc converted and uploaded to Anthropic: ${pdfResult.file_id}`);

      updatePendingToReady(localId, pdfResult.file_id, displayName);
      console.log(`✅ Flow 1 Complete: Google file ready with file_id ${pdfResult.file_id}`);

                                                               
                                                        
      (async () => {
        try {
          const contextFileRecord = await createContextFileRecord(
            user.id,
            displayName,
            'pdf',
            '',                   
            displayName,
            pdfResult.file_id,
            documentId
          );

          updatePendingStatus(localId, contextFileRecord.id);
          await refreshActiveFiles();
          console.log(`📊 Flow 2 Step 1: Database record created: ${contextFileRecord.id}`);

          if (user?.id) {
            try {
              await markGoogleFileAsReceived(
                user.id,
                documentId,
                `${typeDisplayName}: ${pdfFilename}`,
                type,
                contextFileRecord.id
              );
              console.log(`📊 Flow 2 Step 2: Marked as received`);
            } catch (error) {
              console.error('Failed to mark file as received:', error);
            }
          }

          const existingJournalId = await findExistingJournalEntry(user.id, documentId);

          const result = await triggerModifiedCall2(
            user.id,
            contextFileRecord.id,
            `${pdfFilename}.pdf`,
            pdfResult.file_id,
            'application/pdf',
            selectedModel,
            selectedPersona,
            existingJournalId
          );

          if (result.success) {
            console.log(`📊 Flow 2 Step 3: Modified-Call2 successful`);
            await refreshActiveFiles();
          } else {
            console.error(`Flow 2 Modified-Call2 failed:`, result.error);
            await refreshActiveFiles();
          }
        } catch (error) {
          console.error('Flow 2 background processing failed:', error);
        }
      })();

    } catch (error) {
      console.error('Google URL processing error:', error);
      removePendingFile(localId);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  const handleNuke = async () => {
    try {
      console.log('🔥 NUKE: Starting nuclear deletion...');

                                                          
                                                                          
      console.log('🔥 NUKE: Unsubscribing from real-time channels...');
      supabase.removeAllChannels();

                                   
      console.log('🔥 NUKE: Calling backend edge function...');
      const { data, error } = await supabase.functions.invoke('nuke-user-data');

                                 
      if (error) {
        console.error('🔥 NUKE: Edge function returned error:', error);
        return; // Don't clear storage or refresh on error
      }

      if (!data?.success) {
        console.error('🔥 NUKE: Backend reported failure:', data?.error || data);
        return; // Don't clear storage or refresh on failure
      }

      console.log('🔥 NUKE: Backend deletion successful:', data);
      console.log(`🔥 NUKE: Deleted from ${data.deletedTables?.length || 0} tables`);
      console.log(`🔥 NUKE: Deleted ${data.deletedStorageFiles || 0} storage files`);

                                                        
      console.log('🔥 NUKE: Clearing localStorage...');
      localStorage.clear();

      console.log('🔥 NUKE: Clearing sessionStorage...');
      sessionStorage.clear();

                                                                                
      console.log('🔥 NUKE: Refreshing browser...');
      window.location.reload();

    } catch (err) {
                                        
      console.error('🔥 NUKE: Unexpected exception:', err);
      // Don't clear storage or refresh on exception
    }
  };

  const getUserInitials = (name: string | undefined) => {
    
    if (user?.email === 'demo@aether.ai') return "DEMO";

    
    if (user?.email === 'test-a@test.com') return "TEST";

    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  const handleDismissFile = async (fileId: string) => {
    if (fileId.startsWith('pending-')) {
      removePendingFile(fileId);
      console.log(`Cancelled pending file: ${fileId}`);
      return;
    }

    try {
      await updateFileStatus(fileId, 'inactive');
      await refreshActiveFiles();
      console.log(`File dismissed and moved to inactive: ${fileId}`);
    } catch (error) {
      console.error('Failed to dismiss file:', error);
    }
  };

  const handleFilesActivate = async (fileIds: string[]) => {
    try {
      for (const fileId of fileIds) {
        await updateFileStatus(fileId, 'active');
      }

      await refreshActiveFiles();
      await refreshInactiveFiles();

      console.log(`Activated ${fileIds.length} file(s)`);
    } catch (error) {
      console.error('Failed to activate files:', error);
    }
  };

  const handleFileDelete = async (fileId: string) => {
    if (!fileId || fileId.trim() === '') {
      console.error('Invalid fileId provided to handleFileDelete');
      return;
    }

    try {
      const { data: fileRecord, error: fetchError } = await supabase
        .from('context_files')
        .select('google_file_id')
        .eq('id', fileId)
        .maybeSingle();

      if (fetchError) {
        console.error('Failed to fetch file record:', fetchError);
        return;
      }

      if (!fileRecord) {
        console.log(`File not found: ${fileId}`);
        return;
      }

      await deleteContextFile(fileId);

      if (fileRecord.google_file_id && user?.id) {
        await unmarkGoogleFileAsReceived(user.id, fileRecord.google_file_id);
        console.log(`Unmarked Google file as received: ${fileRecord.google_file_id}`);
      }

      console.log(`File permanently deleted: ${fileId}`);
    } catch (error) {
      console.error('Failed to delete file:', error);
    }
  };

  const handleUploadClick = () => {
    console.log('Upload clicked - file picker should open');
  };

  const handleUserScrolledUp = useCallback(() => {
    setShouldAutoScroll(false);
  }, []);

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <ErrorDisplay
        error={currentError}
        onRetry={handleRetryLastMessage}
        onDismiss={handleDismissError}
      />

      <MessageList
        messages={messages}
        systemMessages={systemMessages}
        copiedMessageId={animatingButtons.copy}
        onCopy={handleCopyMessage}
        turnModeState={turnModeState}
        isLoading={isLoading}
        shouldAutoScroll={shouldAutoScroll}
        onUserScrolledUp={handleUserScrolledUp}
        onRethink={handleRethink}
        onBossRethink={handleBossRethink}
        onDelete={handleDelete}
        onMiniChat={handleMiniChat}
        onDismissSystemMessage={handleDismissSystemMessage}
        onTogglePin={handleTogglePin}
      />

      <ActiveContextBar
        activeFiles={displayFiles}
        onDismiss={handleDismissFile}
      />

      <div className="relative">
        <InputArea
          inputValue={inputValue}
          setInputValue={setInputValue}
          isLoading={isLoading}
          onSendMessage={handleSendMessage}
          attachments={attachments}
          onFileSelect={handleFileSelect}
          onRemoveAttachment={handleRemoveAttachment}
          onFilesActivate={handleFilesActivate}
          onFileDelete={handleFileDelete}
          onUploadClick={handleUploadClick}
          onGoogleUrlSubmit={handleGoogleUrlSubmit}
          tokenPercentage={tokenPercentage}
          isGlobalMiniChatOpen={isGlobalMiniChatOpen}
          globalMiniChatMessages={globalMiniChatMessages}
          globalMiniChatInput={globalMiniChatInput}
          setGlobalMiniChatInput={setGlobalMiniChatInput}
          isGlobalMiniChatLoading={isGlobalMiniChatLoading}
          onGlobalMiniChatOpen={handleGlobalMiniChatOpen}
          onGlobalMiniChatClose={handleGlobalMiniChatClose}
          onGlobalMiniChatSend={handleGlobalMiniChatSend}
          onNuke={handleNuke}
        />

      {user && (
        <div className="fixed top-4 right-4 z-50 flex flex-col items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                <Avatar className="h-10 w-10">
                  <AvatarImage
                    src={user?.user_metadata?.avatar_url}
                    alt={user?.user_metadata?.full_name || "User"}
                  />
                  <AvatarFallback className="text-[9px]">
                    {getUserInitials(user?.user_metadata?.full_name)}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 bg-background" align="end" forceMount>
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none">
                    {user?.user_metadata?.full_name || "User"}
                  </p>
                  <p className="text-xs leading-none text-muted-foreground">
                    {user?.email}
                  </p>
                </div>
              </DropdownMenuLabel>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button
            onClick={handleSignOut}
            variant="ghost"
            size="sm"
            className="h-8 px-3 text-xs text-chat-label hover:text-destructive hover:bg-destructive/10"
            title="Log out"
          >
            <LogOut className="h-3 w-3 mr-1" />
            Logout
          </Button>
        </div>
      )}
      </div>
    </div>
  );
};

export default ChatInterface;

