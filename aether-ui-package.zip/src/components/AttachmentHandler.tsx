import React, { useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Paperclip, X, Info } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from '@/components/ui/tooltip';
import { getSupportedFilesByCategory, FILE_TYPE_REGISTRY } from '@/utils/fileTypeManager';

interface AttachmentHandlerProps {
  onFileSelect: (file: File) => void;
  disabled?: boolean;
}

const generateAcceptString = (): string => {
  const supportedExtensions = Object.values(FILE_TYPE_REGISTRY)
    .filter(fileType => fileType.isSupported)
    .map(fileType => `.${fileType.extension}`);
  return supportedExtensions.join(',');
};

const generateSupportedFormatsTooltip = (): string => {
  const categories = getSupportedFilesByCategory();
  let tooltipContent = 'Supported file formats:\n\n';

  Object.entries(categories).forEach(([category, files]) => {
    const extensions = files.map(f => `.${f.extension}`).join(', ');
    const categoryName = category.charAt(0).toUpperCase() + category.slice(1);
    tooltipContent += `${categoryName}: ${extensions}\n`;
  });

  return tooltipContent;
};

const AttachmentHandler: React.FC<AttachmentHandlerProps> = ({
  onFileSelect,
  disabled = false
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    files.forEach(file => onFileSelect(file));
    e.target.value = '';
  };

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <TooltipProvider>
      <input
        ref={fileInputRef}
        type="file"
        onChange={handleFileChange}
        className="hidden"
        accept={generateAcceptString()}
        multiple
      />

      <Button
        onClick={handleButtonClick}
        variant="ghost"
        size="sm"
        className="h-6 w-6 p-0 hover:text-foreground hover:shadow-[0_0_8px_rgba(223,208,184,0.5)] transition-all duration-0"
        disabled={disabled}
      >
        <Paperclip className="!h-3 !w-3" />
      </Button>
    </TooltipProvider>
  );
};

export default AttachmentHandler;