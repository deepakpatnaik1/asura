import React from 'react';

interface TurnIndicatorProps {
  currentTurnIndex: number | null;
  totalTurns: number;
  isTurnMode: boolean;
}

const TurnIndicator: React.FC<TurnIndicatorProps> = ({
  currentTurnIndex,
  totalTurns,
  isTurnMode
}) => {
  return null;
};

export default TurnIndicator;