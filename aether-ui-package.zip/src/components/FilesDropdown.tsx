import React, { useState, useRef, useEffect } from 'react';
import { X, Folder } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import type { InactiveFile } from '@/types/contextFiles';
import { useInactiveFiles } from '@/hooks/useInactiveFiles';

interface FilesDropdownProps {
  onFilesActivate: (fileIds: string[]) => void;
  onFileDelete: (fileId: string) => void;
}

const FilesDropdown: React.FC<FilesDropdownProps> = ({
  onFilesActivate,
  onFileDelete,
}) => {
  const [open, setOpen] = useState(false);
  const [focusedIndex, setFocusedIndex] = useState<number>(-1);
  const contentRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  const { inactiveFiles, refreshInactiveFiles } = useInactiveFiles();

  useEffect(() => {
    if (open) {
      refreshInactiveFiles();
      setFocusedIndex(-1);
    } else {
      triggerRef.current?.blur();
    }
  }, [open, refreshInactiveFiles]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (inactiveFiles.length === 0) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setFocusedIndex(prev => Math.min(prev + 1, inactiveFiles.length - 1));
        break;

      case 'ArrowUp':
        e.preventDefault();
        setFocusedIndex(prev => Math.max(prev - 1, 0));
        break;

      case 'Escape':
        e.preventDefault();
        setOpen(false);
        break;
    }
  };

  const handleDelete = async (fileId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    await onFileDelete(fileId);
    await refreshInactiveFiles();
  };

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <Button
          ref={triggerRef}
          variant="ghost"
          className="h-6 w-6 p-0 hover:text-foreground hover:shadow-[0_0_8px_rgba(223,208,184,0.5)] transition-all duration-0 focus:outline-none focus:ring-0 focus-visible:ring-0 focus-visible:ring-offset-0"
          onMouseDown={(e) => {
            e.preventDefault();
          }}
        >
          <Folder className="!h-3 !w-3" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        className="z-50 bg-card border-chat-border shadow-lg w-96"
        onKeyDown={handleKeyDown}
        ref={contentRef}
        align="start"
        sideOffset={5}
      >
        <div className="py-1">
          {inactiveFiles.length === 0 ? (
            <div className="px-3 py-4 text-center text-chat-label font-menlo" style={{ fontSize: '10px' }}>
              No inactive files
            </div>
          ) : (
            inactiveFiles.map((file, index) => (
              <div
                key={file.id}
                className="flex items-center gap-1.5 px-3 py-1.5"
              >
                <button
                  className="text-red-500 hover:bg-red-500/20 rounded-full p-0.5 transition-colors duration-150"
                  onClick={(e) => handleDelete(file.id, e)}
                  title="Delete file"
                >
                  <X className="h-2.5 w-2.5" />
                </button>
                <span
                  className={`font-menlo text-foreground flex-1 cursor-pointer hover:bg-accent rounded px-1.5 py-0.5 transition-colors duration-150 ${
                    focusedIndex === index ? 'bg-accent' : ''
                  }`}
                  style={{ fontSize: '10px' }}
                  onClick={async () => {
                    await onFilesActivate([file.id]);
                    await refreshInactiveFiles();
                  }}
                >
                  {file.filename}
                </span>
              </div>
            ))
          )}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default FilesDropdown;
