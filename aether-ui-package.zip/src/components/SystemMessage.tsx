import React from 'react';
import { Info, X } from 'lucide-react';
import type { SystemMessageType } from '@/types/systemMessages';

interface SystemMessageProps {
  message: SystemMessageType;
  onDismiss?: (messageId: string) => void;
}

const SystemMessage: React.FC<SystemMessageProps> = ({ message, onDismiss }) => {
  const formattedDate = new Date(message.created_at).toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });

  return (
    <div
      className="py-6"
      style={{ borderBottom: '1px solid rgba(160, 160, 160, 0.3)' }}
    >
      {}
      <div className="flex items-center gap-2 mb-3">
        <Info
          className="flex-shrink-0"
          style={{
            width: '16px',
            height: '16px',
            color: 'rgb(160, 160, 160)'
          }}
        />
        <span
          style={{
            color: 'rgb(160, 160, 160)',
            fontSize: '12px',
            fontWeight: 500
          }}
        >
          System
        </span>
        <span
          style={{
            color: 'rgb(160, 160, 160)',
            fontSize: '11px',
            opacity: 0.7
          }}
        >
          {formattedDate}
        </span>
        {onDismiss && (
          <button
            onClick={() => onDismiss(message.id)}
            className="ml-auto opacity-50 hover:opacity-100 transition-opacity"
            style={{ color: 'rgb(160, 160, 160)' }}
            title="Dismiss message"
          >
            <X size={16} />
          </button>
        )}
      </div>

      {}
      <div
        style={{
          fontSize: '13px',
          color: 'rgb(210, 213, 219)',
          lineHeight: 1.6,
          background: 'rgba(0, 0, 0, 0.2)',
          padding: '12px',
          borderRadius: '6px',
          whiteSpace: 'pre-wrap'
        }}
      >
        {message.message}

        {}
        {message.link && (
          <div className="mt-2">
            <a
              href={message.link}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                color: 'rgb(96, 165, 250)',
                textDecoration: 'underline',
                cursor: 'pointer'
              }}
              className="hover:opacity-80"
            >
              {message.link}
            </a>
          </div>
        )}
      </div>
    </div>
  );
};

export default SystemMessage;
