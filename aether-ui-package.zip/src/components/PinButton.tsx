import React from 'react';
import { Star } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from '@/components/ui/tooltip';

interface PinButtonProps {
  isPinned: boolean;
  onToggle: () => void;
  messageId: string;
  sender?: 'Boss' | 'Gunnar';
}

const PinButton: React.FC<PinButtonProps> = ({
  isPinned,
  onToggle,
  messageId,
  sender
}) => {
  const iconColor = sender === 'Boss' ? 'rgb(217, 133, 107)' : undefined;

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            onClick={onToggle}
            className="flex-shrink-0 p-1 rounded transition-all duration-0 hover:text-foreground hover:shadow-[0_0_8px_rgba(223,208,184,0.5)]"
            style={iconColor ? { color: iconColor } : undefined}
            aria-label={isPinned ? 'Unpin message' : 'Pin message'}
            data-message-id={messageId}
          >
            <Star
              size={12}
              className={isPinned ? 'fill-red-400 text-red-400' : 'text-yellow-400/30'}
            />
          </button>
        </TooltipTrigger>
        <TooltipContent>
          <p>
            {isPinned ? 'Unpin this message' : 'Pin this message (always keep in context)'}
          </p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default PinButton;
