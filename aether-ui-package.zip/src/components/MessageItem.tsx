import React, { useState, useRef, useEffect } from 'react';
import { X, ArrowUp } from 'lucide-react';

import MessageActions from './MessageActions';
import MarkdownRenderer from './MarkdownRenderer';
import PinButton from './PinButton';

interface Message {
  id: string;
  text: string;
  sender: 'Boss' | 'Gunnar';
  dbId?: string;
  timestamp?: string;
  isPinned?: boolean;
}

interface MessageItemProps {
  message: Message;
  turnNumber?: number;
  bossMessageId?: string;
  copiedMessageId: string | null;
  onCopy: (text: string, messageId: string) => void;
  onRethink?: (messageId: string, corrections: Array<{text: string, feedback: string}>) => void;
  onBossRethink?: (messageId: string, newQuery: string) => void;
  onDelete?: (messageId: string) => void;
  onMiniChat?: (messageId: string, question: string, onResponse: (content: string, isComplete: boolean) => void) => void;
  isPinned?: boolean;
  onTogglePin?: (messageId: string) => void;
}

const MessageItem: React.FC<MessageItemProps> = ({
  message,
  turnNumber,
  bossMessageId,
  copiedMessageId,
  onCopy,
  onRethink,
  onBossRethink,
  onDelete,
  onMiniChat,
  isPinned,
  onTogglePin,
}) => {
  const [isRethinkMode, setIsRethinkMode] = useState(false);
  const [isMiniChatMode, setIsMiniChatMode] = useState(false);
  const [corrections, setCorrections] = useState<Array<{text: string, feedback: string}>>([]);
  const [showFeedbackPopup, setShowFeedbackPopup] = useState(false);
  const [popupPosition, setPopupPosition] = useState({ x: 0, y: 0 });
  const [selectedText, setSelectedText] = useState('');
  const [currentFeedback, setCurrentFeedback] = useState('');
  const [miniChatMessages, setMiniChatMessages] = useState<Array<{sender: 'Boss' | 'Gunnar', text: string}>>([]);
  const [miniChatInput, setMiniChatInput] = useState('');
  const [isMiniChatLoading, setIsMiniChatLoading] = useState(false);
  const [isBossRethinkMode, setIsBossRethinkMode] = useState(false);
  const [bossRethinkInput, setBossRethinkInput] = useState('');
  const popupRef = useRef<HTMLDivElement>(null);
  const messageBoxRef = useRef<HTMLDivElement>(null);
  const miniChatInputRef = useRef<HTMLInputElement>(null);
  const bossRethinkInputRef = useRef<HTMLInputElement>(null);

  const scrollToBossMessage = () => {
    if (!bossMessageId) return;
    const bossElement = document.querySelector(`[data-message-id="${bossMessageId}"]`);
    if (bossElement) {
      const container = bossElement.closest('.overflow-y-auto');
      if (container) {
        const elementTop = (bossElement as HTMLElement).offsetTop;
        const lineHeight = 24; 
        container.scrollTo({ top: elementTop - lineHeight, behavior: 'smooth' });
      } else {
        bossElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  };

  const handleRethinkClick = () => {
    if (message.sender === 'Boss') {
      if (isBossRethinkMode) {
        return;
      }
      setIsBossRethinkMode(true);
    } else {
      if (isRethinkMode) {
        let finalCorrections = corrections;
        const pendingText = selectedText?.trim();
        const pendingFeedback = currentFeedback?.trim();
        if (finalCorrections.length === 0 && pendingText && pendingFeedback) {
          finalCorrections = [...finalCorrections, { text: pendingText, feedback: pendingFeedback }];
        }
        if (onRethink && finalCorrections.length > 0) {
          onRethink(message.id, finalCorrections);
        }
        setIsRethinkMode(false);
        setCorrections([]);
        setShowFeedbackPopup(false);
        setSelectedText('');
        setCurrentFeedback('');
      } else {
        setIsRethinkMode(true);
      }
    }
  };

  const handleMiniChatClick = () => {
    setIsMiniChatMode(true);
  };

  const closeMiniChat = () => {
    setIsMiniChatMode(false);
    setMiniChatMessages([]);
    setMiniChatInput('');
    setIsMiniChatLoading(false);
  };

  const handleMiniChatSend = () => {
    if (!miniChatInput.trim() || isMiniChatLoading || !onMiniChat) return;

    const question = miniChatInput;

    const bossMessage = { sender: 'Boss' as const, text: question };
    setMiniChatMessages(prev => [...prev, bossMessage]);
    setMiniChatInput('');
    setIsMiniChatLoading(true);

    setMiniChatMessages(prev => [...prev, { sender: 'Gunnar' as const, text: '' }]);

    onMiniChat(message.id, question, (content: string, isComplete: boolean) => {
      setMiniChatMessages(prev => {
        const updated = [...prev];
        updated[updated.length - 1] = { sender: 'Gunnar' as const, text: content };
        return updated;
      });

      if (isComplete) {
        setIsMiniChatLoading(false);
      }
    });
  };

  const handleBossRethinkSubmit = () => {
    if (!bossRethinkInput.trim() || !onBossRethink) return;

    const newQuery = bossRethinkInput.trim();

    onBossRethink(message.id, newQuery);

    closeBossRethink();
  };

  const closeBossRethink = () => {
    setIsBossRethinkMode(false);
    setBossRethinkInput('');
  };

  const handleTextSelection = () => {
    if (!isRethinkMode) return;

    const selection = window.getSelection();
    const text = selection?.toString().trim();

    if (text && text.length > 0) {
      const anchorNode = selection?.anchorNode as Node | null;
      if (anchorNode && messageBoxRef.current && !messageBoxRef.current.contains(anchorNode)) {
        return; 
      }

      const range = selection?.getRangeAt(0);
      const rect = range?.getBoundingClientRect();
      const messageBoxRect = messageBoxRef.current?.getBoundingClientRect();

      if (rect && messageBoxRect) {
        let popupX = rect.left;
        const popupWidth = 400;

        if (popupX + popupWidth > messageBoxRect.right) {
          popupX = messageBoxRect.right - popupWidth;
        }

        if (popupX < messageBoxRect.left) {
          popupX = messageBoxRect.left;
        }

        setSelectedText(text);
        setPopupPosition({ x: popupX, y: rect.bottom });
        setShowFeedbackPopup(true);
        setCurrentFeedback('');
      }
    }
  };

  const handleAddCorrection = () => {
    if (selectedText && currentFeedback) {
      setCorrections([...corrections, { text: selectedText, feedback: currentFeedback }]);
      setShowFeedbackPopup(false);
      setSelectedText('');
      setCurrentFeedback('');
    }
  };

  const handleCancelFeedback = () => {
    setShowFeedbackPopup(false);
    setSelectedText('');
    setCurrentFeedback('');
    window.getSelection()?.removeAllRanges();
  };

  const exitRethinkMode = () => {
    setIsRethinkMode(false);
    setCorrections([]);
    setShowFeedbackPopup(false);
    setSelectedText('');
    setCurrentFeedback('');

    setTimeout(() => {
      const mainInput = document.querySelector('input[placeholder="Type your message..."]') as HTMLInputElement;
      if (mainInput) {
        mainInput.focus();
      }
    }, 0);
  };

  useEffect(() => {
    if (!showFeedbackPopup) return;

    const handleClickOutside = (event: MouseEvent) => {
      if (popupRef.current && !popupRef.current.contains(event.target as Node)) {
        if (currentFeedback.trim()) {
          handleAddCorrection();
        } else {
          handleCancelFeedback();
        }
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showFeedbackPopup, currentFeedback, selectedText]);

  useEffect(() => {
    if (!isRethinkMode) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        exitRethinkMode();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isRethinkMode]);

  useEffect(() => {
    if (!isMiniChatMode) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        closeMiniChat();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isMiniChatMode]);

  useEffect(() => {
    if (!isBossRethinkMode) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        closeBossRethink();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isBossRethinkMode]);

  useEffect(() => {
    if (isMiniChatMode && miniChatInputRef.current) {
      miniChatInputRef.current.focus();
    }
  }, [isMiniChatMode, miniChatMessages]);

  useEffect(() => {
    if (isBossRethinkMode && bossRethinkInputRef.current) {
      bossRethinkInputRef.current.focus();
    }
  }, [isBossRethinkMode]);

  return (
    <div
      className="group relative"
      data-message-id={message.id}
      style={message.sender === 'Boss' ? {
        background: 'rgba(217, 133, 107, 0.08)',
        padding: '16px',
        marginLeft: '-16px',
        marginRight: '-16px',
        borderRadius: '8px'
      } : undefined}
    >
      {message.sender === 'Boss' && turnNumber && (
        <div
          className="font-menlo mb-1"
          style={{
            fontSize: '9px',
            opacity: 0.3,
            color: 'rgb(217, 133, 107)'
          }}
        >
          Turn {turnNumber}
        </div>
      )}
      <div
        className="text-chat-label text-sm font-medium mb-3 border-b border-chat-border pb-2 flex justify-between items-center"
        style={message.sender === 'Boss' ? { borderColor: 'rgb(217, 133, 107)' } : undefined}
      >
        <span
          className="bg-card px-2 py-1 rounded text-xs"
          style={message.sender === 'Boss' ? { color: 'rgb(217, 133, 107)' } : undefined}
        >
          {message.sender}
        </span>
        <div className="flex items-center gap-2">
          <PinButton
            isPinned={isPinned || false}
            onToggle={() => onTogglePin?.(message.id)}
            messageId={message.id}
            sender={message.sender}
          />
          <MessageActions
            messageId={message.id}
            messageText={message.text}
            copiedMessageId={copiedMessageId}
            onCopy={onCopy}
            rethinkingMessageId={isRethinkMode || isBossRethinkMode ? message.id : undefined}
            deletingMessageId={undefined}
            miniChatMessageId={isMiniChatMode ? message.id : undefined}
            sender={message.sender}
            onRethinkClick={handleRethinkClick}
            onDelete={onDelete}
            onMiniChatClick={handleMiniChatClick}
          />
          <span
            className="ml-2 font-menlo"
            style={{
              fontSize: '10px',
              color: message.sender === 'Boss' ? 'rgb(217, 133, 107)' : undefined
            }}
          >
            {message.timestamp ? new Date(message.timestamp).toLocaleString('en-US', {
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            }) : ''}
          </span>
        </div>
      </div>

      <div
        ref={messageBoxRef}
        className={`text-foreground leading-relaxed pl-3 select-text ${isRethinkMode ? 'rounded-lg p-3' : ''}`}
        style={{
          fontSize: '13px',
          WebkitUserSelect: 'text' as any,
          userSelect: 'text' as any,
          ...(isRethinkMode && {
            background: 'rgba(255, 255, 255, 0.08)',
            border: '2px solid rgba(59, 130, 246, 0.6)',
            boxShadow: '0 0 20px rgba(59, 130, 246, 0.4)',
          })
        }}
        onMouseUp={handleTextSelection}
      >
        <MarkdownRenderer>{message.text}</MarkdownRenderer>
      </div>

      {isRethinkMode && corrections.length > 0 && (
        <div className="mt-2 pl-3 text-xs font-menlo text-chat-label">
          {corrections.length} correction{corrections.length > 1 ? 's' : ''} added
        </div>
      )}

      {showFeedbackPopup && (
        <div
          ref={popupRef}
          className="fixed z-50 bg-card border rounded shadow-lg flex items-center gap-2 px-3 py-2"
          style={{
            left: popupPosition.x,
            top: popupPosition.y + 10,
            width: '400px',
            borderWidth: '1px',
            borderStyle: 'solid',
            borderColor: 'rgba(217, 133, 107, 0.5)'
          }}
>
          <button
            className="text-red-500 hover:text-red-600 transition-colors"
            onClick={handleCancelFeedback}
          >
            <X size={16} />
          </button>
          <input
            autoFocus
            type="text"
            className="flex-1 bg-card font-sans focus-visible:ring-0 focus-visible:ring-offset-0 border-none outline-none placeholder:text-prose-body"
            style={{
              fontSize: '13px',
              color: 'rgb(210, 213, 219)'
            }}
            placeholder="Type your message..."
            value={currentFeedback}
            onChange={(e) => setCurrentFeedback(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                handleAddCorrection();
              }
            }}
            onFocus={(e) => {
              e.target.selectionStart = e.target.selectionEnd = e.target.value.length;
            }}
          />
        </div>
      )}

      {isMiniChatMode && (
        <>
          {}
          <div
            className="fixed inset-0 bg-black z-40"
            style={{ opacity: 0.6 }}
            onClick={closeMiniChat}
          />

          {}
          <div
            className="fixed z-50"
            style={{
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)'
            }}
          >
            <div
              className="bg-card rounded-lg shadow-2xl"
              style={{
                width: '350px',
                maxHeight: '600px',
                display: 'flex',
                flexDirection: 'column'
              }}
            >
            {}
            <div className="flex-1 p-4 overflow-y-auto space-y-5" style={{ maxHeight: '500px', background: 'rgba(0, 0, 0, 0.3)' }}>
              {miniChatMessages.length === 0 && (
                <div className="text-chat-label text-center py-12" style={{ fontSize: '11px' }}>
                  Ask a quick question about this message...
                </div>
              )}

              {miniChatMessages.map((msg, index) => (
                <div key={index}>
                  <div
                    className="font-medium mb-2 border-b border-chat-border pb-1.5"
                    style={msg.sender === 'Boss' ? { borderBottomColor: 'rgb(217, 133, 107)', borderBottomWidth: '0.5px' } : undefined}
                  >
                    <span
                      className="bg-card px-1.5 py-0.5 rounded"
                      style={{
                        fontSize: '11px',
                        color: msg.sender === 'Boss' ? 'rgb(217, 133, 107)' : 'inherit'
                      }}
                    >
                      {msg.sender}
                    </span>
                  </div>
                  <div className="leading-relaxed pl-2" style={{ fontSize: '11px', color: 'rgb(210, 213, 219)' }}>
                    {msg.text}
                  </div>
                </div>
              ))}

              {isMiniChatLoading && (
                <div style={{ fontSize: '11px' }}>
                  {'Thinking...'.split('').map((char, index) => (
                    <span
                      key={index}
                      className="inline-block animate-pulse"
                      style={{
                        animationDelay: `${index * 100}ms`,
                        animationDuration: '1s'
                      }}
                    >
                      {char === ' ' ? '\u00A0' : char}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {}
            <div className="p-3 border-t border-chat-border">
              <div className="flex items-center gap-2">
                <input
                  ref={miniChatInputRef}
                  type="text"
                  placeholder="Ask a question..."
                  value={miniChatInput}
                  onChange={(e) => setMiniChatInput(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      handleMiniChatSend();
                    }
                  }}
                  disabled={isMiniChatLoading}
                  className="flex-1 bg-card border-none outline-none placeholder:text-prose-body px-2 py-1 rounded"
                  style={{
                    fontSize: '11px',
                    border: '0.5px solid rgb(217, 133, 107)',
                    color: 'rgb(210, 213, 219)'
                  }}
                />
                <button
                  onClick={handleMiniChatSend}
                  disabled={isMiniChatLoading || !miniChatInput.trim()}
                  className="px-3 py-1 rounded transition-colors disabled:opacity-50"
                  style={{
                    background: 'rgb(217, 133, 107)',
                    color: 'rgb(20, 21, 23)',
                    fontSize: '11px'
                  }}
                >
                  Send
                </button>
              </div>
            </div>
          </div>
        </div>
        </>
      )}

      {isBossRethinkMode && (
        <>
          {}
          <div
            className="fixed inset-0 bg-black z-40"
            style={{ opacity: 0.6 }}
            onClick={closeBossRethink}
          />

          {}
          <div
            className="fixed z-50"
            style={{
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)'
            }}
          >
            <div
              className="bg-card rounded-lg shadow-2xl p-6"
              style={{
                width: '450px',
                display: 'flex',
                flexDirection: 'column',
                gap: '16px'
              }}
            >
              {}
              <div className="text-center">
                <div
                  className="font-medium mb-2"
                  style={{
                    fontSize: '13px',
                    color: 'rgb(217, 133, 107)'
                  }}
                >
                  Rethink Question
                </div>
                <div
                  className="text-chat-label"
                  style={{ fontSize: '11px' }}
                >
                  Enter a new question to replace your previous one
                </div>
              </div>

              {}
              <input
                ref={bossRethinkInputRef}
                type="text"
                placeholder="Type your new question..."
                value={bossRethinkInput}
                onChange={(e) => setBossRethinkInput(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleBossRethinkSubmit();
                  }
                }}
                className="w-full bg-card border rounded px-3 py-2 outline-none placeholder:text-prose-body"
                style={{
                  fontSize: '13px',
                  borderWidth: '1px',
                  borderColor: 'rgb(217, 133, 107)',
                  color: 'rgb(210, 213, 219)'
                }}
              />

              {}
              <div className="flex items-center justify-end gap-2">
                <button
                  onClick={closeBossRethink}
                  className="px-4 py-2 rounded transition-colors"
                  style={{
                    fontSize: '12px',
                    color: 'rgb(210, 213, 219)',
                    border: '1px solid rgba(217, 133, 107, 0.3)'
                  }}
                >
                  Cancel
                </button>
                <button
                  onClick={handleBossRethinkSubmit}
                  disabled={!bossRethinkInput.trim()}
                  className="px-4 py-2 rounded transition-colors disabled:opacity-50"
                  style={{
                    background: 'rgb(217, 133, 107)',
                    color: 'rgb(20, 21, 23)',
                    fontSize: '12px'
                  }}
                >
                  Submit
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default React.memo(MessageItem);
