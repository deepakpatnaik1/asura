import React, { useRef, useEffect, useCallback } from 'react';

import MessageItem from './MessageItem';
import SystemMessage from './SystemMessage';
import TurnIndicator from './TurnIndicator';
import type { SystemMessageType } from '@/types/systemMessages';

interface Message {
  id: string;
  text: string;
  sender: 'Boss' | 'Gunnar';
  dbId?: string;
  timestamp?: string;
  isPinned?: boolean;
}

interface Turn {
  turnNumber: number;
  bossMessage: Message;
  gunnarMessage?: Message;
  startIndex: number;
  endIndex: number;
}

interface TurnModeState {
  isTurnMode: boolean;
  currentTurnIndex: number | null;
  turns: Turn[];
  totalTurns: number;
  enterTurnMode: () => void;
  exitTurnMode: () => void;
  navigateToTurn: (direction: 'up' | 'down') => void;
  isMessageInCurrentTurn: (messageId: string) => boolean;
}

interface MessageListProps {
  messages: Message[];
  systemMessages: SystemMessageType[];
  copiedMessageId: string | null;
  onCopy: (text: string, messageId: string) => void;
  turnModeState: TurnModeState;
  isLoading: boolean;
  shouldAutoScroll: boolean;
  onUserScrolledUp: () => void;
  onRethink?: (messageId: string, corrections: Array<{text: string; feedback: string}>) => void;
  onBossRethink?: (messageId: string, newQuery: string) => void;
  onDelete?: (messageId: string) => void;
  onMiniChat?: (messageId: string, question: string, onResponse: (content: string, isComplete: boolean) => void) => void;
  onDismissSystemMessage?: (messageId: string) => void;
  onTogglePin?: (messageId: string) => void;
}

const MessageList: React.FC<MessageListProps> = ({
  messages,
  systemMessages,
  copiedMessageId,
  onCopy,
  turnModeState,
  isLoading,
  shouldAutoScroll,
  onUserScrolledUp,
  onRethink,
  onBossRethink,
  onDelete,
  onMiniChat,
  onDismissSystemMessage,
  onTogglePin,
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const currentTurnRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const scrollTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const resizeObserverRef = useRef<ResizeObserver | null>(null);
  const initialScrollDoneRef = useRef(false);

  const turnModeRef = useRef(turnModeState.isTurnMode);
  turnModeRef.current = turnModeState.isTurnMode;

  const isNearBottom = useCallback(() => {
    const container = containerRef.current;
    if (!container) return false;
    const threshold = 120; 
    const position = container.scrollTop + container.clientHeight;
    return container.scrollHeight - position < threshold;
  }, []);

  const scrollToBottom = useCallback(() => {
    if (!turnModeRef.current && containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, []);

  const deferredScrollToBottom = useCallback(() => {
    if (scrollTimeoutRef.current) {
      clearTimeout(scrollTimeoutRef.current);
    }

    scrollTimeoutRef.current = setTimeout(() => {
      
      if (isLoading) {
        scrollToBottom();
        return;
      }

      if (isNearBottom()) {
        scrollToBottom();
      }
    }, 50);
  }, [scrollToBottom, isNearBottom, isLoading]);

  useEffect(() => {
    if (!containerRef.current || typeof ResizeObserver === 'undefined') return;

    const handleResize = (entries: ResizeObserverEntry[]) => {
      if (turnModeRef.current || !messagesEndRef.current) return;

      const entry = entries[0];
      if (entry && entry.contentRect.height > 0) {
        
        
        
        if (scrollTimeoutRef.current) {
          clearTimeout(scrollTimeoutRef.current);
        }
        scrollTimeoutRef.current = setTimeout(() => {
          if (turnModeRef.current || !containerRef.current) return;
          
          if (isNearBottom()) {
            containerRef.current.scrollTop = containerRef.current.scrollHeight;
          }
        }, 16);
      }
    };

    try {
      resizeObserverRef.current = new ResizeObserver(handleResize);
      resizeObserverRef.current.observe(containerRef.current);
    } catch (error) {
      console.warn('ResizeObserver not supported:', error);
    }

    return () => {
      if (resizeObserverRef.current) {
        resizeObserverRef.current.disconnect();
      }
    };
  }, []);

  
  useEffect(() => {
    if (!turnModeRef.current && !initialScrollDoneRef.current && messages.length > 0) {
      if (messagesEndRef.current) {
        messagesEndRef.current.scrollIntoView({ behavior: 'auto' });
        initialScrollDoneRef.current = true;
      }
    }
  }, [messages.length]);

  useEffect(() => {
    if (turnModeRef.current) return; 

    if (shouldAutoScroll) {
      
      scrollToBottom();
      return;
    }

    if (isNearBottom()) {
      scrollToBottom();
    }
  }, [messages, scrollToBottom, isNearBottom, shouldAutoScroll]);

  useEffect(() => {
    return () => {
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (turnModeState.isTurnMode && currentTurnRef.current) {
      currentTurnRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }
  }, [turnModeState.isTurnMode, turnModeState.currentTurnIndex]);

  
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleScroll = () => {
      
      if (turnModeRef.current) return;

      
      if (!isNearBottom()) {
        onUserScrolledUp();
      }
    };

    container.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      container.removeEventListener('scroll', handleScroll);
    };
  }, [isNearBottom, onUserScrolledUp]);

  return (
    <div ref={containerRef} className="flex-1 overflow-y-auto px-4 py-4">
      <TurnIndicator
        currentTurnIndex={turnModeState.currentTurnIndex}
        totalTurns={turnModeState.totalTurns}
        isTurnMode={turnModeState.isTurnMode}
      />

      <div className="mx-auto space-y-5" style={{ maxWidth: '600px' }}>
        {(() => {
          const allMessages = [
            ...messages.map(msg => ({
              type: 'regular' as const,
              data: msg,
              timestamp: msg.timestamp || ''
            })),
            ...systemMessages.map(sysMsg => ({
              type: 'system' as const,
              data: sysMsg,
              timestamp: sysMsg.created_at
            }))
          ].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

          
          let turnCounter = 0;
          let lastBossMessageId: string | undefined;
          const messageWithTurns = allMessages.map((item) => {
            if (item.type === 'regular' && item.data.sender === 'Boss') {
              turnCounter++;
              lastBossMessageId = item.data.id;
              return { ...item, turnNumber: turnCounter, bossMessageId: undefined };
            }
            if (item.type === 'regular' && item.data.sender === 'Gunnar') {
              return { ...item, turnNumber: undefined, bossMessageId: lastBossMessageId };
            }
            return { ...item, turnNumber: undefined, bossMessageId: undefined };
          });

          return messageWithTurns.map((item) => {
            if (item.type === 'system') {
              return (
                <div key={`system-${item.data.id}`}>
                  <SystemMessage message={item.data} onDismiss={onDismissSystemMessage} />
                </div>
              );
            }

            const message = item.data;
            const isInCurrentTurn = turnModeState.isMessageInCurrentTurn(message.id);
            const isDimmed = turnModeState.isTurnMode && !isInCurrentTurn;

            return (
              <div
                key={message.id}
                ref={isInCurrentTurn && turnModeState.isTurnMode ? currentTurnRef : undefined}
                className={`transition-opacity duration-300 ${
                  isDimmed ? 'opacity-30' : 'opacity-100'
                }`}
              >
                <MessageItem
                  message={message}
                  turnNumber={item.turnNumber}
                  bossMessageId={item.bossMessageId}
                  copiedMessageId={copiedMessageId}
                  onCopy={onCopy}
                  onRethink={onRethink}
                  onBossRethink={onBossRethink}
                  onDelete={onDelete}
                  onMiniChat={onMiniChat}
                  isPinned={message.isPinned}
                  onTogglePin={onTogglePin}
                />
              </div>
            );
          });
        })()}
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
};


const MessageListMemo = React.memo(MessageList, (prev, next) => {
  return (
    prev.messages === next.messages &&
    prev.systemMessages === next.systemMessages &&
    prev.copiedMessageId === next.copiedMessageId &&
    prev.isLoading === next.isLoading &&
    prev.shouldAutoScroll === next.shouldAutoScroll &&
    prev.turnModeState.isTurnMode === next.turnModeState.isTurnMode &&
    prev.turnModeState.currentTurnIndex === next.turnModeState.currentTurnIndex &&
    prev.turnModeState.totalTurns === next.turnModeState.totalTurns
  );
});

export default MessageListMemo;
