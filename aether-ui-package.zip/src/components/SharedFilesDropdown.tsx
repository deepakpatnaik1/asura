import React, { useState, useRef, useEffect } from 'react';
import { FileText, Table, Presentation, Download } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import type { SharedGoogleFile } from '@/services/listSharedGoogleFiles';

const SERVICE_ACCOUNT_EMAIL = 'tsushima@tsushima-472819.iam.gserviceaccount.com';

interface SharedFilesDropdownProps {
  files: SharedGoogleFile[];
  onFilesSelect: (selectedFiles: SharedGoogleFile[]) => void;
  isLoading: boolean;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

const SharedFilesDropdown: React.FC<SharedFilesDropdownProps> = ({
  files,
  onFilesSelect,
  isLoading,
  open: controlledOpen,
  onOpenChange,
}) => {
  const [internalOpen, setInternalOpen] = useState(false);
  const open = controlledOpen !== undefined ? controlledOpen : internalOpen;

  const handleOpenChange = (newOpen: boolean) => {
    if (onOpenChange) {
      onOpenChange(newOpen);
    } else {
      setInternalOpen(newOpen);
    }
  };
  const [selectedFiles, setSelectedFiles] = useState<Set<string>>(new Set());
  const [focusedIndex, setFocusedIndex] = useState<number>(-1);
  const contentRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) {
      triggerRef.current?.blur();
      setSelectedFiles(new Set());
      setFocusedIndex(-1);
    }
  }, [open]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (isLoading || files.length === 0) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setFocusedIndex(prev => Math.min(prev + 1, files.length - 1));
        break;

      case 'ArrowUp':
        e.preventDefault();
        setFocusedIndex(prev => Math.max(prev - 1, 0));
        break;

      case ' ':
        e.preventDefault();
        if (focusedIndex >= 0) {
          const fileId = files[focusedIndex].id;
          setSelectedFiles(prev => {
            const newSet = new Set(prev);
            if (newSet.has(fileId)) {
              newSet.delete(fileId);
            } else {
              newSet.add(fileId);
            }
            return newSet;
          });
        }
        break;

      case 'Enter':
        e.preventDefault();
        if (selectedFiles.size > 0) {
          const selected = files.filter(f => selectedFiles.has(f.id));
          onFilesSelect(selected);
        }
        break;

      case 'Escape':
        e.preventDefault();
        handleOpenChange(false);
        break;
    }
  };

  const handleFileClick = (file: SharedGoogleFile) => {
    onFilesSelect([file]);
  };

  const getFileIcon = (type: 'docs' | 'sheets' | 'slides') => {
    switch (type) {
      case 'docs':
        return <FileText className="h-3.5 w-3.5 text-blue-500" />;
      case 'sheets':
        return <Table className="h-3.5 w-3.5 text-green-500" />;
      case 'slides':
        return <Presentation className="h-3.5 w-3.5 text-orange-500" />;
    }
  };

  return (
    <DropdownMenu open={open} onOpenChange={handleOpenChange}>
      <DropdownMenuTrigger asChild>
        <Button
          ref={triggerRef}
          variant="ghost"
          className="h-6 px-2 text-chat-label font-menlo bg-transparent border-none hover:text-foreground hover:shadow-[0_0_8px_rgba(223,208,184,0.5)] transition-all duration-0 flex items-center gap-1 focus:outline-none focus:ring-0 focus-visible:ring-0 focus-visible:ring-offset-0"
          style={{ fontSize: '10px' }}
          disabled={false}
          onMouseDown={(e) => {
            e.preventDefault();
          }}
        >
          <Download className="!h-3 !w-3" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        className="z-50 bg-card border-chat-border shadow-lg w-96"
        onKeyDown={handleKeyDown}
        ref={contentRef}
        align="start"
        sideOffset={5}
      >
        <div className="py-1">
          {isLoading ? (
            <div className="flex items-center px-3 py-2">
              <span className="font-menlo text-chat-label" style={{ fontSize: '10px' }}>
                Checking
                {'...'.split('').map((char, charIndex) => (
                  <span
                    key={charIndex}
                    className="inline-block animate-pulse"
                    style={{
                      animationDelay: `${charIndex * 100}ms`,
                      animationDuration: '1s'
                    }}
                  >
                    {char}
                  </span>
                ))}
              </span>
            </div>
          ) : files.length === 0 ? (
            <div className="flex items-center justify-center px-3 py-2">
              <span className="font-menlo text-chat-label" style={{ fontSize: '10px' }}>
                No recently shared files
              </span>
            </div>
          ) : (
            files.map((file, index) => (
              <div
                key={file.id}
                className={`flex items-center gap-1.5 px-3 py-1.5 cursor-pointer ${
                  focusedIndex === index ? 'bg-accent' : 'hover:bg-accent'
                }`}
                onClick={() => handleFileClick(file)}
              >
                <span className="font-menlo text-foreground flex-1" style={{ fontSize: '10px' }}>
                  {file.name}
                </span>
              </div>
            ))
          )}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default SharedFilesDropdown;
