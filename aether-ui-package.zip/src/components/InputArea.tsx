
import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AI_MODELS } from '@/config/constants';
import FilesDropdown from './FilesDropdown';
import { X, Download, Flame, ChevronsDown, ChevronsUp, MessageSquare, ArrowDown, Paperclip } from 'lucide-react';
import { Attachment } from '@/types/attachments';
import { FILE_TYPE_REGISTRY } from '@/utils/fileTypeManager';
import { isGoogleUrl, validateGoogleUrl } from '@/utils/googleUrlValidator';
import SharedFilesDropdown from './SharedFilesDropdown';
import { listSharedGoogleFiles, type SharedGoogleFile } from '@/services/listSharedGoogleFiles';
import { getReceivedGoogleFileIds } from '@/services/receivedGoogleFilesDB';
import { useAuth } from '@/hooks/useAuth';
import type { PersonaInfo } from '@/types/personas';
import type { ModelInfo } from '@/types/models';
import { useSettings } from '@/hooks/useSettings';
import { supabase } from '@/integrations/supabase/client';
import Fuse from 'fuse.js';
import { PERSONA_CONFIGS } from '@/config/systemPrompts';

interface InputAreaProps {
  inputValue: string;
  setInputValue: (value: string) => void;
  isLoading: boolean;
  onSendMessage: () => void;
  attachments: Attachment[];
  onFileSelect: (file: File) => void;
  onRemoveAttachment: (id: string) => void;
  onFilesActivate: (fileIds: string[]) => void;
  onFileDelete: (fileId: string) => void;
  onUploadClick: () => void;
  onGoogleUrlSubmit?: (url: string, type: 'docs' | 'sheets' | 'slides', documentId: string, fileName?: string) => void;
  tokenPercentage?: number | null;
  isGlobalMiniChatOpen: boolean;
  globalMiniChatMessages: Array<{sender: 'Boss' | 'Gunnar', text: string}>;
  globalMiniChatInput: string;
  setGlobalMiniChatInput: (value: string) => void;
  isGlobalMiniChatLoading: boolean;
  onGlobalMiniChatOpen: () => void;
  onGlobalMiniChatClose: () => void;
  onGlobalMiniChatSend: () => void;
  onNuke: () => void;
}

const InputArea: React.FC<InputAreaProps> = ({
  inputValue,
  setInputValue,
  isLoading,
  onSendMessage,
  attachments,
  onFileSelect,
  onRemoveAttachment,
  onFilesActivate,
  onFileDelete,
  onUploadClick,
  onGoogleUrlSubmit,
  tokenPercentage,
  isGlobalMiniChatOpen,
  globalMiniChatMessages,
  globalMiniChatInput,
  setGlobalMiniChatInput,
  isGlobalMiniChatLoading,
  onGlobalMiniChatOpen,
  onGlobalMiniChatClose,
  onGlobalMiniChatSend,
  onNuke,
}) => {
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const justReplacedRef = useRef(false);
  const [isDragOver, setIsDragOver] = React.useState(false);
  const [modelDropdownOpen, setModelDropdownOpen] = React.useState(false);
  const [personaDropdownOpen, setPersonaDropdownOpen] = React.useState(false);
  const [models, setModels] = useState<ModelInfo[]>([]);
  const [modelsLoading, setModelsLoading] = useState(true);
  const [personas, setPersonas] = useState<PersonaInfo[]>([]);
  const [personasLoading, setPersonasLoading] = useState(true);
  const [sharedFiles, setSharedFiles] = useState<SharedGoogleFile[]>([]);
  const [isLoadingSharedFiles, setIsLoadingSharedFiles] = useState(false);
  const [sharedFilesDropdownOpen, setSharedFilesDropdownOpen] = useState(false);
  const [isAutoScrolling, setIsAutoScrolling] = useState(false);
  const isAutoScrollingRef = useRef(false);
  const autoScrollFrameRef = useRef<number | null>(null);
  const lastScrollTimeRef = useRef<number>(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { user } = useAuth();
  const { selectedModel: settingsModel, updateModel, selectedPersona, updatePersona } = useSettings();

  
  
  const lastDetectedPersonaRef = useRef<string | null>(null);

  useEffect(() => {
    
    const firstWord = inputValue.trim().split(/\s+/)[0] || '';
    if (!firstWord) {
      lastDetectedPersonaRef.current = null;
      return;
    }

    const matchedPersona = personas.find(p => p.name === firstWord);

    
    

    if (
      matchedPersona &&
      matchedPersona.name !== selectedPersona &&
      matchedPersona.name !== lastDetectedPersonaRef.current
    ) {
      lastDetectedPersonaRef.current = matchedPersona.name;
      updatePersona(matchedPersona.name);
    }

    if (!matchedPersona || matchedPersona.name !== lastDetectedPersonaRef.current) {
      lastDetectedPersonaRef.current = null;
    }
  }, [inputValue, selectedPersona, personas, updatePersona]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    const handleWindowFocus = () => {
      inputRef.current?.focus();
    };

    window.addEventListener('focus', handleWindowFocus);
    return () => window.removeEventListener('focus', handleWindowFocus);
  }, []);

  
  useEffect(() => {
    const textarea = inputRef.current;
    if (textarea) {
      
      textarea.style.height = 'auto';

      
      const maxHeight = 200; 
      const newHeight = Math.min(textarea.scrollHeight, maxHeight);
      textarea.style.height = `${newHeight}px`;

      
      textarea.style.overflowY = textarea.scrollHeight > maxHeight ? 'auto' : 'hidden';
    }
  }, [inputValue]);

  useEffect(() => {
    const loadModels = async () => {
      setModelsLoading(true);
      try {
        const { data, error } = await supabase
          .from('ai_models')
          .select('*')
          .eq('is_active', true)
          .order('display_order', { ascending: true });

        if (error) {
          console.error('Failed to load models:', error);
          setModels([]);
          return;
        }

        setModels(data || []);
      } catch (err) {
        console.error('Error loading models:', err);
        setModels([]);
      } finally {
        setModelsLoading(false);
      }
    };

    loadModels();
  }, []);

  useEffect(() => {
    const loadPersonas = async () => {
      setPersonasLoading(true);
      try {
        const { data, error } = await supabase
          .from('personas')
          .select('*')
          .eq('is_active', true)
          .order('display_order', { ascending: true });

        if (error) {
          console.error('Failed to load personas:', error);
          setPersonas([]);
          return;
        }

        setPersonas(data || []);
      } catch (err) {
        console.error('Error loading personas:', err);
        setPersonas([]);
      } finally {
        setPersonasLoading(false);
      }
    };

    loadPersonas();
  }, []);

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSendMessage();
    }
  };

  const handlePaste = async (e: React.ClipboardEvent) => {
    const clipboardData = e.clipboardData;
    const pastedText = clipboardData.getData('text/plain').trim();

    if (!pastedText) return;

    if (isGoogleUrl(pastedText)) {
      e.preventDefault();
      const validationResult = validateGoogleUrl(pastedText);

      if (validationResult.isValid && validationResult.type && validationResult.documentId) {
        if (onGoogleUrlSubmit) {
          onGoogleUrlSubmit(pastedText, validationResult.type, validationResult.documentId, undefined);
        } else {
          console.log('Valid Google URL detected:', validationResult);
        }
      } else {
        console.error('Invalid Google URL:', validationResult.error);
      }
      return;
    }

  };

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!e.currentTarget.contains(e.relatedTarget as Node)) {
      setIsDragOver(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);

    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      const supportedTypes = Object.values(FILE_TYPE_REGISTRY)
        .filter(ft => ft.isSupported)
        .map(ft => `.${ft.extension}`);

      files.forEach(file => {
        const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();

        if (supportedTypes.includes(fileExtension)) {
          onFileSelect(file);
        }
      });
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const truncateFilename = (filename: string, maxLength: number = 24) => {
    if (filename.length <= maxLength) return filename;

    const lastDotIndex = filename.lastIndexOf('.');
    if (lastDotIndex === -1) {
      return filename.substring(0, maxLength - 3) + '...';
    }

    const extension = filename.substring(lastDotIndex);
    const nameWithoutExt = filename.substring(0, lastDotIndex);

    const availableSpace = maxLength - extension.length - 3;

    if (availableSpace <= 0) {
      return '...' + extension;
    }

    if (nameWithoutExt.length <= availableSpace) {
      return filename;
    }

    const keepFromStart = Math.floor(availableSpace * 0.7);
    const keepFromEnd = availableSpace - keepFromStart;

    return nameWithoutExt.substring(0, keepFromStart) +
           '...' +
           (keepFromEnd > 0 ? nameWithoutExt.substring(nameWithoutExt.length - keepFromEnd) : '') +
           extension;
  };

  useEffect(() => {
    const fetchSharedFiles = async () => {
      if (!sharedFilesDropdownOpen || !user) return;

      setIsLoadingSharedFiles(true);

      try {
        const result = await listSharedGoogleFiles();

        if (!result.success || !result.files) {
          console.error('Failed to fetch shared files:', result.error);
          setSharedFiles([]);
          return;
        }

        const receivedFileIds = await getReceivedGoogleFileIds(user.id);

        const newFiles = result.files.filter(
          file => !receivedFileIds.includes(file.id)
        );

        setSharedFiles(newFiles);

      } catch (error) {
        console.error('Error fetching shared files:', error);
        setSharedFiles([]);
      } finally {
        setIsLoadingSharedFiles(false);
      }
    };

    fetchSharedFiles();
  }, [sharedFilesDropdownOpen, user]);

  const toggleAutoScroll = useCallback(() => {
    console.log('🔵 toggleAutoScroll called, isAutoScrollingRef:', isAutoScrollingRef.current);

    if (isAutoScrollingRef.current) {
      
      console.log('🔴 Stopping auto-scroll');
      if (autoScrollFrameRef.current) {
        cancelAnimationFrame(autoScrollFrameRef.current);
        autoScrollFrameRef.current = null;
      }
      isAutoScrollingRef.current = false;
      setIsAutoScrolling(false);
    } else {
      
      console.log('🟢 Starting auto-scroll');
      const container = document.querySelector('.overflow-y-auto');
      console.log('📦 Container found:', container);
      if (!container) {
        console.error('❌ No container found!');
        return;
      }

      isAutoScrollingRef.current = true;
      setIsAutoScrolling(true);
      lastScrollTimeRef.current = performance.now();
      const startTime = performance.now();

      let accumulatedScroll = 0;
      let scrollAttempts = 0;
      const scroll = (currentTime: number) => {
        if (!isAutoScrollingRef.current) {
          console.log('🛑 Auto-scroll stopped by ref');
          return;
        }

        const deltaTime = currentTime - lastScrollTimeRef.current;
        const elapsedTime = currentTime - startTime;

        
        const cycleTime = elapsedTime % 15000;
        const isScrolling = cycleTime < 5000;

        if (isScrolling) {
          
          const scrollAmount = (30 * deltaTime) / 1000;

          
          accumulatedScroll += scrollAmount;

          
          if (accumulatedScroll >= 1) {
            const scrollElement = container as HTMLElement;

            
            scrollElement.style.scrollBehavior = 'auto';

            
            const pixelsToScroll = Math.floor(accumulatedScroll);
            container.scrollTop += pixelsToScroll;

            
            accumulatedScroll -= pixelsToScroll;
          }
        }

        lastScrollTimeRef.current = currentTime;

        autoScrollFrameRef.current = requestAnimationFrame(scroll);
      };

      console.log('🚀 Starting requestAnimationFrame loop');
      autoScrollFrameRef.current = requestAnimationFrame(scroll);
    }
  }, []);

  
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && isAutoScrolling) {
        toggleAutoScroll();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isAutoScrolling]);

  
  useEffect(() => {
    return () => {
      if (autoScrollFrameRef.current) {
        cancelAnimationFrame(autoScrollFrameRef.current);
      }
    };
  }, []);

  const generateAcceptString = (): string => {
    const supportedExtensions = Object.values(FILE_TYPE_REGISTRY)
      .filter(fileType => fileType.isSupported)
      .map(fileType => `.${fileType.extension}`);
    return supportedExtensions.join(',');
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    files.forEach(file => onFileSelect(file));
    
    e.target.value = '';
  };

  const navigateTurns = (direction: 'up' | 'down') => {
    
    const wasAutoScrolling = isAutoScrolling;
    if (isAutoScrolling) {
      toggleAutoScroll();
    }

    
    const container = document.querySelector('.overflow-y-auto');
    if (!container) return;

    
    const allMessages = Array.from(document.querySelectorAll('[data-message-id]'));
    const bossMessages = allMessages.filter(el => {
      const senderSpan = el.querySelector('span');
      return senderSpan?.textContent === 'Boss';
    });

    if (bossMessages.length === 0) return;

    const lineHeight = 24; 
    const currentScrollTop = container.scrollTop;
    const containerRect = container.getBoundingClientRect();
    const viewportHeight = containerRect.height;
    const viewportTop = containerRect.top;

    
    let currentTopIndex = -1;

    
    const isAtBottom = currentScrollTop + containerRect.height >= container.scrollHeight - 10;

    if (isAtBottom) {
      
      currentTopIndex = bossMessages.length - 1;
    } else {
      
      for (let i = bossMessages.length - 1; i >= 0; i--) {
        const message = bossMessages[i] as HTMLElement;
        const rect = message.getBoundingClientRect();

        
        if (rect.top <= viewportTop + lineHeight + 50) {
          currentTopIndex = i;
          break;
        }
      }

      
      if (currentTopIndex === -1) {
        currentTopIndex = 0;
      }
    }

    const currentBoss = bossMessages[currentTopIndex] as HTMLElement;
    const currentBossTop = currentBoss.offsetTop;
    const targetScrollPosition = currentBossTop - lineHeight;
    const isAlreadyPositioned = Math.abs(currentScrollTop - targetScrollPosition) < 10;

    let targetIndex = currentTopIndex;

    if (direction === 'up') {
      
      
      if (isAlreadyPositioned && currentTopIndex > 0) {
        targetIndex = currentTopIndex - 1;
      }
      
      else if (currentTopIndex === bossMessages.length - 1) {
        const lastBossTop = currentBoss.offsetTop;
        const containerScrollHeight = container.scrollHeight;
        const remainingContentHeight = containerScrollHeight - lastBossTop;

        
        if (remainingContentHeight < viewportHeight && currentTopIndex > 0) {
          targetIndex = currentTopIndex - 1;
        }
      }
    } else {
      
      
      if (wasAutoScrolling || isAlreadyPositioned) {
        if (currentTopIndex < bossMessages.length - 1) {
          targetIndex = currentTopIndex + 1;
        } else {
          
          return;
        }
      }

    }

    const targetBoss = bossMessages[targetIndex] as HTMLElement;
    const elementTop = targetBoss.offsetTop;
    const maxScrollTop = container.scrollHeight - container.clientHeight;
    const targetScrollTop = Math.min(elementTop - lineHeight, maxScrollTop);
    container.scrollTo({ top: targetScrollTop, behavior: 'auto' });
  };

  
  
  const handlePersonaChange = useCallback((newPersona: string) => {
    
    updatePersona(newPersona);

    
    setInputValue(newPersona + ' ');

    
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        if (inputRef.current) {
          inputRef.current.focus();
          
          const cursorPos = newPersona.length + 1;
          inputRef.current.setSelectionRange(cursorPos, cursorPos);
        }
      });
    });
  }, [updatePersona, setInputValue]);

  const handleSharedFilesSubmit = (selectedFiles: SharedGoogleFile[]) => {
    selectedFiles.forEach(file => {
      const url = `https://docs.google.com/${file.type}/d/${file.id}/edit`;
      if (onGoogleUrlSubmit) {
        onGoogleUrlSubmit(url, file.type, file.id, file.name);
      }
    });

    setSharedFiles(prevFiles =>
      prevFiles.filter(file => !selectedFiles.some(selected => selected.id === file.id))
    );
  };

  return (
    <div
      className={`border-t border-chat-border bg-secondary py-2 transition-all duration-300 relative ${
        isDragOver ? 'bg-accent/10 shadow-[0_0_20px_rgba(223,208,184,0.3)] border-accent/50' : ''
      }`}
      style={{ paddingLeft: '16px', paddingRight: '16px' }}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      <div className="mx-auto space-y-1" style={{ maxWidth: '632px' }}>

        <div className="relative h-6 flex items-center">
          <div className="absolute left-[11px] flex items-center">
            {}
            <input
              ref={fileInputRef}
              type="file"
              onChange={handleFileInputChange}
              className="absolute -left-[9999px] w-0 h-0 opacity-0"
              accept={generateAcceptString()}
              multiple
            />
            {}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              disabled={isLoading}
              className="h-6 w-6 p-0 text-chat-label hover:text-foreground hover:shadow-[0_0_8px_rgba(223,208,184,0.5)] transition-all duration-200 disabled:opacity-30 disabled:cursor-not-allowed"
              title="Attach files"
            >
              <Paperclip className="!h-3 !w-3" />
            </Button>
            <SharedFilesDropdown
              files={sharedFiles}
              onFilesSelect={handleSharedFilesSubmit}
              isLoading={isLoadingSharedFiles}
              open={sharedFilesDropdownOpen}
              onOpenChange={setSharedFilesDropdownOpen}
            />
            <FilesDropdown
              onFilesActivate={onFilesActivate}
              onFileDelete={onFileDelete}
            />
          </div>

          <div className="absolute left-[95px]">
            <Select
              value={settingsModel}
              onValueChange={updateModel}
              open={modelDropdownOpen}
              onOpenChange={setModelDropdownOpen}
              disabled={modelsLoading}
            >
              <SelectTrigger
                className={`w-auto min-w-48 h-6 bg-transparent border-none text-chat-label font-menlo px-2 flex flex-row-reverse justify-end gap-1 outline-none focus:outline-none focus:ring-0 focus-visible:ring-0 focus-visible:ring-offset-0 active:outline-none active:border-0 data-[state=open]:outline-none data-[state=open]:border-0 [&:focus-visible]:outline-none [&:active]:outline-none ${modelDropdownOpen ? '[&>svg]:rotate-180' : ''} [&>svg]:transition-transform [&>svg]:duration-200`}
                style={{ fontSize: '10px' }}
                onMouseDown={(e: React.MouseEvent) => {
                  e.currentTarget.blur();
                }}
              >
                <span>
                  {models.find(m => m.model_name === settingsModel)?.display_name
                    ?.replace('Claude ', '')
                    .replace('Maverick', 'Mav') || settingsModel}
                </span>
              </SelectTrigger>
              <SelectContent className="z-50 bg-card border-chat-border shadow-lg" align="start" sideOffset={5}>
                {models.map((model) => (
                  <SelectItem
                    key={model.id}
                    value={model.model_name}
                    className="font-menlo py-1 hover:bg-accent focus:bg-accent"
                    style={{ fontSize: '10px' }}
                  >
                    {model.display_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="absolute left-[180px]">
            <Select
              value={selectedPersona}
              onValueChange={handlePersonaChange}
              open={personaDropdownOpen}
              onOpenChange={setPersonaDropdownOpen}
              disabled={personasLoading}
            >
              <SelectTrigger
                className={`w-auto min-w-48 h-6 bg-transparent border-none text-chat-label font-menlo px-2 flex flex-row-reverse justify-end gap-1 outline-none focus:outline-none focus:ring-0 focus-visible:ring-0 focus-visible:ring-offset-0 active:outline-none active:border-0 data-[state=open]:outline-none data-[state=open]:border-0 [&:focus-visible]:outline-none [&:active]:outline-none ${personaDropdownOpen ? '[&>svg]:rotate-180' : ''} [&>svg]:transition-transform [&>svg]:duration-200`}
                style={{ fontSize: '10px' }}
                onMouseDown={(e: React.MouseEvent) => {
                  e.currentTarget.blur();
                }}
              >
                <span>{selectedPersona}</span>
              </SelectTrigger>
              <SelectContent className="z-50 bg-card border-chat-border shadow-lg" align="start" sideOffset={5}>
                {personas.map((persona) => (
                  <SelectItem
                    key={persona.id}
                    value={persona.name}
                    className="font-menlo py-1 hover:bg-accent focus:bg-accent"
                    style={{ fontSize: '10px' }}
                  >
                    <span>{persona.name}<span style={{ marginLeft: '10px', opacity: 0.6 }}>{PERSONA_CONFIGS[persona.name.toLowerCase()]?.role || persona.role}</span></span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {}
          <div className="absolute left-[265px]">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigateTurns('up')}
              disabled={isLoading}
              className="h-6 w-6 p-0 text-chat-label hover:text-foreground hover:shadow-[0_0_8px_rgba(223,208,184,0.5)] transition-all duration-200 disabled:opacity-30 disabled:cursor-not-allowed outline-none focus:outline-none focus:ring-0 focus-visible:ring-0 focus-visible:ring-offset-0 [&:focus-visible]:outline-none [&:active]:outline-none"
              title="Previous turn"
            >
              <ChevronsUp className="!h-3 !w-3" />
            </Button>
          </div>

          {}
          <div className="absolute left-[289px]">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigateTurns('down')}
              disabled={isLoading}
              className="h-6 w-6 p-0 text-chat-label hover:text-foreground hover:shadow-[0_0_8px_rgba(223,208,184,0.5)] transition-all duration-200 disabled:opacity-30 disabled:cursor-not-allowed outline-none focus:outline-none focus:ring-0 focus-visible:ring-0 focus-visible:ring-offset-0 [&:focus-visible]:outline-none [&:active]:outline-none"
              title="Next turn"
            >
              <ChevronsDown className="!h-3 !w-3" />
            </Button>
          </div>

          {}
          <div className="absolute left-[313px]">
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('🟡 Button clicked');
                toggleAutoScroll();
              }}
              className="h-6 w-6 p-0 text-chat-label hover:text-foreground hover:shadow-[0_0_8px_rgba(223,208,184,0.5)] transition-all duration-200 outline-none focus:outline-none focus:ring-0 focus-visible:ring-0 focus-visible:ring-offset-0 [&:focus-visible]:outline-none [&:active]:outline-none"
              title="Auto-scroll"
            >
              <ArrowDown className="!h-3 !w-3" />
            </Button>
          </div>

          {}
          <div className="absolute left-[337px]">
            <Button
              variant="ghost"
              size="sm"
              onClick={onGlobalMiniChatOpen}
              className="h-6 w-6 p-0 text-chat-label hover:text-foreground hover:shadow-[0_0_8px_rgba(223,208,184,0.5)] transition-all duration-200 outline-none focus:outline-none focus:ring-0 focus-visible:ring-0 focus-visible:ring-offset-0 [&:focus-visible]:outline-none [&:active]:outline-none"
              title="Mini chat"
            >
              <MessageSquare className="!h-3 !w-3" />
            </Button>
          </div>

          {}
          {tokenPercentage !== null && tokenPercentage !== undefined && (
            <div className="absolute" style={{ right: '110px' }}>
              <div className="text-chat-label font-menlo px-2" style={{ fontSize: '10px' }}>
                {tokenPercentage}%
              </div>
            </div>
          )}

          <div className="absolute right-0">
            <Button
              variant="ghost"
              size="sm"
              onClick={onNuke}
              className="h-6 w-6 p-0 text-destructive hover:text-foreground hover:shadow-[0_0_8px_rgba(223,208,184,0.5)] transition-all duration-0"
              title="Delete all data (no confirmation)"
              style={{ marginRight: '76px' }}
            >
              <Flame className="!h-3 !w-3" />
            </Button>
          </div>
        </div>

        <div className="flex items-start gap-3" style={{ marginLeft: '-16px', marginRight: '-16px', paddingLeft: '16px', paddingRight: '16px' }}>
          <textarea
            ref={inputRef}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            onPaste={handlePaste}
            placeholder="Type your message..."
            rows={1}
            className="bg-card font-sans focus-visible:ring-0 focus-visible:ring-offset-0 focus-visible:shadow-[0_0_8px_rgba(217,133,107,0.5)] focus:outline-none transition-shadow duration-200 py-2 flex-1 placeholder:text-prose-body resize-none overflow-hidden rounded-md"
            style={{
              borderWidth: '1px',
              borderStyle: 'solid',
              borderColor: 'rgba(217, 133, 107, 0.5)',
              fontSize: '11px',
              color: 'rgb(210, 213, 219)',
              minHeight: '36px',
              maxHeight: '200px',
              paddingLeft: '28px'
            }}
          />

          <Button
            onClick={onSendMessage}
            disabled={isLoading || (!inputValue.trim() && attachments.length === 0)}
            className="font-menlo text-sm h-9 min-w-16 hover:opacity-90"
            style={{ backgroundColor: 'rgb(217, 133, 107)', color: 'hsl(0, 0%, 10%)' }}
          >
            {isLoading ? '...' : 'Send'}
          </Button>
        </div>
      </div>

      {}
      {isGlobalMiniChatOpen && (
        <>
          {}
          <div
            className="fixed inset-0 bg-black z-40"
            style={{ opacity: 0.6 }}
            onClick={onGlobalMiniChatClose}
          />

          {}
          <div
            className="fixed z-50"
            style={{
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)'
            }}
          >
            <div
              className="bg-card rounded-lg shadow-2xl"
              style={{
                width: '350px',
                maxHeight: '600px',
                display: 'flex',
                flexDirection: 'column'
              }}
            >
            {}
            <div className="flex-1 p-4 overflow-y-auto space-y-5" style={{ maxHeight: '500px', background: 'rgba(0, 0, 0, 0.3)' }}>
              {globalMiniChatMessages.length === 0 && (
                <div className="text-chat-label text-center py-12" style={{ fontSize: '11px' }}>
                  Ask a quick question...
                </div>
              )}

              {globalMiniChatMessages.map((msg, index) => (
                <div key={index}>
                  <div
                    className="font-medium mb-2 border-b border-chat-border pb-1.5"
                    style={msg.sender === 'Boss' ? { borderBottomColor: 'rgb(217, 133, 107)', borderBottomWidth: '0.5px' } : undefined}
                  >
                    <span
                      className="bg-card px-1.5 py-0.5 rounded"
                      style={{
                        fontSize: '11px',
                        color: msg.sender === 'Boss' ? 'rgb(217, 133, 107)' : 'inherit'
                      }}
                    >
                      {msg.sender}
                    </span>
                  </div>
                  <div className="leading-relaxed pl-2" style={{ fontSize: '11px', color: 'rgb(210, 213, 219)' }}>
                    {msg.text}
                  </div>
                </div>
              ))}

              {isGlobalMiniChatLoading && (
                <div style={{ fontSize: '11px' }}>
                  {'Thinking...'.split('').map((char, index) => (
                    <span
                      key={index}
                      className="inline-block animate-pulse"
                      style={{
                        animationDelay: `${index * 100}ms`,
                        animationDuration: '1s'
                      }}
                    >
                      {char === ' ' ? '\u00A0' : char}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {}
            <div className="p-3 border-t border-chat-border">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Ask a question..."
                  value={globalMiniChatInput}
                  onChange={(e) => setGlobalMiniChatInput(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      onGlobalMiniChatSend();
                    }
                  }}
                  disabled={isGlobalMiniChatLoading}
                  className="flex-1 bg-card border-none outline-none placeholder:text-prose-body px-2 py-1 rounded"
                  style={{
                    fontSize: '11px',
                    border: '0.5px solid rgb(217, 133, 107)',
                    color: 'rgb(210, 213, 219)'
                  }}
                  autoFocus
                />
                <button
                  onClick={onGlobalMiniChatSend}
                  disabled={isGlobalMiniChatLoading || !globalMiniChatInput.trim()}
                  className="px-3 py-1 rounded transition-colors disabled:opacity-50"
                  style={{
                    background: 'rgb(217, 133, 107)',
                    color: 'rgb(20, 21, 23)',
                    fontSize: '11px'
                  }}
                >
                  Send
                </button>
              </div>
            </div>
          </div>
        </div>
        </>
      )}

    </div>
  );
};

export default InputArea;
