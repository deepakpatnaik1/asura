import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';

interface MarkdownRendererProps {
  children: string;
}

const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ children }) => {
  if (children.trim() === 'Thinking...' || children.trim() === 'Rethinking...') {
    const text = children.trim();
    return (
      <div className="mb-1">
        {text.split('').map((char, charIndex) => (
          <span
            key={charIndex}
            className="inline-block animate-pulse"
            style={{
              animationDelay: `${charIndex * 100}ms`,
              animationDuration: '1s'
            }}
          >
            {char === ' ' ? '\u00A0' : char}
          </span>
        ))}
      </div>
    );
  }

  return (
    <div className="prose prose-invert max-w-none [&_ul]:list-disc [&_ol]:list-decimal [&_p]:mb-2 [&_hr]:hidden [&_p]:font-normal" style={{ fontSize: '11px' }}>
      <style>{`
        .prose li::marker {
          color: rgb(217, 133, 107);
        }
        .prose p {
          font-weight: normal;
        }
      `}</style>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          
          h1: ({ children }) => <span className="font-normal">{children}</span>,
          h2: ({ children }) => <span className="font-normal">{children}</span>,
          h3: ({ children }) => <span className="font-normal">{children}</span>,
          h4: ({ children }) => <span className="font-normal">{children}</span>,
          h5: ({ children }) => <span className="font-normal">{children}</span>,
          h6: ({ children }) => <span className="font-normal">{children}</span>,
          
          hr: () => null,
          
          strong: ({ children }) => <strong className="font-bold" style={{ color: 'rgb(217, 133, 107)' }}>{children}</strong>,
          code({ node, inline, className, children, ...props }) {
            const match = /language-(\w+)/.exec(className || '');
            return !inline && match ? (
              <SyntaxHighlighter
                style={oneDark}
                language={match[1]}
                PreTag="div"
                className="rounded-md !bg-muted !text-sm"
                customStyle={{
                  backgroundColor: 'hsl(var(--muted))',
                  padding: '1rem',
                  margin: '0.5rem 0',
                  borderRadius: '0.375rem',
                  fontSize: '0.875rem',
                  fontFamily: 'Menlo, Monaco, Consolas, monospace',
                }}
                {...props}
              >
                {String(children).replace(/\n$/, '')}
              </SyntaxHighlighter>
            ) : (
              <code
                className="bg-muted text-foreground px-1.5 py-0.5 rounded text-xs"
                {...props}
              >
                {children}
              </code>
            );
          },
        }}
      >
        {children}
      </ReactMarkdown>
    </div>
  );
};

export default MarkdownRenderer;