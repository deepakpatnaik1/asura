import { useState, useEffect, useRef } from 'react';
import { Circle, CheckCircle2, Plus, X, Star, ChevronDown, ChevronRight, Trash2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useTodoLists } from '@/hooks/useTodoLists';
import { useTodos } from '@/hooks/useTodos';
import type { Database } from '@/integrations/supabase/types';
import type { TodoList, Todo as TodoItem } from '@/types/todos';

type CalendarEvent = Database['public']['Tables']['calendar_events']['Row'];

interface DayEvent {
  id: string;
  dayNumber: string;
  dayName: string;
  events: {
    time: string;
    title: string;
    color?: 'blue' | 'orange';
  }[];
}

interface CondensedEvent {
  day: string;
  title: string;
}

interface MonthSection {
  title: string;
  events: CondensedEvent[];
}

interface Reminder {
  id: string;
  text: string;
}

type PaneType = 'blue' | 'orange' | 'brown' | 'yellow' | 'emerald' | 'red';


const paneConfig: Record<PaneType, { fullWidth: boolean }> = {
  blue: { fullWidth: false },     
  orange: { fullWidth: true },    
  brown: { fullWidth: true },     
  yellow: { fullWidth: false },   
  emerald: { fullWidth: true },   
  red: { fullWidth: true },       
};

interface WhiteboardProps {
  activePane: PaneType | null;
  togglePane: (pane: PaneType) => void;
}

const Whiteboard = ({ activePane, togglePane }: WhiteboardProps) => {
  const { user } = useAuth();

  
  const {
    lists,
    isLoading: isLoadingLists,
    createList,
    updateList,
    deleteList,
    toggleCollapse
  } = useTodoLists();
  const {
    todos,
    isLoading: isLoadingTodos,
    createTodo,
    updateTodo,
    deleteTodo,
    moveTodo,
    toggleComplete,
    toggleStar,
    reorderTodos,
    refreshTodos
  } = useTodos();

  
  const [editingTodoId, setEditingTodoId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState('');
  const todoInputRef = useRef<HTMLInputElement>(null);

  
  const optimisticTodoIdRef = useRef<string | null>(null);

  
  const [editingListId, setEditingListId] = useState<string | null>(null);
  const [editingListName, setEditingListName] = useState('');
  const listNameInputRef = useRef<HTMLInputElement>(null);

  
  const optimisticListIdRef = useRef<string | null>(null);

  
  const [hoveredListId, setHoveredListId] = useState<string | null>(null);

  
  const [expandedCompleted, setExpandedCompleted] = useState<Set<string>>(new Set());

  
  useEffect(() => {
    if (editingListId && listNameInputRef.current) {
      listNameInputRef.current.select();
    }
  }, [editingListId]);

  
  useEffect(() => {
    if (editingTodoId && todoInputRef.current) {
      todoInputRef.current.select();
    }
  }, [editingTodoId]);

  
  useEffect(() => {
    if (editingListId && optimisticListIdRef.current === editingListId) {
      
      const listExists = lists.some(list => list.id === editingListId);
      if (!listExists && lists.length > 0) {
        
        const newestList = lists.reduce((newest, list) =>
          list.position > newest.position ? list : newest
        , lists[0]);

        
        const createdAt = new Date(newestList.created_at).getTime();
        const now = Date.now();
        if (now - createdAt < 2000) {
          setEditingListId(newestList.id);
          optimisticListIdRef.current = null;
        }
      }
    }
  }, [lists, editingListId]);

  
  useEffect(() => {
    if (editingTodoId && optimisticTodoIdRef.current === editingTodoId) {
      
      const todoExists = todos.some(todo => todo.id === editingTodoId);
      if (!todoExists && todos.length > 0) {
        
        const newestTodo = todos.reduce((newest, todo) => {
          const newestTime = new Date(newest.created_at).getTime();
          const todoTime = new Date(todo.created_at).getTime();
          return todoTime > newestTime ? todo : newest;
        }, todos[0]);

        
        const createdAt = new Date(newestTodo.created_at).getTime();
        const now = Date.now();
        if (now - createdAt < 2000) {
          console.log('Updating editingTodoId from', editingTodoId, 'to', newestTodo.id);
          setEditingTodoId(newestTodo.id);
          setEditingText(newestTodo.text);
          optimisticTodoIdRef.current = null;
        }
      }
    }
  }, [todos, editingTodoId]);

  
  type DragSource =
    | { type: 'list'; listId: string; index: number }
    | { type: 'calendar'; date: string; index: number };

  const [draggedTodo, setDraggedTodo] = useState<{
    todo: TodoItem;
    source: DragSource;
  } | null>(null);

  const [dropTarget, setDropTarget] = useState<
    | { type: 'list'; list: string; index: number }
    | { type: 'calendar'; date: string }
    | null
  >(null);

  
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>([]);
  const [isLoadingEvents, setIsLoadingEvents] = useState(true);
  const [isSyncingCalendar, setIsSyncingCalendar] = useState(false);

  
  useEffect(() => {
    const fetchCalendarEvents = async () => {
      if (!user?.id) return;

      setIsLoadingEvents(true);
      console.log('[Whiteboard] Fetching calendar events for user:', user.id);
      const { data, error } = await supabase
        .from('calendar_events')
        .select('*')
        .eq('user_id', user.id)
        .order('start_time', { ascending: true });

      if (error) {
        console.error('[Whiteboard] Error fetching calendar events:', error);
      } else {
        console.log('[Whiteboard] Fetched calendar events:', data?.length || 0, 'events');
        setCalendarEvents(data || []);
      }
      setIsLoadingEvents(false);
    };

    fetchCalendarEvents();
  }, [user?.id]);

  
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel('calendar_events_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'calendar_events',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            setCalendarEvents((prev) => [...prev, payload.new as CalendarEvent]);
          } else if (payload.eventType === 'UPDATE') {
            setCalendarEvents((prev) =>
              prev.map((event) =>
                event.id === (payload.new as CalendarEvent).id
                  ? (payload.new as CalendarEvent)
                  : event
              )
            );
          } else if (payload.eventType === 'DELETE') {
            setCalendarEvents((prev) =>
              prev.filter((event) => event.id !== (payload.old as CalendarEvent).id)
            );
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  
  const syncCalendar = async () => {
    if (!user?.id) return;

    setIsSyncingCalendar(true);
    try {
      const session = await supabase.auth.getSession();
      const token = session.data.session?.access_token;

      if (!token) {
        console.error('No auth token available');
        return;
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/list-calendar-events`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        }
      );

      const result = await response.json();
      console.log('Calendar sync result:', result);

      if (result.success) {
        
        console.log('Calendar synced successfully, refreshing events...');
        const { data, error } = await supabase
          .from('calendar_events')
          .select('*')
          .eq('user_id', user.id)
          .order('start_time', { ascending: true });

        if (!error && data) {
          setCalendarEvents(data);
          console.log('Calendar events refreshed:', data.length, 'events');
        }
      } else {
        console.error('Calendar sync failed:', result.error);
      }
    } catch (error) {
      console.error('Error syncing calendar:', error);
    } finally {
      setIsSyncingCalendar(false);
    }
  };

  
  const formatEventTime = (event: CalendarEvent): string => {
    if (event.is_all_day) {
      return ''; 
    }
    const date = new Date(event.start_time);
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
  };

  
  const formatDateToISO = (date: Date): string => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  
  const getUpcomingDays = (): (DayEvent & { isoDate: string })[] => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const upcomingDays: (DayEvent & { isoDate: string })[] = [];

    for (let i = 0; i < 7; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);

      const dayNumber = date.getDate().toString();
      let dayName = '';
      if (i === 0) dayName = 'Today';
      else if (i === 1) dayName = 'Tomorrow';
      else dayName = dayNames[date.getDay()];

      const isoDate = formatDateToISO(date);

      
      const dayEvents = calendarEvents
        .filter(event => {
          const eventDate = new Date(event.start_time);
          eventDate.setHours(0, 0, 0, 0);
          return eventDate.getTime() === date.getTime();
        })
        .map(event => ({
          time: formatEventTime(event),
          title: event.title,
          isAllDay: event.is_all_day,
          color: undefined as 'blue' | 'orange' | undefined,
        }));

      upcomingDays.push({
        id: i.toString(),
        dayNumber,
        dayName,
        events: dayEvents,
        isoDate,
      });
    }

    return upcomingDays;
  };

  
  const getMonthEvents = (startDay: number, endDay: number, monthOffset: number): MonthSection => {
    const today = new Date();
    const targetMonth = new Date(today.getFullYear(), today.getMonth() + monthOffset, 1);

    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const monthName = monthNames[targetMonth.getMonth()];

    let title = monthName;
    if (startDay > 1 || endDay < 31) {
      title = `${monthName} ${startDay}-${endDay}`;
    }

    const events: CondensedEvent[] = calendarEvents
      .filter(event => {
        const eventDate = new Date(event.start_time);
        return (
          eventDate.getMonth() === targetMonth.getMonth() &&
          eventDate.getFullYear() === targetMonth.getFullYear() &&
          eventDate.getDate() >= startDay &&
          eventDate.getDate() <= endDay
        );
      })
      .map(event => ({
        day: new Date(event.start_time).getDate().toString().padStart(2, '0'),
        title: event.title,
      }));

    return { title, events };
  };

  const [reminders] = useState<Reminder[]>([
    { id: '1', text: 'Monday forcing function active' },
    { id: '2', text: 'Talk to users, not code' },
  ]);

  
  const getTodosForList = (listId: string): TodoItem[] => {
    return todos
      .filter(todo => todo.list_id === listId && !todo.completed)
      .sort((a, b) => a.position - b.position);
  };

  
  const getTodosForCalendarDate = (dateString: string): TodoItem[] => {
    return todos
      .filter(todo => todo.calendar_date === dateString && !todo.completed)
      .sort((a, b) => a.position - b.position);
  };

  
  const getCompletedTodosForList = (listId: string): TodoItem[] => {
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const cutoffTime = sevenDaysAgo.getTime();

    return todos
      .filter(todo => {
        if (todo.list_id !== listId || !todo.completed || !todo.completed_at) {
          return false;
        }
        const completedTime = new Date(todo.completed_at).getTime();
        return completedTime >= cutoffTime;
      })
      .sort((a, b) => {
        
        const timeA = a.completed_at ? new Date(a.completed_at).getTime() : 0;
        const timeB = b.completed_at ? new Date(b.completed_at).getTime() : 0;
        return timeB - timeA;
      });
  };

  
  const handleAddTodo = async (listId: string) => {
    console.log('=== handleAddTodo called ===');
    const listTodos = getTodosForList(listId);
    const nextPosition = listTodos.length > 0
      ? Math.max(...listTodos.map(t => t.position)) + 1
      : 0;

    console.log('Creating todo with position:', nextPosition);
    const newTodo = await createTodo({
      list_id: listId,
      text: 'New task',
      position: nextPosition
    });

    console.log('New todo created:', newTodo);
    console.log('Setting editing state for todo:', newTodo.id);

    
    optimisticTodoIdRef.current = newTodo.id;

    
    setEditingTodoId(newTodo.id);
    setEditingText(newTodo.text);
  };

  
  const startEditing = (todo: TodoItem) => {
    setEditingTodoId(todo.id);
    setEditingText(todo.text);
  };

  
  const saveEdit = async (todoId: string) => {
    if (editingText.trim()) {
      
      const atIndex = editingText.indexOf('@');
      if (atIndex !== -1) {
        
        const taskText = editingText.substring(0, atIndex).trim();
        const dateText = editingText.substring(atIndex + 1).trim();

        if (taskText) {
          await updateTodo(todoId, {
            text: taskText,
            date_text: dateText || null
          });
        }
      } else {
        
        await updateTodo(todoId, { text: editingText.trim() });
      }
    }
    setEditingTodoId(null);
    setEditingText('');
  };

  
  const cancelEdit = async () => {
    
    if (editingTodoId && (editingText === 'New task' || editingText.trim() === '')) {
      await deleteTodo(editingTodoId);
    }
    setEditingTodoId(null);
    setEditingText('');
  };

  
  const handleUpdateDate = async (todoId: string, dateText: string) => {
    await updateTodo(todoId, { date_text: dateText || null });
  };

  
  const startEditingList = (list: TodoList) => {
    setEditingListId(list.id);
    setEditingListName(list.name);
  };

  
  const saveListName = async (listId: string) => {
    if (editingListName.trim() && editingListName !== lists.find(l => l.id === listId)?.name) {
      await updateList(listId, { name: editingListName.trim() });
    }
    setEditingListId(null);
    setEditingListName('');
  };

  
  const cancelListEdit = async () => {
    
    if (editingListId && (editingListName === 'New List' || editingListName.trim() === '')) {
      await deleteList(editingListId);
    }
    setEditingListId(null);
    setEditingListName('');
  };

  
  const handleDeleteList = async (listId: string) => {
    await deleteList(listId);
  };

  
  const handleAddList = async () => {
    try {
      const defaultName = 'New List';
      const newList = await createList(defaultName);

      
      optimisticListIdRef.current = newList.id;

      
      
      setEditingListId(newList.id);
      setEditingListName(newList.name);

      
      requestAnimationFrame(() => {
        listNameInputRef.current?.select();
      });
    } catch (error) {
      console.error('Error adding list:', error);
    }
  };

  
  const toggleCompletedSection = (listId: string) => {
    setExpandedCompleted(prev => {
      const newSet = new Set(prev);
      if (newSet.has(listId)) {
        newSet.delete(listId);
      } else {
        newSet.add(listId);
      }
      return newSet;
    });
  };

  
  const handleListDragStart = (e: React.DragEvent, todo: TodoItem, sourceList: string, sourceIndex: number) => {
    setDraggedTodo({
      todo,
      source: { type: 'list', listId: sourceList, index: sourceIndex }
    });
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleListDragOver = (e: React.DragEvent, targetList: string, targetIndex: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDropTarget({ type: 'list', list: targetList, index: targetIndex });
  };

  const handleListDragLeave = () => {
    setDropTarget(null);
  };

  const handleListDrop = async (e: React.DragEvent, targetList: string, targetIndex: number) => {
    e.preventDefault();

    if (!draggedTodo) {
      setDropTarget(null);
      return;
    }

    const { todo, source } = draggedTodo;

    
    if (source.type === 'list') {
      const sourceList = source.listId;
      const sourceIndex = source.index;

      
      if (sourceList === targetList) {
        
        if (sourceIndex === targetIndex) {
          setDraggedTodo(null);
          setDropTarget(null);
          return;
        }

        
        const listTodos = getTodosForList(targetList);
        const reordered = [...listTodos];

        
        reordered.splice(sourceIndex, 1);

        
        const adjustedTargetIndex = sourceIndex < targetIndex ? targetIndex - 1 : targetIndex;

        
        reordered.splice(adjustedTargetIndex, 0, todo);

        
        const todoIds = reordered.map(t => t.id);

        
        await reorderTodos(todoIds, targetList);
      } else {
        
        await moveTodo(todo.id, {
          toListId: targetList,
          position: targetIndex
        });

        
        const targetTodos = getTodosForList(targetList);
        const reordered = [...targetTodos];
        reordered.splice(targetIndex, 0, todo);
        const todoIds = reordered.map(t => t.id);
        await reorderTodos(todoIds, targetList);
      }
    } else if (source.type === 'calendar') {
      
      await moveTodo(todo.id, {
        toListId: targetList,
        position: targetIndex
      });

      
      const targetTodos = getTodosForList(targetList);
      const reordered = [...targetTodos];
      reordered.splice(targetIndex, 0, todo);
      const todoIds = reordered.map(t => t.id);
      await reorderTodos(todoIds, targetList);
    }

    setDraggedTodo(null);
    setDropTarget(null);
  };

  const handleDragEnd = () => {
    setDraggedTodo(null);
    setDropTarget(null);
  };

  
  const handleCalendarDragStart = (e: React.DragEvent, todo: TodoItem, sourceDate: string, sourceIndex: number) => {
    setDraggedTodo({
      todo,
      source: { type: 'calendar', date: sourceDate, index: sourceIndex }
    });
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleCalendarDragOver = (e: React.DragEvent, targetDate: string) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDropTarget({ type: 'calendar', date: targetDate });
  };

  const handleCalendarDragLeave = () => {
    setDropTarget(null);
  };

  const handleCalendarDrop = async (e: React.DragEvent, targetDate: string) => {
    e.preventDefault();

    if (!draggedTodo) {
      setDropTarget(null);
      return;
    }

    const { todo, source } = draggedTodo;

    
    if (source.type === 'list') {
      
      const dateTodos = getTodosForCalendarDate(targetDate);
      const nextPosition = dateTodos.length > 0
        ? Math.max(...dateTodos.map(t => t.position)) + 1
        : 0;

      await moveTodo(todo.id, {
        toCalendarDate: targetDate,
        position: nextPosition
      });
    }
    
    else if (source.type === 'calendar' && source.date !== targetDate) {
      
      const dateTodos = getTodosForCalendarDate(targetDate);
      const nextPosition = dateTodos.length > 0
        ? Math.max(...dateTodos.map(t => t.position)) + 1
        : 0;

      await moveTodo(todo.id, {
        toCalendarDate: targetDate,
        position: nextPosition
      });
    }

    setDraggedTodo(null);
    setDropTarget(null);
  };

  
  const renderRightContent = () => {
    switch (activePane) {
      case 'blue': {
        
        if (isLoadingLists || isLoadingTodos) {
          return (
            <div className="flex items-center justify-center h-32">
              <span className="text-muted-foreground" style={{ fontSize: '12px' }}>Loading todos...</span>
            </div>
          );
        }

        return (
          <>
            {}
            <div className="flex items-center gap-2 mb-2">
              <div className="w-3 h-3 bg-yellow-400 rounded-sm flex-shrink-0" />
              <span className="font-semibold text-yellow-400 uppercase" style={{ fontSize: '12px' }}>Todos</span>
            </div>

            {}
            {lists.map((list, listIndex) => {
              const listTodos = getTodosForList(list.id);
              const completedTodos = getCompletedTodosForList(list.id);
              const isCompletedExpanded = expandedCompleted.has(list.id);

              return (
                <div key={list.id}>
                  {}
                  <div
                    className="flex items-center mb-2"
                    onMouseEnter={() => {
                      console.log('Mouse enter list:', list.id, list.name);
                      setHoveredListId(list.id);
                    }}
                    onMouseLeave={() => {
                      console.log('Mouse leave list:', list.id);
                      setHoveredListId(null);
                    }}
                  >
                    {}
                    <button
                      onClick={() => toggleCollapse(list.id)}
                      className="flex-shrink-0 hover:opacity-70 mr-2"
                    >
                      {list.is_collapsed ? (
                        <ChevronRight className="h-3 w-3 text-yellow-400" />
                      ) : (
                        <ChevronDown className="h-3 w-3 text-yellow-400" />
                      )}
                    </button>

                    {}
                    {editingListId === list.id ? (
                      <input
                        ref={listNameInputRef}
                        type="text"
                        value={editingListName}
                        onChange={(e) => setEditingListName(e.target.value)}
                        onBlur={() => saveListName(list.id)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') saveListName(list.id);
                          if (e.key === 'Escape') cancelListEdit();
                        }}
                        autoFocus
                        className="bg-transparent focus:outline-none font-semibold text-yellow-400 uppercase tracking-wide"
                        style={{ fontSize: '11px', width: '150px' }}
                      />
                    ) : (
                      <span
                        onClick={() => startEditingList(list)}
                        className="font-semibold text-yellow-400 uppercase tracking-wide cursor-pointer hover:opacity-70"
                        style={{ fontSize: '11px' }}
                      >
                        {list.name}
                      </span>
                    )}

                    {}
                    {!list.is_protected && (
                      <button
                        onClick={() => handleDeleteList(list.id)}
                        className="flex-shrink-0 bg-red-500 rounded-full p-0.5 hover:bg-red-600 ml-2"
                        style={{ opacity: hoveredListId === list.id ? 1 : 0 }}
                      >
                        <Trash2 className="h-2.5 w-2.5 text-white" />
                      </button>
                    )}
                  </div>

                  {}
                  {!list.is_collapsed && (
                    <>
                      {}
                      <div className="space-y-1">
                    {listTodos.map((todo, index) => (
                      <div key={todo.id} className="relative">
                        {}
                        {dropTarget?.type === 'list' && dropTarget.list === list.id && dropTarget.index === index && (
                          <div className="absolute -top-0.5 left-0 right-0 h-0.5 bg-yellow-400 z-10" />
                        )}
                        <div
                          onDragOver={(e) => handleListDragOver(e, list.id, index)}
                          onDrop={(e) => handleListDrop(e, list.id, index)}
                          className="flex flex-col gap-1"
                        >
                          {}
                          <div className="flex items-baseline group">
                            {}
                            <div
                              draggable
                              onDragStart={(e) => handleListDragStart(e, todo, list.id, index)}
                              onDragEnd={handleDragEnd}
                              onClick={() => toggleComplete(todo.id)}
                              className="flex-shrink-0 cursor-grab active:cursor-grabbing hover:opacity-70 mr-2"
                              style={{ transform: 'translateY(2px)' }}
                            >
                              {todo.completed ? (
                                <CheckCircle2 className="h-3 w-3 text-green-500" />
                              ) : (
                                <Circle className={`h-3 w-3 ${todo.starred ? 'text-red-400' : 'text-yellow-400'}`} />
                              )}
                            </div>

                            {}
                            <button
                              onClick={() => toggleStar(todo.id)}
                              className="flex-shrink-0 mr-2"
                              style={{ transform: 'translateY(2px)' }}
                            >
                              <Star className={`h-3 w-3 ${todo.starred ? 'fill-red-400 text-red-400' : 'text-yellow-400/30'}`} />
                            </button>

                            {}
                            <div className="min-w-0">
                              {editingTodoId === todo.id ? (
                                <input
                                  ref={todoInputRef}
                                  type="text"
                                  value={editingText}
                                  onChange={(e) => setEditingText(e.target.value)}
                                  onBlur={() => saveEdit(todo.id)}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') saveEdit(todo.id);
                                    if (e.key === 'Escape') cancelEdit();
                                  }}
                                  className="bg-transparent focus:outline-none text-foreground"
                                  style={{ fontSize: '12px', width: '200px' }}
                                />
                              ) : (
                                <span
                                  onClick={() => startEditing(todo)}
                                  className={`cursor-text ${todo.completed ? 'line-through text-muted-foreground' : todo.starred ? 'text-red-400' : 'text-foreground'}`}
                                  style={{ fontSize: '12px' }}
                                >
                                  {todo.text}
                                </span>
                              )}
                            </div>

                            {}
                            {editingTodoId !== todo.id && todo.date_text && (
                              <div className="flex items-baseline ml-2">
                                <span className={todo.starred ? 'text-red-400' : 'text-muted-foreground'} style={{ fontSize: '12px' }}>
                                  @
                                </span>
                                <span className={`ml-1 ${todo.starred ? 'text-red-400' : 'text-muted-foreground'}`} style={{ fontSize: '12px' }}>
                                  {todo.date_text}
                                </span>
                              </div>
                            )}

                            {}
                            <button
                              onClick={() => deleteTodo(todo.id)}
                              className="opacity-0 group-hover:opacity-100 flex-shrink-0 bg-red-500 rounded-full p-0.5 hover:bg-red-600 ml-2"
                            >
                              <X className="h-2.5 w-2.5 text-white" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}

                        {}
                        <div
                          onDragOver={(e) => handleListDragOver(e, list.id, listTodos.length)}
                          onDrop={(e) => handleListDrop(e, list.id, listTodos.length)}
                          className="relative h-4"
                        >
                          {dropTarget?.type === 'list' && dropTarget.list === list.id && dropTarget.index === listTodos.length && (
                            <div className="absolute top-0 left-0 right-0 h-0.5 bg-yellow-400 z-10" />
                          )}
                        </div>
                      </div>

                      {}
                      <button
                        onClick={() => handleAddTodo(list.id)}
                        className="flex items-center gap-1 mt-2 text-muted-foreground hover:text-foreground"
                      >
                        <Plus className="h-3 w-3" />
                        <span style={{ fontSize: '12px' }}>Add task</span>
                      </button>

                      {}
                      {completedTodos.length > 0 && (
                        <div className="mt-3 rounded-md border border-border/40 overflow-hidden" style={{ backgroundColor: 'rgba(217, 133, 107, 0.1)' }}>
                          {}
                          <button
                            onClick={() => toggleCompletedSection(list.id)}
                            className="w-full flex items-center gap-2 px-2 py-1.5 hover:opacity-80"
                            style={{ backgroundColor: 'rgba(217, 133, 107, 0.2)' }}
                          >
                            {isCompletedExpanded ? (
                              <ChevronDown className="h-3 w-3" style={{ color: 'rgb(217, 133, 107)' }} />
                            ) : (
                              <ChevronRight className="h-3 w-3" style={{ color: 'rgb(217, 133, 107)' }} />
                            )}
                            <span className="font-semibold uppercase tracking-wide" style={{ fontSize: '10px', color: 'rgb(217, 133, 107)' }}>
                              Completed ({completedTodos.length})
                            </span>
                          </button>

                          {}
                          {isCompletedExpanded && (
                            <div className="px-2 py-2 space-y-1">
                              {completedTodos.map((todo) => (
                                <div key={todo.id} className="flex items-start group opacity-70">
                                  {}
                                  <div
                                    onClick={() => toggleComplete(todo.id)}
                                    className="flex-shrink-0 cursor-pointer hover:opacity-70 mr-2"
                                  >
                                    <CheckCircle2 className="h-3 w-3 text-green-500 mt-0.5" />
                                  </div>

                                  {}
                                  <div className="flex-shrink-0 opacity-30 mr-2" style={{ marginTop: '2px' }}>
                                    <Star className={`h-3 w-3 ${todo.starred ? 'fill-red-400 text-red-400' : 'text-muted-foreground'}`} />
                                  </div>

                                  {}
                                  <div className="min-w-0">
                                    <span className="line-through text-muted-foreground" style={{ fontSize: '12px' }}>
                                      {todo.text}
                                    </span>
                                  </div>

                                  {}
                                  <button
                                    onClick={() => deleteTodo(todo.id)}
                                    className="opacity-0 group-hover:opacity-100 flex-shrink-0 bg-red-500 rounded-full p-0.5 hover:bg-red-600 ml-2"
                                    style={{ marginTop: '2px' }}
                                  >
                                    <X className="h-2.5 w-2.5 text-white" />
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </>
                  )}

                  {}
                  {listIndex < lists.length - 1 && (
                    <div className="border-t border-border/40 my-3" />
                  )}
                </div>
              );
            })}

            {}
            {lists.length > 0 && (
              <div className="border-t border-border/40 my-3" />
            )}

            {}
            <button
              onClick={handleAddList}
              className="flex items-center gap-1 text-yellow-400 hover:text-yellow-300"
            >
              <Plus className="h-3 w-3" />
              <span style={{ fontSize: '12px' }}>Add list</span>
            </button>
          </>
        );
      }

      case 'orange':
        return (
          <div className="flex items-center justify-center h-full">
            <span className="text-orange-400" style={{ fontSize: '14px' }}>Orange Pane - Coming Soon</span>
          </div>
        );

      case 'brown':
        return (
          <div className="flex items-center justify-center h-full">
            <span style={{ fontSize: '14px', color: 'rgb(217, 133, 107)' }}>Brown Pane - Coming Soon</span>
          </div>
        );

      case 'yellow':
        return (
          <div className="flex items-center justify-center h-full">
            <span className="text-yellow-400" style={{ fontSize: '14px' }}>Yellow Pane - Coming Soon</span>
          </div>
        );

      case 'emerald':
        return (
          <div className="flex items-center justify-center h-full">
            <span className="text-emerald-400" style={{ fontSize: '14px' }}>Emerald Pane - Coming Soon</span>
          </div>
        );

      case 'red':
        return (
          <div className="flex items-center justify-center h-full">
            <span className="text-red-400" style={{ fontSize: '14px' }}>Red Pane - Coming Soon</span>
          </div>
        );

      default:
        return null;
    }
  };

  
  const renderFullWidthContent = () => {
    switch (activePane) {
      case 'orange':
        return (
          <div className="flex items-center justify-center h-full">
            <span className="text-orange-400" style={{ fontSize: '18px' }}>Orange Full-Width Pane</span>
          </div>
        );

      case 'brown':
        return (
          <div className="flex items-center justify-center h-full">
            <span style={{ fontSize: '18px', color: 'rgb(217, 133, 107)' }}>Brown Full-Width Pane</span>
          </div>
        );

      case 'emerald':
        return (
          <div className="flex items-center justify-center h-full">
            <span className="text-emerald-400" style={{ fontSize: '18px' }}>Emerald Full-Width Pane</span>
          </div>
        );

      case 'red':
        return (
          <div className="flex items-center justify-center h-full">
            <span className="text-red-400" style={{ fontSize: '18px' }}>Red Full-Width Pane</span>
          </div>
        );

      default:
        return null;
    }
  };

  
  const renderLeftContent = () => {
    switch (activePane) {
      case 'blue': {
        if (isLoadingEvents) {
          return (
            <div className="flex items-center justify-center h-32">
              <span className="text-muted-foreground" style={{ fontSize: '12px' }}>Loading calendar...</span>
            </div>
          );
        }

        const upcomingDays = getUpcomingDays();

        
        const today = new Date();
        const sevenDaysLater = new Date(today);
        sevenDaysLater.setDate(today.getDate() + 7);

        
        const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();

        
        const showRestOfMonth = sevenDaysLater.getDate() < lastDayOfMonth && sevenDaysLater.getMonth() === today.getMonth();
        const restOfMonth = showRestOfMonth ? getMonthEvents(sevenDaysLater.getDate(), lastDayOfMonth, 0) : null;

        
        const nextMonth = getMonthEvents(1, 31, 1);

        
        return (
          <>
            {}
            <div className="flex items-center justify-between gap-2 mb-2">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-emerald-400 rounded-sm flex-shrink-0" />
                <span className="font-semibold text-emerald-400 uppercase" style={{ fontSize: '12px' }}>Upcoming</span>
              </div>

              {}
              <button
                onClick={syncCalendar}
                disabled={isSyncingCalendar || isLoadingEvents}
                className="text-emerald-400 hover:text-emerald-300 disabled:opacity-50 disabled:cursor-not-allowed"
                style={{ fontSize: '11px' }}
                title="Sync Google Calendar"
              >
                {isSyncingCalendar ? '⟳ Syncing...' : '⟳ Sync'}
              </button>
            </div>

            {}
            {upcomingDays.map((day, index) => {
              const dayTodos = getTodosForCalendarDate(day.isoDate);
              const isDropTarget = dropTarget?.type === 'calendar' && dropTarget.date === day.isoDate;

              return (
                <div
                  key={day.id}
                  onDragOver={(e) => handleCalendarDragOver(e, day.isoDate)}
                  onDragLeave={handleCalendarDragLeave}
                  onDrop={(e) => handleCalendarDrop(e, day.isoDate)}
                  className={`rounded-md p-2 -mx-2 ${
                    isDropTarget ? 'bg-emerald-400/10 border border-emerald-400/30' : ''
                  }`}
                >
                  {}
                  <div className="flex items-baseline gap-2 mb-1">
                    <span className="text-xl font-light text-emerald-400">{day.dayNumber}</span>
                    <span className="text-emerald-400" style={{ fontSize: '12px' }}>{day.dayName}</span>
                  </div>

                  {}
                  {day.events.length > 0 && (
                    <div className="ml-10 space-y-0.5">
                      {day.events.map((event, eventIndex) => (
                        <div key={eventIndex} className="flex items-baseline group hover:opacity-80 cursor-pointer">
                          {event.isAllDay ? (
                            <span className="font-menlo text-blue-400 w-16 flex-shrink-0" style={{ fontSize: '12px' }}>
                              all-day
                            </span>
                          ) : event.time && (
                            <span className="font-menlo text-blue-400 w-16 flex-shrink-0" style={{ fontSize: '12px' }}>
                              {event.time}
                            </span>
                          )}
                          <span className="text-foreground" style={{ fontSize: '12px' }}>{event.title}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {}
                  {dayTodos.length > 0 && (
                    <div className="ml-10 space-y-0.5 mt-1">
                      {dayTodos.map((todo, todoIndex) => (
                        <div
                          key={todo.id}
                          className="flex items-baseline group hover:opacity-80"
                        >
                          {}
                          <div className="w-16 flex-shrink-0 flex items-baseline">
                            {}
                            <div
                              draggable
                              onDragStart={(e) => handleCalendarDragStart(e, todo, day.isoDate, todoIndex)}
                              onDragEnd={handleDragEnd}
                              onClick={() => toggleComplete(todo.id)}
                              className="cursor-grab active:cursor-grabbing mr-2"
                              style={{ transform: 'translateY(2px)' }}
                            >
                              {todo.completed ? (
                                <CheckCircle2 className="h-3 w-3 text-blue-400" />
                              ) : (
                                <Circle className={`h-3 w-3 ${todo.starred ? 'text-red-400' : 'text-blue-400'}`} />
                              )}
                            </div>

                            {}
                            <button
                              onClick={() => toggleStar(todo.id)}
                              className=""
                              style={{ transform: 'translateY(2px)' }}
                            >
                              <Star className={`h-3 w-3 ${todo.starred ? 'fill-red-400 text-red-400' : 'text-blue-400/30'}`} />
                            </button>
                          </div>

                          {}
                          <div className="min-w-0">
                            {editingTodoId === todo.id ? (
                              <input
                                ref={todoInputRef}
                                type="text"
                                value={editingText}
                                onChange={(e) => setEditingText(e.target.value)}
                                onBlur={() => saveEdit(todo.id)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') saveEdit(todo.id);
                                  if (e.key === 'Escape') cancelEdit();
                                }}
                                className="bg-transparent focus:outline-none text-foreground"
                                style={{ fontSize: '12px', width: '200px' }}
                              />
                            ) : (
                              <span
                                onClick={() => startEditing(todo)}
                                className={`cursor-text ${todo.starred ? 'text-red-400' : 'text-foreground'}`}
                                style={{ fontSize: '12px' }}
                              >
                                {todo.text}
                              </span>
                            )}
                          </div>

                          {}
                          {editingTodoId !== todo.id && todo.date_text && (
                            <span className={`ml-2 ${todo.starred ? 'text-red-400' : 'text-muted-foreground'}`} style={{ fontSize: '11px' }}>
                              @ {todo.date_text}
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {}
                  {isDropTarget && (
                    <div className="ml-10 mt-1">
                      <span className="text-emerald-400 text-xs italic">Drop todo here</span>
                    </div>
                  )}

                  {}
                  {index < upcomingDays.length - 1 && (
                    <div className="mt-2.5 border-t border-border/20" />
                  )}
                </div>
              );
            })}

            {}
            {restOfMonth && restOfMonth.events.length > 0 && (
              <>
                {}
                <div className="border-t border-border/40 my-3" />

                <div>
                  <div className="mb-2">
                    <span className="font-semibold text-emerald-400" style={{ fontSize: '12px' }}>{restOfMonth.title}</span>
                  </div>
                  <div className="space-y-0.5">
                    {restOfMonth.events.map((event, index) => (
                      <div key={index} className="flex items-baseline gap-2 group hover:opacity-80 cursor-pointer">
                        <span className="font-menlo text-blue-400 w-6 flex-shrink-0" style={{ fontSize: '12px' }}>{event.day}</span>
                        <span className="text-foreground" style={{ fontSize: '12px' }}>{event.title}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {}
            {nextMonth.events.length > 0 && (
              <>
                {}
                <div className="border-t border-border/40 my-3" />

                <div>
                  <div className="mb-2">
                    <span className="font-semibold text-emerald-400" style={{ fontSize: '12px' }}>{nextMonth.title}</span>
                  </div>
                  <div className="space-y-0.5">
                    {nextMonth.events.map((event, index) => (
                      <div key={index} className="flex items-baseline gap-2 group hover:opacity-80 cursor-pointer">
                        <span className="font-menlo text-blue-400 w-6 flex-shrink-0" style={{ fontSize: '12px' }}>{event.day}</span>
                        <span className="text-foreground" style={{ fontSize: '12px' }}>{event.title}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </>
        );
      }

      case 'orange':
      case 'brown':
      case 'yellow':
      case 'emerald':
      case 'red':
        return (
          <div className="flex items-center justify-center h-full">
            <span className="text-muted-foreground" style={{ fontSize: '14px' }}>Left Pane - Coming Soon</span>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="h-full w-full flex bg-background border-l border-border/40 relative">
      {activePane && paneConfig[activePane].fullWidth ? (
        
        <div className="w-full h-full">
          <div
            className="h-full relative overflow-y-auto"
            style={{
              background: 'radial-gradient(circle at 20% 30%, rgba(223, 208, 184, 0.03) 0%, transparent 50%), radial-gradient(circle at 80% 70%, rgba(223, 208, 184, 0.02) 0%, transparent 50%)',
            }}
          >
            {}
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                backgroundImage: `
                  linear-gradient(rgba(223, 208, 184, 0.03) 1px, transparent 1px),
                  linear-gradient(90deg, rgba(223, 208, 184, 0.03) 1px, transparent 1px)
                `,
                backgroundSize: '40px 40px'
              }}
            />

            {}
            <div className="relative z-10 px-6 py-4 pb-24 space-y-3">
              {renderFullWidthContent()}
            </div>
          </div>
        </div>
      ) : activePane ? (
        
        <>
          {}
          <div className="w-1/2 h-full border-r border-border/40">
            <div
              className="h-full relative overflow-y-auto"
              style={{
                background: 'radial-gradient(circle at 20% 30%, rgba(223, 208, 184, 0.03) 0%, transparent 50%), radial-gradient(circle at 80% 70%, rgba(223, 208, 184, 0.02) 0%, transparent 50%)',
              }}
            >
              {}
              <div
                className="absolute inset-0 pointer-events-none"
                style={{
                  backgroundImage: `
                    linear-gradient(rgba(223, 208, 184, 0.03) 1px, transparent 1px),
                    linear-gradient(90deg, rgba(223, 208, 184, 0.03) 1px, transparent 1px)
                  `,
                  backgroundSize: '40px 40px'
                }}
              />

              {}
              <div className="relative z-10 px-6 py-4 space-y-3">
                {renderLeftContent()}
              </div>
            </div>
          </div>

          {}
          <div className="w-1/2 h-full">
        <div
          className="h-full overflow-y-auto relative"
          style={{
            background: 'radial-gradient(circle at 20% 30%, rgba(223, 208, 184, 0.03) 0%, transparent 50%), radial-gradient(circle at 80% 70%, rgba(223, 208, 184, 0.02) 0%, transparent 50%)',
          }}
        >
          {}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              backgroundImage: `
                linear-gradient(rgba(223, 208, 184, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(223, 208, 184, 0.03) 1px, transparent 1px)
              `,
              backgroundSize: '40px 40px'
            }}
          />

          {}
          <div className="relative z-10 px-6 py-4 pb-24 space-y-3">
            {renderRightContent()}
          </div>
        </div>
          </div>
        </>
      ) : null}
    </div>
  );
};

export default Whiteboard;
