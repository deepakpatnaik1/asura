import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { FileText, Table, Presentation } from 'lucide-react';
import type { SharedGoogleFile } from '@/services/listSharedGoogleFiles';

const SERVICE_ACCOUNT_EMAIL = 'tsushima@tsushima-472819.iam.gserviceaccount.com';

interface SharedFilesModalProps {
  isOpen: boolean;
  onClose: () => void;
  files: SharedGoogleFile[];
  onSubmit: (selectedFiles: SharedGoogleFile[]) => void;
}

const SharedFilesModal: React.FC<SharedFilesModalProps> = ({
  isOpen,
  onClose,
  files,
  onSubmit,
}) => {
  const [selectedFileIds, setSelectedFileIds] = useState<Set<string>>(new Set());

  const handleToggle = (fileId: string) => {
    const newSelected = new Set(selectedFileIds);
    if (newSelected.has(fileId)) {
      newSelected.delete(fileId);
    } else {
      newSelected.add(fileId);
    }
    setSelectedFileIds(newSelected);
  };

  const handleSubmit = () => {
    const selectedFiles = files.filter(f => selectedFileIds.has(f.id));
    onSubmit(selectedFiles);
    setSelectedFileIds(new Set());
    onClose();
  };

  const getFileIcon = (type: 'docs' | 'sheets' | 'slides') => {
    switch (type) {
      case 'docs':
        return <FileText className="h-4 w-4 text-blue-500" />;
      case 'sheets':
        return <Table className="h-4 w-4 text-green-500" />;
      case 'slides':
        return <Presentation className="h-4 w-4 text-orange-500" />;
    }
  };

  const getTypeLabel = (type: 'docs' | 'sheets' | 'slides') => {
    switch (type) {
      case 'docs':
        return 'Google Docs';
      case 'sheets':
        return 'Google Sheets';
      case 'slides':
        return 'Google Slides';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] bg-card border-chat-border">
        <DialogHeader>
          <DialogTitle className="text-prose-heading">Shared Google Files</DialogTitle>
          <DialogDescription className="text-prose-body">
            Select files to add to your context
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-2 max-h-[400px] overflow-y-auto">
          {files.length === 0 ? (
            <div className="text-center py-8 text-prose-body">
              <p>No new shared files</p>
              <p className="text-xs mt-2">Share Google Docs, Sheets, or Slides with:</p>
              <p className="text-xs font-mono mt-1">{SERVICE_ACCOUNT_EMAIL}</p>
            </div>
          ) : (
            files.map((file) => (
              <div
                key={file.id}
                className="flex items-center gap-3 p-3 border border-chat-border rounded hover:bg-accent/10 cursor-pointer"
                onClick={() => handleToggle(file.id)}
              >
                <Checkbox
                  checked={selectedFileIds.has(file.id)}
                  onCheckedChange={() => handleToggle(file.id)}
                />
                {getFileIcon(file.type)}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-prose-heading truncate">
                    {file.name}
                  </p>
                  <p className="text-xs text-prose-body">
                    {getTypeLabel(file.type)}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>

        {files.length > 0 && (
          <div className="flex justify-end gap-2 pt-4">
            <Button
              variant="ghost"
              onClick={onClose}
              className="text-prose-body"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={selectedFileIds.size === 0}
              className="bg-accent text-background hover:bg-accent/90"
            >
              Add {selectedFileIds.size > 0 ? `(${selectedFileIds.size})` : ''}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default SharedFilesModal;
