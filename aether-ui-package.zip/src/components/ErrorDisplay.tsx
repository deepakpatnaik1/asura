import React from 'react';
import { AppError } from '@/utils/errorHandling';

interface ErrorDisplayProps {
  error: AppError | null;
  onRetry?: () => void;
  onDismiss: () => void;
}

const ErrorDisplay: React.FC<ErrorDisplayProps> = ({ error, onRetry, onDismiss }) => {
  if (!error) return null;

  const getErrorColor = (type: AppError['type']) => {
    switch (type) {
      case 'network':
        return 'text-orange-300';
      case 'api':
        return 'text-red-300';
      case 'database':
        return 'text-yellow-300';
      case 'clipboard':
        return 'text-blue-300';
      default:
        return 'text-muted-foreground';
    }
  };

  return (
    <div className="bg-card border border-chat-border rounded-md p-3 mb-4 mx-6">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className={`text-sm font-medium ${getErrorColor(error.type)} mb-1`}>
            {error.message}
          </div>
          {error.details && (
            <div className="text-xs text-chat-label">
              {error.details}
            </div>
          )}
        </div>
        <div className="flex items-center gap-2 ml-4">
          {error.recoverable && onRetry && (
            <button
              onClick={onRetry}
              className="text-xs text-chat-label hover:text-foreground px-2 py-1 rounded transition-colors"
            >
              Retry
            </button>
          )}
          <button
            onClick={onDismiss}
            className="text-xs text-chat-label hover:text-foreground px-2 py-1 rounded transition-colors"
          >
            ✕
          </button>
        </div>
      </div>
    </div>
  );
};

export default ErrorDisplay;