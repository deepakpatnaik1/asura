import React from 'react';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import type { DisplayFile } from '@/types/contextFiles';
import { deleteContextFile } from '@/services/contextFilesDB';
import { secureLog } from '@/utils/secureLogging';

interface ActiveContextBarProps {
  activeFiles: DisplayFile[];
  onDismiss: (fileId: string) => void;
}

const ActiveContextBar: React.FC<ActiveContextBarProps> = ({ activeFiles, onDismiss }) => {
  const handleDismiss = async (fileId: string) => {
    const file = activeFiles.find(f => f.id === fileId);

    if (!file) {
      secureLog.error('File not found in activeFiles', fileId);
      onDismiss(fileId);
      return;
    }

    try {
      await deleteContextFile(fileId);
      onDismiss(fileId);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      secureLog.error('Failed to delete file', errorMessage);
      onDismiss(fileId);
    }
  };
  if (activeFiles.length === 0) {
    return null;
  }

  return (
    <div className="border-t border-chat-border bg-secondary/30 px-6 py-2">
      <div className="mx-auto" style={{ maxWidth: '600px' }}>
        <div className="flex flex-wrap items-center gap-2">
          {activeFiles.map((file) => (
            <div
              key={file.id}
              className="flex items-center gap-1.5 bg-card border border-chat-border rounded px-2 py-0.5 shadow-sm"
            >
              <button
                onClick={() => handleDismiss(file.id)}
                className="text-red-500 hover:bg-red-500/20 rounded-full p-0.5 transition-colors duration-150"
                title="Dismiss file"
              >
                <X className="h-2.5 w-2.5" />
              </button>

              <span className="text-chat-label font-menlo" style={{ fontSize: '10px' }}>
                {file.displayName}
              </span>

              {(file.status === 'uploading' || file.status === 'processing') && (
                <span className="text-chat-label font-menlo" style={{ fontSize: '10px' }}>
                  {'...'.split('').map((char, charIndex) => (
                    <span
                      key={charIndex}
                      className="inline-block animate-pulse"
                      style={{
                        animationDelay: `${charIndex * 100}ms`,
                        animationDuration: '1s'
                      }}
                    >
                      {char}
                    </span>
                  ))}
                </span>
              )}

              {file.status === 'failed' && (
                <span className="text-red-500 font-menlo" style={{ fontSize: '10px' }}>
                  upload failed
                </span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ActiveContextBar;
