import React from 'react';
import { Copy, Trash2, RotateCcw, MessageCircle } from 'lucide-react';

interface MessageActionsProps {
  messageId: string;
  messageText: string;
  copiedMessageId: string | null;
  onCopy: (text: string, messageId: string) => void;
  rethinkingMessageId?: string | null;
  deletingMessageId?: string | null;
  miniChatMessageId?: string | null;
  sender?: 'Boss' | 'Gunnar';
  onRethinkClick?: () => void;
  onDelete?: (messageId: string) => void;
  onMiniChatClick?: () => void;
}

const MessageActions: React.FC<MessageActionsProps> = ({
  messageId,
  messageText,
  copiedMessageId,
  onCopy,
  rethinkingMessageId,
  deletingMessageId,
  miniChatMessageId,
  sender,
  onRethinkClick,
  onDelete,
  onMiniChatClick,
}) => {
  const iconColor = sender === 'Boss' ? 'rgb(217, 133, 107)' : undefined;
  return (
    <div className="flex items-center gap-2 font-menlo" style={{ fontSize: '10px' }}>
      <button
        className={`p-1 rounded transition-all duration-0 ${
          copiedMessageId === messageId
            ? 'animate-scale-in'
            : 'hover:text-foreground hover:shadow-[0_0_8px_rgba(223,208,184,0.5)]'
        }`}
        style={copiedMessageId === messageId ? { color: '#00ff41' } : { color: iconColor }}
        onClick={() => onCopy(messageText, messageId)}
      >
        <Copy size={12} />
      </button>

      <button
        className={`p-1 rounded transition-all duration-0 ${
          rethinkingMessageId === messageId
            ? 'animate-scale-in'
            : 'hover:text-foreground hover:shadow-[0_0_8px_rgba(223,208,184,0.5)]'
        }`}
        style={rethinkingMessageId === messageId ? { color: '#3b82f6' } : { color: iconColor }}
        onClick={onRethinkClick}
      >
        <RotateCcw size={12} />
      </button>

      <button
        className={`p-1 rounded transition-all duration-0 ${
          deletingMessageId === messageId
            ? 'animate-scale-in'
            : 'hover:text-foreground hover:shadow-[0_0_8px_rgba(223,208,184,0.5)]'
        }`}
        style={deletingMessageId === messageId ? { color: '#ef4444' } : { color: iconColor }}
        onClick={() => onDelete?.(messageId)}
      >
        <Trash2 size={12} />
      </button>

      <button
        className={`p-1 rounded transition-all duration-0 ${
          miniChatMessageId === messageId
            ? 'animate-scale-in'
            : 'hover:text-foreground hover:shadow-[0_0_8px_rgba(223,208,184,0.5)]'
        }`}
        style={miniChatMessageId === messageId ? { color: 'rgb(217, 133, 107)' } : { color: iconColor }}
        onClick={onMiniChatClick}
      >
        <MessageCircle size={12} />
      </button>
    </div>
  );
};

export default MessageActions;