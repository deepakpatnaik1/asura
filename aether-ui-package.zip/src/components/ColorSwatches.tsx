type PaneType = 'blue' | 'orange' | 'brown' | 'yellow' | 'emerald' | 'red';

interface ColorSwatchesProps {
  activePane: PaneType | null;
  togglePane: (pane: PaneType) => void;
}

const ColorSwatches = ({ activePane, togglePane }: ColorSwatchesProps) => {
  
  
  const rightPosition = activePane ? '25%' : '16.667%';

  return (
    <div className="fixed z-30 pointer-events-none" style={{ bottom: '14px', right: rightPosition, transform: 'translateX(50%)' }}>
      <div className="flex items-center gap-2 bg-background/80 backdrop-blur-sm px-4 py-3 rounded-full border border-border/40 shadow-lg pointer-events-auto">
        <button
          onClick={() => togglePane('blue')}
          className={`w-6 h-6 bg-blue-400 flex-shrink-0 ${activePane === 'blue' ? 'scale-125 shadow-lg' : 'opacity-60 hover:opacity-100'}`}
          style={{ clipPath: 'polygon(10% 0%, 100% 5%, 95% 90%, 5% 100%, 0% 15%)', transform: activePane === 'blue' ? 'rotate(-3deg) scale(1.25)' : 'rotate(-3deg)' }}
        />
        <button
          onClick={() => togglePane('orange')}
          className={`w-5 h-6 bg-orange-400 flex-shrink-0 ${activePane === 'orange' ? 'scale-125 shadow-lg' : 'opacity-60 hover:opacity-100'}`}
          style={{ clipPath: 'polygon(5% 10%, 90% 0%, 100% 85%, 15% 95%, 0% 20%)', transform: activePane === 'orange' ? 'rotate(2deg) scale(1.25)' : 'rotate(2deg)' }}
        />
        <button
          onClick={() => togglePane('brown')}
          className={`w-6 h-5 flex-shrink-0 ${activePane === 'brown' ? 'scale-125 shadow-lg' : 'opacity-60 hover:opacity-100'}`}
          style={{ backgroundColor: 'rgb(217, 133, 107)', clipPath: 'polygon(8% 5%, 95% 0%, 100% 90%, 10% 100%, 0% 25%)', transform: activePane === 'brown' ? 'rotate(-1deg) scale(1.25)' : 'rotate(-1deg)' }}
        />
        <button
          onClick={() => togglePane('yellow')}
          className={`w-5 h-6 bg-yellow-400 flex-shrink-0 ${activePane === 'yellow' ? 'scale-125 shadow-lg' : 'opacity-60 hover:opacity-100'}`}
          style={{ clipPath: 'polygon(15% 0%, 100% 8%, 90% 95%, 0% 100%, 5% 18%)', transform: activePane === 'yellow' ? 'rotate(4deg) scale(1.25)' : 'rotate(4deg)' }}
        />
        <button
          onClick={() => togglePane('emerald')}
          className={`w-6 h-5 bg-emerald-400 flex-shrink-0 ${activePane === 'emerald' ? 'scale-125 shadow-lg' : 'opacity-60 hover:opacity-100'}`}
          style={{ clipPath: 'polygon(12% 8%, 98% 0%, 100% 88%, 8% 100%, 0% 22%)', transform: activePane === 'emerald' ? 'rotate(-2deg) scale(1.25)' : 'rotate(-2deg)' }}
        />
        <button
          onClick={() => togglePane('red')}
          className={`w-5 h-6 bg-red-400 flex-shrink-0 ${activePane === 'red' ? 'scale-125 shadow-lg' : 'opacity-60 hover:opacity-100'}`}
          style={{ clipPath: 'polygon(8% 0%, 95% 12%, 100% 92%, 12% 100%, 0% 15%)', transform: activePane === 'red' ? 'rotate(1deg) scale(1.25)' : 'rotate(1deg)' }}
        />
      </div>
    </div>
  );
};

export default ColorSwatches;
