export const API_CONFIG = {
  SUPABASE_URL: `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat-ai`,
  SUPABASE_ANON_KEY: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
} as const;

export const AI_MODELS = {
  SONNET_4_5: 'claude-sonnet-4-5',
  HAIKU_4_5: 'claude-haiku-4-5',
} as const;

export type AIModelType = typeof AI_MODELS[keyof typeof AI_MODELS];