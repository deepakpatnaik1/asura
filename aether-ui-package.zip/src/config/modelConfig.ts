

export interface ModelConfig {
  maxCompletionTokens: number;
  contextWindow: number; 
  provider: 'anthropic';
}

export const MODEL_CONFIGS: Record<string, ModelConfig> = {
  'claude-sonnet-4-5': {
    maxCompletionTokens: 8192,
    contextWindow: 200000, 
    provider: 'anthropic'
  },
  'claude-haiku-4-5': {
    maxCompletionTokens: 8192,
    contextWindow: 200000, 
    provider: 'anthropic'
  }
};

export function getModelConfig(model: string): ModelConfig | undefined {
  return MODEL_CONFIGS[model];
}

export function getContextWindowLimit(model: string): number {
  const config = getModelConfig(model);
  return config?.contextWindow ?? 200000; 
}
