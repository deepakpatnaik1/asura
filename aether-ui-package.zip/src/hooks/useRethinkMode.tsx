import { useState, useCallback } from 'react';

interface Correction {
  text: string;
  feedback: string;
}

interface UseRethinkModeReturn {
  rethinkingTurnIndex: number | null;
  corrections: Correction[];
  enterRethinkMode: (turnIndex: number) => void;
  exitRethinkMode: () => void;
  addCorrection: (correction: Correction) => void;
  submitRethink: () => void;
  isInRethinkMode: boolean;
}

export const useRethinkMode = (): UseRethinkModeReturn => {
  const [rethinkingTurnIndex, setRethinkingTurnIndex] = useState<number | null>(null);
  const [corrections, setCorrections] = useState<Correction[]>([]);

  const enterRethinkMode = useCallback((turnIndex: number) => {
    setRethinkingTurnIndex(turnIndex);
    setCorrections([]);
  }, []);

  const exitRethinkMode = useCallback(() => {
    setRethinkingTurnIndex(null);
    setCorrections([]);
  }, []);

  const addCorrection = useCallback((correction: Correction) => {
    setCorrections(prev => [...prev, correction]);
  }, []);

  const submitRethink = useCallback(() => {
    
    console.log('Submitting rethink with corrections:', corrections);
    exitRethinkMode();
  }, [corrections, exitRethinkMode]);

  return {
    rethinkingTurnIndex,
    corrections,
    enterRethinkMode,
    exitRethinkMode,
    addCorrection,
    submitRethink,
    isInRethinkMode: rethinkingTurnIndex !== null
  };
};

