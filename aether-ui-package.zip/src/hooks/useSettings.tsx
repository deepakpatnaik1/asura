import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { AI_MODELS } from '@/config/constants';
import { secureLog } from '@/utils/secureLogging';
import type { PersonaName } from '@/types/personas';

interface UserSettingsRow {
  id: string;
  user_id: string;
  selected_model: string;
  selected_persona: string;
  created_at: string;
  updated_at: string;
}

interface UseSettingsReturn {
  selectedModel: string;
  selectedPersona: PersonaName;
  loading: boolean;
  error: string | null;
  updateModel: (model: string) => Promise<void>;
  updatePersona: (persona: PersonaName) => Promise<void>;
}

export function useSettings(): UseSettingsReturn {
  const { user } = useAuth();

  const [selectedModel, setSelectedModel] = useState<string>('claude-sonnet-4-5');
  const [selectedPersona, setSelectedPersona] = useState<PersonaName>('Gunnar');
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const hasLoadedRef = useRef(false);
  const isLoadingRef = useRef(false);

  const loadSettings = async (): Promise<void> => {
    if (!user?.id || isLoadingRef.current) {
      return;
    }

    isLoadingRef.current = true;
    setLoading(true);
    setError(null);

    try {
      secureLog.info('Loading user settings from database');

      const { data, error: queryError } = await supabase
        .from('user_settings')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (queryError) {
        throw new Error(`Database query failed: ${queryError.message}`);
      }

      if (data) {
        setSelectedModel(data.selected_model);
        setSelectedPersona(data.selected_persona);
        hasLoadedRef.current = true;
        secureLog.info('Settings loaded from database', {
          model: data.selected_model,
          persona: data.selected_persona
        });
        return;
      }

      secureLog.info('No settings found - creating default settings');

      const { data: newSettings, error: insertError } = await supabase
        .from('user_settings')
        .insert({
          user_id: user.id,
          selected_model: 'claude-sonnet-4-5',
          selected_persona: 'Gunnar'
        })
        .select()
        .single();

      if (insertError) {
        throw new Error(`Failed to create settings: ${insertError.message}`);
      }

      setSelectedModel(newSettings.selected_model);
      setSelectedPersona(newSettings.selected_persona);
      hasLoadedRef.current = true;
      secureLog.info('Default settings created successfully');

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load settings';
      setError(errorMessage);
      secureLog.error('Settings loading error', errorMessage);
      setSelectedModel('claude-sonnet-4-5');
      setSelectedPersona('Gunnar');
    } finally {
      setLoading(false);
      isLoadingRef.current = false;
    }
  };

  const updateModel = useCallback(async (model: string): Promise<void> => {
    if (!user?.id) {
      secureLog.error('Update model failed: No authenticated user');
      return;
    }

    try {
      secureLog.info('Updating model selection', { model });

      const { error: updateError } = await supabase
        .from('user_settings')
        .update({ selected_model: model })
        .eq('user_id', user.id);

      if (updateError) {
        throw new Error(`Failed to update model: ${updateError.message}`);
      }

      setSelectedModel(model);
      secureLog.info('Model updated successfully', { model });

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update model';
      setError(errorMessage);
      secureLog.error('Model update error', errorMessage);
    }
  }, [user?.id]);

  const updatePersona = useCallback(async (persona: PersonaName): Promise<void> => {
    if (!user?.id) {
      secureLog.error('Update persona failed: No authenticated user');
      return;
    }

    try {
      secureLog.info('Updating persona selection', { persona });

      const { error: updateError } = await supabase
        .from('user_settings')
        .update({ selected_persona: persona })
        .eq('user_id', user.id);

      if (updateError) {
        throw new Error(`Failed to update persona: ${updateError.message}`);
      }

      setSelectedPersona(persona);
      secureLog.info('Persona updated successfully', { persona });

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update persona';
      setError(errorMessage);
      secureLog.error('Persona update error', errorMessage);
    }
  }, [user?.id]);

  useEffect(() => {
    if (user?.id && !hasLoadedRef.current && !isLoadingRef.current) {
      loadSettings();
    }
  }, [user?.id]);

  useEffect(() => {
    if (!user) {
      setSelectedModel('claude-sonnet-4-5');
      setSelectedPersona('Gunnar');
      setLoading(false);
      setError(null);
      hasLoadedRef.current = false;
      isLoadingRef.current = false;
      secureLog.info('Settings reset on logout');
    }
  }, [user]);

  useEffect(() => {
    if (!user?.id) {
      return;
    }

    secureLog.info('Subscribing to user_settings real-time updates');

    const subscription = supabase
      .channel('user_settings_updates')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'user_settings',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          secureLog.info('Settings updated via real-time', payload.new);

          const updated = payload.new as UserSettingsRow;
          setSelectedModel(updated.selected_model);
          setSelectedPersona(updated.selected_persona);
        }
      )
      .subscribe();

    return () => {
      secureLog.info('Unsubscribing from user_settings real-time');
      subscription.unsubscribe();
    };
  }, [user?.id]);

  return {
    selectedModel,
    selectedPersona,
    loading,
    error,
    updateModel,
    updatePersona
  };
}
