import { useState, useCallback, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { getInactiveFiles } from '@/services/contextFilesDB';
import type { InactiveFile, ContextFileRecord } from '@/types/contextFiles';
import { secureLog } from '@/utils/secureLogging';

interface UseInactiveFilesReturn {
  inactiveFiles: InactiveFile[];
  loading: boolean;
  error: string | null;
  refreshInactiveFiles: () => Promise<void>;
}

function formatTimestamp(isoTimestamp: string): string {
  try {
    const date = new Date(isoTimestamp);

    const month = date.toLocaleString('en-US', { month: 'short' });
    const day = date.getDate();
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');

    return `${month} ${day}, ${hours}:${minutes}`;
  } catch (error) {
    secureLog.error('Failed to format timestamp', isoTimestamp);
    return isoTimestamp;
  }
}

export function useInactiveFiles(): UseInactiveFilesReturn {
  const { user } = useAuth();
  const [inactiveFiles, setInactiveFiles] = useState<InactiveFile[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const mapToInactiveFile = (record: ContextFileRecord): InactiveFile => {
    return {
      id: record.id,
      filename: record.filename,
      timestamp: formatTimestamp(record.updated_at)
    };
  };

  const refreshInactiveFiles = useCallback(async () => {
    if (!user) {
      setInactiveFiles([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const records = await getInactiveFiles(user.id);

      const mapped = records.map(mapToInactiveFile);

      setInactiveFiles(mapped);
      secureLog.info(`Loaded ${mapped.length} inactive files for user`);

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load inactive files';
      setError(errorMessage);
      secureLog.error('Failed to refresh inactive files', errorMessage);
      setInactiveFiles([]);
    } finally {
      setLoading(false);
    }
  }, [user]);

  return {
    inactiveFiles,
    loading,
    error,
    refreshInactiveFiles
  };
}
