import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import {
  getTodoLists,
  createTodoList,
  updateTodoList,
  deleteTodoList,
  reorderLists
} from '@/services/todoListsDB';
import type { TodoList, UpdateTodoListParams } from '@/types/todos';
import { secureLog } from '@/utils/secureLogging';

interface UseTodoListsReturn {
  lists: TodoList[];
  isLoading: boolean;
  error: string | null;
  createList: (name: string) => Promise<TodoList>;
  updateList: (listId: string, updates: UpdateTodoListParams) => Promise<void>;
  deleteList: (listId: string) => Promise<void>;
  toggleCollapse: (listId: string) => Promise<void>;
  reorderLists: (listIds: string[]) => Promise<void>;
}

export function useTodoLists(): UseTodoListsReturn {
  const { user } = useAuth();
  const [lists, setLists] = useState<TodoList[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  
  const loadLists = useCallback(async () => {
    if (!user) {
      setLists([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      let data = await getTodoLists(user.id);

      
      const hasGunnarsList = data.some(list => list.name === "Gunnar's List");
      const hasMoneyTodos = data.some(list => list.name === "Money Todos");

      
      if (!hasGunnarsList || !hasMoneyTodos) {
        secureLog.info('Creating missing default lists');

        if (!hasGunnarsList) {
          await createTodoList({
            user_id: user.id,
            name: "Gunnar's List",
            is_protected: true,
            position: 0
          });
        }

        if (!hasMoneyTodos) {
          await createTodoList({
            user_id: user.id,
            name: "Money Todos",
            is_protected: true,
            position: 1
          });
        }

        data = await getTodoLists(user.id);
        secureLog.info('Created default protected lists');
      }

      setLists(data);
      secureLog.info(`Loaded ${data.length} todo lists for user`);

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load todo lists';
      setError(errorMessage);
      secureLog.error('Failed to load todo lists', errorMessage);
      setLists([]);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadLists();
  }, [loadLists]);

  
  useEffect(() => {
    if (!user?.id) {
      return;
    }

    const channelName = `todo_lists_updates_${user.id}`;

    const subscription = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: '*', 
          schema: 'public',
          table: 'todo_lists',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          secureLog.info(`Todo list ${payload.eventType}`, payload.new || payload.old);

          if (payload.eventType === 'INSERT') {
            
            const newList = payload.new as TodoList;
            setLists((prev) => {
              
              if (prev.some(list => list.id === newList.id)) {
                secureLog.info(`Duplicate INSERT ignored for list ${newList.id}`);
                return prev;
              }
              
              const updated = [...prev, newList];
              return updated.sort((a, b) => a.position - b.position);
            });
          } else if (payload.eventType === 'UPDATE') {
            
            const updatedList = payload.new as TodoList;
            setLists((prev) =>
              prev.map((list) =>
                list.id === updatedList.id ? updatedList : list
              ).sort((a, b) => a.position - b.position)
            );
          } else if (payload.eventType === 'DELETE') {
            
            const deletedList = payload.old as TodoList;
            setLists((prev) => prev.filter(list => list.id !== deletedList.id));
          }
        }
      )
      .subscribe();

    return () => {
      secureLog.info(`Unsubscribing from channel ${channelName}`);
      subscription.unsubscribe();
    };
  }, [user?.id]);

  
  useEffect(() => {
    if (!user) {
      setLists([]);
      setError(null);
      setLoading(false);
    }
  }, [user]);

  
  const createListHandler = useCallback(async (name: string): Promise<TodoList> => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      setError(null);

      
      const maxPosition = lists.reduce((max, list) => Math.max(max, list.position), -1);
      const nextPosition = maxPosition + 1;

      
      const optimisticList: TodoList = {
        id: crypto.randomUUID(), 
        user_id: user.id,
        name,
        is_protected: false,
        is_collapsed: false,
        position: nextPosition,
        created_at: new Date().toISOString()
      };

      
      setLists((prev) => [...prev, optimisticList].sort((a, b) => a.position - b.position));

      
      createTodoList({
        user_id: user.id,
        name,
        position: nextPosition
      }).then((newList) => {
        secureLog.info(`Created todo list: ${name}`);
        
        
        setLists((prev) =>
          prev.map(list => {
            if (list.id === optimisticList.id) {
              
              return { ...newList };
            }
            return list;
          })
        );
        
        optimisticList.id = newList.id;
      }).catch((err) => {
        
        setLists((prev) => prev.filter(list => list.id !== optimisticList.id));
        const errorMessage = err instanceof Error ? err.message : 'Failed to create list';
        setError(errorMessage);
        secureLog.error('Failed to create todo list', errorMessage);
      });

      
      return optimisticList;

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to create list';
      setError(errorMessage);
      secureLog.error('Failed to create todo list', errorMessage);
      throw err;
    }
  }, [user, lists]);

  
  const updateListHandler = useCallback(async (
    listId: string,
    updates: UpdateTodoListParams
  ) => {
    try {
      setError(null);
      await updateTodoList(listId, updates);
      secureLog.info(`Updated todo list: ${listId}`);
      

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update list';
      setError(errorMessage);
      secureLog.error('Failed to update todo list', errorMessage);
      throw err;
    }
  }, []);

  
  const deleteListHandler = useCallback(async (listId: string) => {
    try {
      setError(null);

      
      const list = lists.find(l => l.id === listId);
      if (!list) {
        throw new Error('List not found');
      }

      if (list.is_protected) {
        throw new Error('Cannot delete protected list');
      }

      await deleteTodoList(listId);
      secureLog.info(`Deleted todo list: ${listId}`);
      

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to delete list';
      setError(errorMessage);
      secureLog.error('Failed to delete todo list', errorMessage);
      throw err;
    }
  }, [lists]);

  
  const toggleCollapseHandler = useCallback(async (listId: string) => {
    try {
      setError(null);

      
      const list = lists.find(l => l.id === listId);
      if (!list) {
        throw new Error('List not found');
      }

      await updateTodoList(listId, { is_collapsed: !list.is_collapsed });
      secureLog.info(`Toggled collapse for list: ${listId}`);
      

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to toggle collapse';
      setError(errorMessage);
      secureLog.error('Failed to toggle collapse', errorMessage);
      throw err;
    }
  }, [lists]);

  
  const reorderListsHandler = useCallback(async (listIds: string[]) => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      setError(null);
      await reorderLists(user.id, listIds);
      secureLog.info(`Reordered ${listIds.length} lists`);
      

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to reorder lists';
      setError(errorMessage);
      secureLog.error('Failed to reorder lists', errorMessage);
      throw err;
    }
  }, [user]);

  return {
    lists,
    isLoading: loading,
    error,
    createList: createListHandler,
    updateList: updateListHandler,
    deleteList: deleteListHandler,
    toggleCollapse: toggleCollapseHandler,
    reorderLists: reorderListsHandler
  };
}
