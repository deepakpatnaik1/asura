import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { getActiveFiles } from '@/services/contextFilesDB';
import type { ActiveFile, ContextFileRecord, PendingFile, DisplayFile } from '@/types/contextFiles';
import { secureLog } from '@/utils/secureLogging';

interface UseActiveFilesReturn {
  displayFiles: DisplayFile[];
  loading: boolean;
  error: string | null;
  refreshActiveFiles: () => Promise<void>;
  addPendingFile: (file: PendingFile) => void;
  removePendingFile: (localId: string) => void;
  updatePendingStatus: (localId: string, dbId: string) => void;
  updatePendingToReady: (localId: string, openaiFileId: string, displayName?: string) => void;
}

export function useActiveFiles(): UseActiveFilesReturn {
  const { user } = useAuth();
  const [activeFiles, setActiveFiles] = useState<ActiveFile[]>([]);
  const [pendingFiles, setPendingFiles] = useState<PendingFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const mapToActiveFile = (record: ContextFileRecord): ActiveFile => {
    return {
      id: record.id,
      filename: record.filename,
      title: record.title,
      type: record.file_type,
      status: record.status as 'processing' | 'active' | 'failed'
    };
  };

  const mergeFilesToDisplay = useCallback((): DisplayFile[] => {
    const dbIds = new Set(activeFiles.map(af => af.id));
    const filteredPending = pendingFiles.filter(pf => {
      if (pf.dbId && dbIds.has(pf.dbId)) {
        secureLog.info(`Auto-removing pending file ${pf.localId} - now exists in database`);
        return false;
      }
      return true;
    });

    const pending: DisplayFile[] = filteredPending.map(pf => ({
      id: pf.localId,
      displayName: pf.source === 'physical'
        ? pf.filename
        : pf.displayName,
      status: pf.status,
      source: 'local' as const,
      type: pf.source === 'physical' ? undefined : 'pdf',
      anthropic_file_id: pf.anthropic_file_id
    }));

    const database: DisplayFile[] = activeFiles.map(af => ({
      id: af.id,
      displayName: af.title || af.filename,
      status: af.status,
      source: 'database' as const,
      type: af.type,
      anthropic_file_id: undefined
    }));

    return [...pending, ...database];
  }, [pendingFiles, activeFiles]);

  const refreshActiveFiles = useCallback(async () => {
    if (!user) {
      setActiveFiles([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const records = await getActiveFiles(user.id);

      const mapped = records.map(mapToActiveFile);

      setActiveFiles(mapped);
      secureLog.info(`Loaded ${mapped.length} active files for user`);

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load active files';
      setError(errorMessage);
      secureLog.error('Failed to refresh active files', errorMessage);
      setActiveFiles([]);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    refreshActiveFiles();
  }, [refreshActiveFiles]);

  useEffect(() => {
    if (!user?.id) {
      return;
    }

    const subscription = supabase
      .channel('context_files_updates')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'context_files',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          secureLog.info('Context file updated via real-time', payload.new);

          const newStatus = payload.new.status;

          if (newStatus === 'inactive' || newStatus === 'deleted') {
            secureLog.info(`Removing file ${payload.new.id} from active files (status: ${newStatus})`);
            setActiveFiles((prev) => prev.filter(file => file.id !== payload.new.id));
                                                              
            setPendingFiles((prev) => {
              const filtered = prev.filter(pf => pf.dbId !== payload.new.id);
              if (filtered.length !== prev.length) {
                secureLog.info(`Removed pending file with dbId ${payload.new.id} (file became ${newStatus})`);
              }
              return filtered;
            });
          } else if (newStatus === 'active' || newStatus === 'processing' || newStatus === 'failed') {
            setActiveFiles((prev) =>
              prev.map((file) =>
                file.id === payload.new.id
                  ? {
                      ...file,
                      filename: payload.new.filename || file.filename,
                      title: payload.new.title || file.title,
                      status: newStatus as 'processing' | 'active' | 'failed'
                    }
                  : file
              )
            );
          }
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [user?.id]);

  useEffect(() => {
    const dbIds = new Set(activeFiles.map(af => af.id));
    const hasMatchingDbIds = pendingFiles.some(pf =>
      pf.dbId && dbIds.has(pf.dbId)
    );

    if (hasMatchingDbIds) {
      setPendingFiles(prev => prev.filter(pf => {
        if (pf.dbId && dbIds.has(pf.dbId)) {
          secureLog.info(`Auto-removing pending file ${pf.localId} - now exists in database`);
          return false;
        }
        return true;
      }));
    }
  }, [activeFiles, pendingFiles]);

  const addPendingFile = useCallback((file: PendingFile) => {
    setPendingFiles(prev => [...prev, file]);
    secureLog.info(`Added pending file: ${file.localId}`);
  }, []);

  const removePendingFile = useCallback((localId: string) => {
    setPendingFiles(prev => prev.filter(pf => pf.localId !== localId));
    secureLog.info(`Removed pending file: ${localId}`);
  }, []);

  const updatePendingToReady = useCallback((localId: string, anthropicFileId: string, displayName?: string) => {
    setPendingFiles(prev => prev.map(pf => {
      if (pf.localId === localId) {
        return {
          ...pf,
          status: 'ready' as const,
          anthropic_file_id: anthropicFileId,
          ...(displayName && pf.source === 'google' ? { displayName } : {})
        };
      }
      return pf;
    }));
    secureLog.info(`Pending file ${localId} now ready with anthropic_file_id: ${anthropicFileId}`);
  }, []);

  const updatePendingStatus = useCallback((localId: string, dbId: string) => {
    setPendingFiles(prev => prev.map(pf => {
      if (pf.localId === localId) {
        return {
          ...pf,
          dbId: dbId
        };
      }
      return pf;
    }));
    secureLog.info(`Pending file ${localId} now in database as ${dbId}`);
  }, []);

  return {
    displayFiles: mergeFilesToDisplay(),
    loading,
    error,
    refreshActiveFiles,
    addPendingFile,
    removePendingFile,
    updatePendingStatus,
    updatePendingToReady
  };
}
