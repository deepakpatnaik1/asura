import { useState, useEffect, useMemo, useCallback } from 'react';

interface Message {
  id: string;
  text: string;
  sender: 'Boss' | 'Gunnar';
  dbId?: string;
  timestamp?: string;
}

interface Turn {
  turnNumber: number;
  bossMessage: Message;
  gunnarMessage?: Message;
  startIndex: number;
  endIndex: number;
}

interface UseTurnModeReturn {
  isTurnMode: boolean;
  currentTurnIndex: number | null;
  turns: Turn[];
  totalTurns: number;
  enterTurnMode: () => void;
  exitTurnMode: () => void;
  navigateToTurn: (direction: 'up' | 'down') => void;
  isMessageInCurrentTurn: (messageId: string) => boolean;
}

export const useTurnMode = (messages: Message[]): UseTurnModeReturn => {
  const [isTurnMode, setIsTurnMode] = useState(false);
  const [currentTurnIndex, setCurrentTurnIndex] = useState<number | null>(null);

  const turns = useMemo<Turn[]>(() => {
    const computedTurns: Turn[] = [];
    let turnNumber = 1;
    let i = 0;

    while (i < messages.length) {
      const currentMessage = messages[i];

      if (currentMessage.sender === 'Boss') {
        const bossMessage = currentMessage;
        const startIndex = i;
        let gunnarMessage: Message | undefined;
        let endIndex = i;

        if (i + 1 < messages.length && messages[i + 1].sender === 'Gunnar') {
          gunnarMessage = messages[i + 1];
          endIndex = i + 1;
          i += 2;
        } else {
          i += 1;
        }

        computedTurns.push({
          turnNumber,
          bossMessage,
          gunnarMessage,
          startIndex,
          endIndex
        });

        turnNumber++;
      } else {
        i++;
      }
    }

    return computedTurns;
  }, [messages]);

  const totalTurns = turns.length;

  const enterTurnMode = useCallback(() => {
    setIsTurnMode(true);
    if (turns.length > 0) {
      setCurrentTurnIndex(turns.length - 1);
    }
  }, [turns.length]);

  const exitTurnMode = useCallback(() => {
    setIsTurnMode(false);
    setCurrentTurnIndex(null);
  }, []);

  const navigateToTurn = useCallback((direction: 'up' | 'down') => {
    if (!isTurnMode || currentTurnIndex === null || turns.length === 0) return;

    if (direction === 'up') {
      const newIndex = Math.max(0, currentTurnIndex - 1);
      setCurrentTurnIndex(newIndex);
    } else if (direction === 'down') {
      const newIndex = Math.min(turns.length - 1, currentTurnIndex + 1);
      setCurrentTurnIndex(newIndex);
    }
  }, [isTurnMode, currentTurnIndex, turns.length]);

  const isMessageInCurrentTurn = useCallback((messageId: string) => {
    if (!isTurnMode || currentTurnIndex === null || turns.length === 0) {
      return false;
    }

    const currentTurn = turns[currentTurnIndex];
    if (!currentTurn) return false;

    return currentTurn.bossMessage.id === messageId ||
           (currentTurn.gunnarMessage && currentTurn.gunnarMessage.id === messageId);
  }, [isTurnMode, currentTurnIndex, turns]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      
      const isModifierPressed = event.ctrlKey || event.metaKey;

      if (isModifierPressed && event.key === 'ArrowUp') {
        event.preventDefault();
        if (!isTurnMode) {
          enterTurnMode();
        } else {
          navigateToTurn('up');
        }
      } else if (isModifierPressed && event.key === 'ArrowDown') {
        event.preventDefault();
        if (isTurnMode) {
          navigateToTurn('down');
        }
      } else if (event.key === 'Escape') {
        event.preventDefault();
        if (isTurnMode) {
          exitTurnMode();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isTurnMode, enterTurnMode, navigateToTurn, exitTurnMode]);

  useEffect(() => {
    if (isTurnMode && currentTurnIndex !== null) {
      if (currentTurnIndex >= turns.length) {
        if (turns.length > 0) {
          setCurrentTurnIndex(turns.length - 1);
        } else {
          exitTurnMode();
        }
      }
    }
  }, [turns.length, currentTurnIndex, isTurnMode, exitTurnMode]);

  return {
    isTurnMode,
    currentTurnIndex,
    turns,
    totalTurns,
    enterTurnMode,
    exitTurnMode,
    navigateToTurn,
    isMessageInCurrentTurn
  };
};