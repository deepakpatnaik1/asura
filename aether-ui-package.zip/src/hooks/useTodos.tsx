import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import {
  getTodos,
  createTodo,
  updateTodo,
  deleteTodo,
  moveTodo,
  toggleComplete,
  toggleStar,
  reorderTodos
} from '@/services/todosDB';
import type {
  Todo,
  CreateTodoParams,
  UpdateTodoParams,
  MoveTodoParams
} from '@/types/todos';
import { secureLog } from '@/utils/secureLogging';

interface UseTodosReturn {
  todos: Todo[];
  isLoading: boolean;
  error: string | null;
  refreshTodos: () => Promise<void>;
  createTodo: (params: Omit<CreateTodoParams, 'user_id'>) => Promise<Todo>;
  updateTodo: (todoId: string, updates: UpdateTodoParams) => Promise<void>;
  deleteTodo: (todoId: string) => Promise<void>;
  moveTodo: (todoId: string, params: MoveTodoParams) => Promise<void>;
  toggleComplete: (todoId: string) => Promise<void>;
  toggleStar: (todoId: string) => Promise<void>;
  reorderTodos: (todoIds: string[], listId?: string, calendarDate?: string) => Promise<void>;
}

export function useTodos(): UseTodosReturn {
  const { user } = useAuth();
  const [todos, setTodos] = useState<Todo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  
  const loadTodos = useCallback(async () => {
    if (!user) {
      setTodos([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      
      const data = await getTodos(user.id);
      setTodos(data);
      secureLog.info(`Loaded ${data.length} todos for user`);

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load todos';
      setError(errorMessage);
      secureLog.error('Failed to load todos', errorMessage);
      setTodos([]);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadTodos();
  }, [loadTodos]);

  
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (!document.hidden && user) {
        secureLog.info('Window visible again - refreshing todos');
        loadTodos();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [user, loadTodos]);

  
  useEffect(() => {
    if (!user?.id) {
      return;
    }

    const refreshSubscription = supabase
      .channel('todo_refresh_events')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'todo_refresh_events',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          secureLog.info('🔔 Refresh event received from AI tools - reloading todos');
          loadTodos();
        }
      )
      .subscribe();

    
    const todosSubscription = supabase
      .channel('todos_updates')
      .on(
        'postgres_changes',
        {
          event: '*', 
          schema: 'public',
          table: 'todos',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          secureLog.info(`Todo ${payload.eventType}`, payload.new || payload.old);

          if (payload.eventType === 'INSERT') {
            
            const newTodo = payload.new as Todo;
            setTodos((prev) => {
              
              if (prev.some(todo => todo.id === newTodo.id)) {
                return prev;
              }
              return [...prev, newTodo];
            });
          } else if (payload.eventType === 'UPDATE') {
            
            const updatedTodo = payload.new as Todo;
            setTodos((prev) =>
              prev.map((todo) =>
                todo.id === updatedTodo.id ? updatedTodo : todo
              )
            );
          } else if (payload.eventType === 'DELETE') {
            
            const deletedTodo = payload.old as Todo;
            setTodos((prev) => prev.filter(todo => todo.id !== deletedTodo.id));
          }
        }
      )
      .subscribe();

    return () => {
      refreshSubscription.unsubscribe();
      todosSubscription.unsubscribe();
    };
  }, [user?.id, loadTodos]);

  
  useEffect(() => {
    if (!user) {
      setTodos([]);
      setError(null);
      setLoading(false);
    }
  }, [user]);

  
  const createTodoHandler = useCallback(async (
    params: Omit<CreateTodoParams, 'user_id'>
  ): Promise<Todo> => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      setError(null);

      
      const optimisticTodo: Todo = {
        id: crypto.randomUUID(), 
        user_id: user.id,
        list_id: params.list_id || null,
        calendar_date: params.calendar_date || null,
        text: params.text,
        date_text: params.date_text || null,
        completed: false,
        starred: false,
        position: params.position,
        completed_at: null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      
      setTodos((prev) => [...prev, optimisticTodo]);

      
      createTodo({
        ...params,
        user_id: user.id
      }).then((newTodo) => {
        secureLog.info(`Created todo: ${params.text}`);
        
        setTodos((prev) =>
          prev.map(todo => todo.id === optimisticTodo.id ? newTodo : todo)
        );
        
        optimisticTodo.id = newTodo.id;
      }).catch((err) => {
        
        setTodos((prev) => prev.filter(todo => todo.id !== optimisticTodo.id));
        const errorMessage = err instanceof Error ? err.message : 'Failed to create todo';
        setError(errorMessage);
        secureLog.error('Failed to create todo', errorMessage);
      });

      
      return optimisticTodo;

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to create todo';
      setError(errorMessage);
      secureLog.error('Failed to create todo', errorMessage);
      throw err;
    }
  }, [user]);

  
  const updateTodoHandler = useCallback(async (
    todoId: string,
    updates: UpdateTodoParams
  ) => {
    try {
      setError(null);
      await updateTodo(todoId, updates);
      secureLog.info(`Updated todo: ${todoId}`);
      

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update todo';
      setError(errorMessage);
      secureLog.error('Failed to update todo', errorMessage);
      throw err;
    }
  }, []);

  
  const deleteTodoHandler = useCallback(async (todoId: string) => {
    try {
      setError(null);
      await deleteTodo(todoId);
      secureLog.info(`Deleted todo: ${todoId}`);
      

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to delete todo';
      setError(errorMessage);
      secureLog.error('Failed to delete todo', errorMessage);
      throw err;
    }
  }, []);

  
  const moveTodoHandler = useCallback(async (
    todoId: string,
    params: MoveTodoParams
  ) => {
    try {
      setError(null);

      
      setTodos((prev) =>
        prev.map((todo) => {
          if (todo.id === todoId) {
            return {
              ...todo,
              list_id: params.toListId !== undefined ? params.toListId : todo.list_id,
              calendar_date: params.toCalendarDate !== undefined ? params.toCalendarDate : todo.calendar_date,
              position: params.position !== undefined ? params.position : todo.position,
              updated_at: new Date().toISOString()
            };
          }
          return todo;
        })
      );

      await moveTodo(todoId, params);
      secureLog.info(`Moved todo: ${todoId}`);
      

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to move todo';
      setError(errorMessage);
      secureLog.error('Failed to move todo', errorMessage);
      
      loadTodos();
      throw err;
    }
  }, [loadTodos]);

  
  const toggleCompleteHandler = useCallback(async (todoId: string) => {
    try {
      setError(null);
      await toggleComplete(todoId);
      secureLog.info(`Toggled complete for todo: ${todoId}`);
      

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to toggle complete';
      setError(errorMessage);
      secureLog.error('Failed to toggle complete', errorMessage);
      throw err;
    }
  }, []);

  
  const toggleStarHandler = useCallback(async (todoId: string) => {
    try {
      setError(null);
      await toggleStar(todoId);
      secureLog.info(`Toggled star for todo: ${todoId}`);
      

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to toggle star';
      setError(errorMessage);
      secureLog.error('Failed to toggle star', errorMessage);
      throw err;
    }
  }, []);

  
  const reorderTodosHandler = useCallback(async (
    todoIds: string[],
    listId?: string,
    calendarDate?: string
  ) => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      setError(null);
      await reorderTodos(user.id, todoIds, listId, calendarDate);
      secureLog.info(`Reordered ${todoIds.length} todos`);
      

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to reorder todos';
      setError(errorMessage);
      secureLog.error('Failed to reorder todos', errorMessage);
      throw err;
    }
  }, [user]);

  return {
    todos,
    isLoading: loading,
    error,
    refreshTodos: loadTodos,
    createTodo: createTodoHandler,
    updateTodo: updateTodoHandler,
    deleteTodo: deleteTodoHandler,
    moveTodo: moveTodoHandler,
    toggleComplete: toggleCompleteHandler,
    toggleStar: toggleStarHandler,
    reorderTodos: reorderTodosHandler
  };
}
