import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { retrieveContextFiles, formatContextFilesForLLM } from '@/services/contextFileRetrieval';
import { ContextFilesState, DisplayFile } from '@/types/contextFiles';
import { secureLog } from '@/utils/secureLogging';
import type { AttachmentContent } from '@/services/llm/types';

interface UseContextFilesReturn {
  contextFilesState: ContextFilesState;
  contextFilesForLLM: AttachmentContent[];
  refreshContextFiles: () => Promise<void>;
  mergePendingReadyFiles: (displayFiles: DisplayFile[]) => void;
}

export const useContextFiles = (): UseContextFilesReturn => {
  const { user } = useAuth();
  const [contextFilesState, setContextFilesState] = useState<ContextFilesState>({
    files: [],
    isLoading: false,
    error: null
  });
  const [pendingReadyFiles, setPendingReadyFiles] = useState<DisplayFile[]>([]);

  const hasLoadedRef = useRef(false);
  const loadingRef = useRef(false);

  const loadContextFiles = async (): Promise<void> => {
    if (!user?.id || loadingRef.current) {
      return;
    }

    loadingRef.current = true;
    setContextFilesState(prev => ({
      ...prev,
      isLoading: true,
      error: null
    }));

    try {
      secureLog.info('Loading context files for authenticated user');

      const result = await retrieveContextFiles(user.id);

      if (result.success) {
        setContextFilesState({
          files: result.files || [],
          isLoading: false,
          error: null
        });
        hasLoadedRef.current = true;
        secureLog.info(`Successfully loaded ${result.files?.length || 0} context files`);
      } else {
        setContextFilesState({
          files: [],
          isLoading: false,
          error: result.error || 'Failed to load context files'
        });
        secureLog.error('Context files loading failed', result.error);
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      setContextFilesState({
        files: [],
        isLoading: false,
        error: errorMessage
      });
      secureLog.error('Context files loading exception', errorMessage);
    } finally {
      loadingRef.current = false;
    }
  };

  const refreshContextFiles = async (): Promise<void> => {
    hasLoadedRef.current = false;
    await loadContextFiles();
  };

  useEffect(() => {
    if (user?.id && !hasLoadedRef.current && !loadingRef.current) {
      loadContextFiles();
    }
  }, [user?.id]);

  useEffect(() => {
    if (!user) {
      setContextFilesState({
        files: [],
        isLoading: false,
        error: null
      });
      hasLoadedRef.current = false;
      loadingRef.current = false;
    }
  }, [user]);

  const mergePendingReadyFiles = (displayFiles: DisplayFile[]) => {
    const ready = displayFiles.filter(df =>
      df.source === 'local' &&
      df.status === 'ready' &&
      df.anthropic_file_id
    );
    setPendingReadyFiles(ready);
  };

  const databaseFilesForLLM: AttachmentContent[] = formatContextFilesForLLM(contextFilesState.files);

  const pendingFilesForLLM: AttachmentContent[] = pendingReadyFiles.map(pf => ({
    filename: pf.displayName,
    type: pf.type || 'pdf',
    file_id: pf.anthropic_file_id!
  }));

  const contextFilesForLLM = [...databaseFilesForLLM, ...pendingFilesForLLM];

  return {
    contextFilesState,
    contextFilesForLLM,
    refreshContextFiles,
    mergePendingReadyFiles
  };
};