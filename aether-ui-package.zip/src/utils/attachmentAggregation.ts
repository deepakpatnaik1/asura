import { AttachmentContent, MultimodalContent } from '@/services/llm/types';

export interface ProcessedAttachment {
  filename?: string;
  type: string;
  url?: string;
  title?: string;
  file_id?: string;
}

export function aggregateAttachmentsToBundle(
  contextFiles: AttachmentContent[],
  immediateAttachments: ProcessedAttachment[]
): AttachmentContent | undefined {
  if (contextFiles.length === 0 && immediateAttachments.length === 0) {
    return undefined;
  }

  const multimodalContent: MultimodalContent[] = [];
  const textContent: string[] = [];
  const allFilenames: string[] = [];
  let hasMultimodalContent = false;

  if (contextFiles.length > 0) {
    textContent.push('=== SYSTEM CONTEXT BUNDLE ===');
    textContent.push('Files from previous conversations (AI memory):');
    textContent.push('');

    contextFiles.forEach((contextFile, index) => {
      const filename = contextFile.filename;
      allFilenames.push(filename);

      if (!contextFile.file_id) {
        throw new Error(`Context file ${filename} missing file_id`);
      }

      hasMultimodalContent = true;

      multimodalContent.push({
        type: 'text',
        text: `--- Context File ${index + 1}: ${filename} ---\nType: ${contextFile.type}`
      });

      multimodalContent.push({
        type: 'input_file',
        file_id: contextFile.file_id,
        file_type: contextFile.type
      });
    });
  }

  if (immediateAttachments.length > 0) {
    if (contextFiles.length > 0) {
      textContent.push('=== USER QUERY BUNDLE ===');
    }
    textContent.push('Files and URLs attached to current message:');
    textContent.push('');

    immediateAttachments.forEach((attachment, index) => {
      if (attachment.type === 'url') {
        const title = attachment.title || 'URL';
        textContent.push(`--- URL ${index + 1}: ${title} ---`);
        textContent.push(`URL: ${attachment.url}`);
        textContent.push(`Type: ${attachment.type}`);
        if (attachment.title) {
          textContent.push(`Title: ${attachment.title}`);
        }
        textContent.push('');

        allFilenames.push(title);
      } else {
        const filename = attachment.filename || `file-${index + 1}`;
        allFilenames.push(filename);

        if (!attachment.file_id) {
          throw new Error(`Immediate attachment ${filename} missing file_id`);
        }

        hasMultimodalContent = true;

        multimodalContent.push({
          type: 'text',
          text: `--- Attachment ${index + 1}: ${filename} ---\nType: ${attachment.type}`
        });

        multimodalContent.push({
          type: 'input_file',
          file_id: attachment.file_id,
          file_type: attachment.type
        });

        console.log(`Using file_id for immediate attachment: ${filename} → ${attachment.file_id}`);
      }
    });
  }

  const filename = allFilenames.length > 1
    ? `bundle-${allFilenames.length}-files.txt`
    : allFilenames[0] || 'attachment-bundle.txt';

  if (hasMultimodalContent) {
    const finalContent: MultimodalContent[] = [];

    if (textContent.length > 0) {
      finalContent.push({
        type: 'text',
        text: textContent.join('\n')
      });
    }

    finalContent.push(...multimodalContent);

    return {
      content: finalContent,
      filename,
      type: 'multimodal'
    };
  } else {
    return {
      content: textContent.join('\n'),
      filename,
      type: 'text/plain'
    };
  }
}