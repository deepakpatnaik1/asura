export interface RetryOptions {
  maxRetries?: number;

  timeoutMs?: number;

  initialDelayMs?: number;

  maxDelayMs?: number;

  backoffMultiplier?: number;
}

export interface RetryResult<T> {
  success: boolean;

  data?: T;

  error?: string;

  attempts: number;
}

export async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  options: RetryOptions = {}
): Promise<RetryResult<T>> {
  const {
    maxRetries = 2,
    timeoutMs = 10000,
    initialDelayMs = 1000,
    maxDelayMs = 10000,
    backoffMultiplier = 2
  } = options;

  let lastError: string | undefined;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    let timeoutId: number | undefined;

    try {
      console.log(`[RetryHelper] Attempt ${attempt + 1}/${maxRetries + 1}...`);

      const timeoutPromise = new Promise<never>((_, reject) => {
        timeoutId = setTimeout(() => reject(new Error('Request timeout')), timeoutMs) as unknown as number;
      });

      const data = await Promise.race([fn(), timeoutPromise]);

      if (timeoutId !== undefined) {
        clearTimeout(timeoutId);
      }

      console.log(`[RetryHelper] Attempt ${attempt + 1} succeeded`);
      return {
        success: true,
        data,
        attempts: attempt + 1
      };

    } catch (error) {
      if (timeoutId !== undefined) {
        clearTimeout(timeoutId);
      }

      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      lastError = errorMessage;

      console.log(`[RetryHelper] Attempt ${attempt + 1} failed: ${errorMessage}`);

      const retryable = isRetryable(error);
      const isLastAttempt = attempt === maxRetries;

      if (!retryable || isLastAttempt) {
        console.log(`[RetryHelper] Not retrying (retryable=${retryable}, isLastAttempt=${isLastAttempt})`);
        return {
          success: false,
          error: errorMessage,
          attempts: attempt + 1
        };
      }

      const baseDelay = Math.min(
        initialDelayMs * Math.pow(backoffMultiplier, attempt),
        maxDelayMs
      );

      const jitter = (Math.random() - 0.5) * 0.6 * baseDelay;
      const delay = Math.max(0, baseDelay + jitter);

      console.log(`[RetryHelper] Retrying in ${Math.round(delay)}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  return {
    success: false,
    error: lastError || 'All retry attempts failed',
    attempts: maxRetries + 1
  };
}

function isRetryable(error: unknown): boolean {
  if (!(error instanceof Error)) return false;

  const message = error.message.toLowerCase();

  if (
    message.includes('network') ||
    message.includes('timeout') ||
    message.includes('fetch') ||
    message.includes('failed to fetch') ||
    message.includes('connection') ||
    message.includes('networkerror')
  ) {
    return true;
  }

  if (
    message.includes('500') ||
    message.includes('502') ||
    message.includes('503') ||
    message.includes('504') ||
    message.includes('server error')
  ) {
    return true;
  }

  if (message.includes('429') || message.includes('rate limit')) {
    return true;
  }

  if (
    message.includes('400') ||
    message.includes('401') ||
    message.includes('403') ||
    message.includes('404') ||
    message.includes('invalid') ||
    message.includes('authentication') ||
    message.includes('unauthorized') ||
    message.includes('forbidden')
  ) {
    return false;
  }

  return false;
}
