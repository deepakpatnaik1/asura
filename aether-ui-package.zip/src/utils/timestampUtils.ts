
export function getLocalTimestampWithOffset(): string {
  const now = new Date();
  
  
  const timezoneOffsetMinutes = -now.getTimezoneOffset();
  
  
  const offsetHours = Math.floor(Math.abs(timezoneOffsetMinutes) / 60);
  const offsetMinutes = Math.abs(timezoneOffsetMinutes) % 60;
  
  
  const offsetSign = timezoneOffsetMinutes >= 0 ? '+' : '-';
  const offsetString = `${offsetSign}${String(offsetHours).padStart(2, '0')}:${String(offsetMinutes).padStart(2, '0')}`;
  
  
  const localTime = new Date(now.getTime() - (now.getTimezoneOffset() * 60000));
  const isoWithoutZ = localTime.toISOString().slice(0, -1); 
  
  return `${isoWithoutZ}${offsetString}`;
}

export function getTimezoneOffset(): string {
  const now = new Date();
  const timezoneOffsetMinutes = -now.getTimezoneOffset();
  
  const offsetHours = Math.floor(Math.abs(timezoneOffsetMinutes) / 60);
  const offsetMinutes = Math.abs(timezoneOffsetMinutes) % 60;
  
  const offsetSign = timezoneOffsetMinutes >= 0 ? '+' : '-';
  return `${offsetSign}${String(offsetHours).padStart(2, '0')}:${String(offsetMinutes).padStart(2, '0')}`;
}
