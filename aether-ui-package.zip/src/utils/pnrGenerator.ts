import { SupabaseClient } from '@supabase/supabase-js';

   
                                                      
  
                                                                               
                                                     
  
                                                           
                                                       
                                                  
  
           
                
                                            
                                                       
      
   
export function generatePNR(content: string): string {
  if (content === null || content === undefined) {
    throw new Error('Content cannot be null or undefined');
  }

                                                                            
                                                                             
  let hash = 0;
  for (let i = 0; i < content.length; i++) {
    const char = content.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit integer
  }

                                                   
  const positiveHash = Math.abs(hash);
  const base36 = positiveHash.toString(36).toUpperCase();

                                    
  const pnr = (base36 + '000000').slice(0, 6);

  return pnr;
}

   
                                                      
  
                                                                    
                                                        
  
                                                      
                                                                            
                                               
                                        
  
           
                
                                                        
                                               
                                                       
      
   
export async function generatePNRFromFile(file: File | Blob): Promise<string> {
  if (file === null || file === undefined) {
    throw new Error('File cannot be null or undefined');
  }

  try {
                                
    const text = await file.text();

                                                   
    return generatePNR(text);
  } catch (error) {
    throw new Error(`Failed to generate PNR from file: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

   
                                                     
  
                                                                     
                                           
  
                                         
                                                 
                                             
                                                                          
                                          
  
           
                
                                                                               
                      
                                        
    
      
   
export async function checkPNRCollision(
  pnrCode: string,
  userId: string,
  supabase: SupabaseClient
): Promise<boolean> {
  const { data, error } = await supabase
    .from('context_files')
    .select('pnr_code')
    .eq('pnr_code', pnrCode)
    .eq('user_id', userId)
    .limit(1);

  if (error) {
    throw new Error(`Collision check failed: ${error.message}`);
  }

  return data !== null && data.length > 0;
}
