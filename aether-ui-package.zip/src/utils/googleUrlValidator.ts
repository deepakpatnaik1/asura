export interface GoogleUrlValidationResult {
  isValid: boolean;
  type?: 'docs' | 'sheets' | 'slides';
  documentId?: string;
  error?: string;
}

const GOOGLE_DOCS_REGEX = /^https?:\/\/docs\.google\.com\/document\/d\/([a-zA-Z0-9_-]+)/;
const GOOGLE_SHEETS_REGEX = /^https?:\/\/docs\.google\.com\/spreadsheets\/d\/([a-zA-Z0-9_-]+)/;
const GOOGLE_SLIDES_REGEX = /^https?:\/\/docs\.google\.com\/presentation\/d\/([a-zA-Z0-9_-]+)/;

export function validateGoogleUrl(url: string): GoogleUrlValidationResult {
  const trimmedUrl = url.trim();

  const docsMatch = trimmedUrl.match(GOOGLE_DOCS_REGEX);
  if (docsMatch) {
    return {
      isValid: true,
      type: 'docs',
      documentId: docsMatch[1]
    };
  }

  const sheetsMatch = trimmedUrl.match(GOOGLE_SHEETS_REGEX);
  if (sheetsMatch) {
    return {
      isValid: true,
      type: 'sheets',
      documentId: sheetsMatch[1]
    };
  }

  const slidesMatch = trimmedUrl.match(GOOGLE_SLIDES_REGEX);
  if (slidesMatch) {
    return {
      isValid: true,
      type: 'slides',
      documentId: slidesMatch[1]
    };
  }

  return {
    isValid: false,
    error: 'Invalid Google URL. Please provide a valid Google Docs, Sheets, or Slides URL.'
  };
}

export function isGoogleUrl(text: string): boolean {
  const trimmedText = text.trim();
  return (
    trimmedText.includes('docs.google.com/document') ||
    trimmedText.includes('docs.google.com/spreadsheets') ||
    trimmedText.includes('docs.google.com/presentation')
  );
}
