interface Message {
  id: string;
  text: string;
  sender: string;
  dbId?: string;
  timestamp?: string;
}

export function findMessagesInTurn(
  messageId: string,
  messages: Message[]
): { bossMessage: Message; aiMessage: Message } | null {
  const messageIndex = messages.findIndex(m => m.id === messageId);

  if (messageIndex === -1) {
    return null;
  }

  const message = messages[messageIndex];

  if (message.sender === 'Boss') {
    if (messageIndex === messages.length - 1) {
      return null;
    }

    const aiMessage = messages[messageIndex + 1];

    if (aiMessage.sender === 'Boss') {
      return null;
    }

    return {
      bossMessage: message,
      aiMessage
    };
  }

  if (messageIndex === 0) {
    return null;
  }

  const bossMessage = messages[messageIndex - 1];

  if (bossMessage.sender !== 'Boss') {
    return null;
  }

  return {
    bossMessage,
    aiMessage: message
  };
}

export function constructRethinkPrompt(
  bossMessage: string,
  aiResponse: string,
  corrections: Array<{ highlightedText: string; feedback: string }>
): string {
  const correctionsList = corrections
    .map(c => `- "${c.highlightedText}" → Boss: "${c.feedback}"`)
    .join('\n');

  const prompt = `Boss's original message: ${bossMessage}

Your previous response: ${aiResponse}

Boss's corrections:
${correctionsList}

Regenerate your response with these corrections.`;

  return prompt;
}
