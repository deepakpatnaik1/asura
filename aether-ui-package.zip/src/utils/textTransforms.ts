
export function replaceEmDashes(text: string): string {
  return text.replace(/—/g, ' – ');
}
