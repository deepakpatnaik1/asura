export interface AppError {
  type: 'network' | 'api' | 'database' | 'clipboard' | 'auth' | 'unknown';
  message: string;
  details?: string;
  recoverable?: boolean;
}

export const ERROR_MESSAGES = {
  CLIPBOARD: {
    COPY_FAILED: 'Failed to copy to clipboard. Please copy manually.',
  },
  GENERAL: {
    UNKNOWN_ERROR: 'An unexpected error occurred. Please try again.',
  },
} as const;

export const createError = (
  type: AppError['type'],
  message: string,
  details?: string,
  recoverable: boolean = true
): AppError => ({
  type,
  message,
  details,
  recoverable,
});

export const getErrorMessage = (error: unknown): string => {
  if (error instanceof Error) {
    return error.message;
  }
  if (typeof error === 'string') {
    return error;
  }
  return ERROR_MESSAGES.GENERAL.UNKNOWN_ERROR;
};