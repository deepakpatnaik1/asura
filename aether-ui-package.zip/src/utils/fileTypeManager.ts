export interface FileTypeInfo {
  extension: string;
  mimeType: string;
  category: 'image' | 'document' | 'presentation' | 'text' | 'code';
  isSupported: boolean;
  maxSize?: number;
  description: string;
}

export interface FileTypeValidationResult {
  isValid: boolean;
  fileType?: FileTypeInfo;
  error?: string;
  category?: string;
}

export const FILE_TYPE_REGISTRY: Record<string, FileTypeInfo> = {
  'png': {
    extension: 'png',
    mimeType: 'image/png',
    category: 'image',
    isSupported: true,
    maxSize: 10 * 1024 * 1024,
    description: 'Portable Network Graphics'
  },
  'jpg': {
    extension: 'jpg',
    mimeType: 'image/jpeg',
    category: 'image',
    isSupported: true,
    maxSize: 10 * 1024 * 1024,
    description: 'JPEG Image'
  },
  'jpeg': {
    extension: 'jpeg',
    mimeType: 'image/jpeg',
    category: 'image',
    isSupported: true,
    maxSize: 10 * 1024 * 1024,
    description: 'JPEG Image'
  },
  'gif': {
    extension: 'gif',
    mimeType: 'image/gif',
    category: 'image',
    isSupported: true,
    maxSize: 10 * 1024 * 1024,
    description: 'Graphics Interchange Format'
  },
  'webp': {
    extension: 'webp',
    mimeType: 'image/webp',
    category: 'image',
    isSupported: true,
    maxSize: 10 * 1024 * 1024,
    description: 'WebP Image'
  },

  'pdf': {
    extension: 'pdf',
    mimeType: 'application/pdf',
    category: 'document',
    isSupported: true,
    maxSize: 50 * 1024 * 1024,
    description: 'Portable Document Format'
  },
  'doc': {
    extension: 'doc',
    mimeType: 'application/msword',
    category: 'document',
    isSupported: true,
    maxSize: 25 * 1024 * 1024,
    description: 'Microsoft Word Document'
  },
  'docx': {
    extension: 'docx',
    mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    category: 'document',
    isSupported: true,
    maxSize: 25 * 1024 * 1024,
    description: 'Microsoft Word Document (OpenXML)'
  },
  'txt': {
    extension: 'txt',
    mimeType: 'text/plain',
    category: 'document',
    isSupported: true,
    maxSize: 5 * 1024 * 1024,
    description: 'Plain Text'
  },

  'pptx': {
    extension: 'pptx',
    mimeType: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    category: 'presentation',
    isSupported: true,
    maxSize: 25 * 1024 * 1024,
    description: 'Microsoft PowerPoint Presentation (OpenXML)'
  },

  'md': {
    extension: 'md',
    mimeType: 'text/markdown',
    category: 'text',
    isSupported: true,
    maxSize: 5 * 1024 * 1024,
    description: 'Markdown Document'
  },
  'html': {
    extension: 'html',
    mimeType: 'text/html',
    category: 'text',
    isSupported: true,
    maxSize: 5 * 1024 * 1024,
    description: 'HTML Document'
  },
  'json': {
    extension: 'json',
    mimeType: 'application/json',
    category: 'text',
    isSupported: true,
    maxSize: 5 * 1024 * 1024,
    description: 'JSON Document'
  },

  'js': {
    extension: 'js',
    mimeType: 'text/javascript',
    category: 'code',
    isSupported: true,
    maxSize: 2 * 1024 * 1024,
    description: 'JavaScript File'
  },
  'ts': {
    extension: 'ts',
    mimeType: 'text/typescript',
    category: 'code',
    isSupported: true,
    maxSize: 2 * 1024 * 1024,
    description: 'TypeScript File'
  },
  'py': {
    extension: 'py',
    mimeType: 'text/x-python',
    category: 'code',
    isSupported: true,
    maxSize: 2 * 1024 * 1024,
    description: 'Python Script'
  },
  'java': {
    extension: 'java',
    mimeType: 'text/x-java-source',
    category: 'code',
    isSupported: true,
    maxSize: 2 * 1024 * 1024,
    description: 'Java Source File'
  },
  'cpp': {
    extension: 'cpp',
    mimeType: 'text/x-c++src',
    category: 'code',
    isSupported: true,
    maxSize: 2 * 1024 * 1024,
    description: 'C++ Source File'
  },
  'css': {
    extension: 'css',
    mimeType: 'text/css',
    category: 'code',
    isSupported: true,
    maxSize: 2 * 1024 * 1024,
    description: 'Cascading Style Sheets'
  },
  'c': {
    extension: 'c',
    mimeType: 'text/x-c',
    category: 'code',
    isSupported: true,
    maxSize: 2 * 1024 * 1024,
    description: 'C Source File'
  },
  'cs': {
    extension: 'cs',
    mimeType: 'text/x-csharp',
    category: 'code',
    isSupported: true,
    maxSize: 2 * 1024 * 1024,
    description: 'C# Source File'
  },
  'go': {
    extension: 'go',
    mimeType: 'text/x-go',
    category: 'code',
    isSupported: true,
    maxSize: 2 * 1024 * 1024,
    description: 'Go Source File'
  },
  'php': {
    extension: 'php',
    mimeType: 'text/x-php',
    category: 'code',
    isSupported: true,
    maxSize: 2 * 1024 * 1024,
    description: 'PHP Script'
  },
  'rb': {
    extension: 'rb',
    mimeType: 'text/x-ruby',
    category: 'code',
    isSupported: true,
    maxSize: 2 * 1024 * 1024,
    description: 'Ruby Script'
  },
  'sh': {
    extension: 'sh',
    mimeType: 'text/x-shellscript',
    category: 'code',
    isSupported: true,
    maxSize: 2 * 1024 * 1024,
    description: 'Shell Script'
  },
  'tex': {
    extension: 'tex',
    mimeType: 'text/x-tex',
    category: 'code',
    isSupported: true,
    maxSize: 2 * 1024 * 1024,
    description: 'LaTeX Document'
  },

};

export function getFileExtension(filename: string): string {
  return filename.toLowerCase().split('.').pop() || '';
}

export function getFileTypeInfo(extension: string): FileTypeInfo | null {
  return FILE_TYPE_REGISTRY[extension.toLowerCase()] || null;
}

export function detectMimeType(filename: string, originalMimeType?: string): string {
  if (originalMimeType && originalMimeType !== 'application/octet-stream') {
    return originalMimeType;
  }

  const extension = getFileExtension(filename);
  const fileTypeInfo = getFileTypeInfo(extension);

  return fileTypeInfo?.mimeType || 'application/octet-stream';
}

export function validateFile(file: File): FileTypeValidationResult {
  const extension = getFileExtension(file.name);
  const fileTypeInfo = getFileTypeInfo(extension);

  if (!fileTypeInfo) {
    return {
      isValid: false,
      error: `Unsupported file format: .${extension}. Please use a supported file format.`
    };
  }

  if (!fileTypeInfo.isSupported) {
    return {
      isValid: false,
      fileType: fileTypeInfo,
      error: `File format .${extension} is not currently supported.`
    };
  }

  if (fileTypeInfo.maxSize && file.size > fileTypeInfo.maxSize) {
    const maxSizeMB = Math.round(fileTypeInfo.maxSize / (1024 * 1024));
    const fileSizeMB = Math.round(file.size / (1024 * 1024));
    return {
      isValid: false,
      fileType: fileTypeInfo,
      error: `File size (${fileSizeMB}MB) exceeds maximum allowed size of ${maxSizeMB}MB for ${fileTypeInfo.description} files.`
    };
  }

  return {
    isValid: true,
    fileType: fileTypeInfo,
    category: fileTypeInfo.category
  };
}

export function isVisualContent(mimeType: string): boolean {
  return mimeType.startsWith('image/') || mimeType === 'application/pdf';
}

export function getSupportedFilesByCategory(): Record<string, FileTypeInfo[]> {
  const categories: Record<string, FileTypeInfo[]> = {};

  Object.values(FILE_TYPE_REGISTRY).forEach(fileType => {
    if (fileType.isSupported) {
      if (!categories[fileType.category]) {
        categories[fileType.category] = [];
      }
      categories[fileType.category].push(fileType);
    }
  });

  return categories;
}

export function generateFileErrorMessage(filename: string): string {
  const extension = getFileExtension(filename);
  const supportedCategories = getSupportedFilesByCategory();

  let message = `The file "${filename}" has an unsupported format (.${extension}).\n\n`;
  message += 'Supported file formats include:\n\n';

  Object.entries(supportedCategories).forEach(([category, files]) => {
    const extensions = files.map(f => `.${f.extension}`).join(', ');
    const categoryName = category.charAt(0).toUpperCase() + category.slice(1);
    message += `${categoryName}: ${extensions}\n`;
  });

  return message;
}

export function getFileCategory(mimeType: string): string {
  const fileType = Object.values(FILE_TYPE_REGISTRY).find(ft => ft.mimeType === mimeType);
  return fileType?.category || 'other';
}

function inferFileTypeFromExtension(
  filename: string
): 'image' | 'pdf' | 'text' | 'code' | 'spreadsheet' | 'other' {
  const extension = getFileExtension(filename);

  if (extension === 'pdf') return 'pdf';

  if (['txt', 'md', 'markdown', 'rst', 'log'].includes(extension)) return 'text';

  if ([
    'js', 'ts', 'py', 'java', 'cpp', 'c', 'h', 'cs', 'go',
    'php', 'rb', 'sh', 'tex', 'css', 'html', 'json'
  ].includes(extension)) return 'code';

  if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'svg'].includes(extension)) return 'image';

  if (['xlsx', 'xls', 'csv'].includes(extension)) return 'spreadsheet';

  return 'other';
}

export function getFileTypeFromMimeType(
  mimeType: string | null | undefined,
  filename?: string
): 'image' | 'pdf' | 'text' | 'code' | 'spreadsheet' | 'other' {
  if (!mimeType || mimeType === 'application/octet-stream' || mimeType === '') {
    if (filename) {
      return inferFileTypeFromExtension(filename);
    }
    return 'other';
  }

  const normalizedMime = mimeType.toLowerCase().trim();

  if (normalizedMime.startsWith('image/')) {
    return 'image';
  }

  if (normalizedMime === 'application/pdf') {
    return 'pdf';
  }

  if (normalizedMime === 'text/csv') {
    return 'spreadsheet';
  }

  if (normalizedMime.startsWith('text/')) {
    if (
      normalizedMime === 'text/javascript' ||
      normalizedMime === 'text/typescript' ||
      normalizedMime === 'text/x-python' ||
      normalizedMime === 'text/x-java-source' ||
      normalizedMime === 'text/x-c++src' ||
      normalizedMime === 'text/x-c' ||
      normalizedMime === 'text/x-csharp' ||
      normalizedMime === 'text/x-go' ||
      normalizedMime === 'text/x-php' ||
      normalizedMime === 'text/x-ruby' ||
      normalizedMime === 'text/x-shellscript' ||
      normalizedMime === 'text/x-tex' ||
      normalizedMime === 'text/css'
    ) {
      return 'code';
    }
    return 'text';
  }

  if (normalizedMime === 'application/json' || normalizedMime === 'application/xml') {
    return 'code';
  }

  if (
    normalizedMime.includes('spreadsheet') ||
    normalizedMime.includes('excel') ||
    normalizedMime === 'application/vnd.ms-excel' ||
    normalizedMime === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
    normalizedMime === 'text/csv'
  ) {
    return 'spreadsheet';
  }

  return 'other';
}