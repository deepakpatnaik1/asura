
type LogLevel = 'info' | 'warn' | 'error' | 'debug';

interface SecureLogOptions {
  level?: LogLevel;
  sanitize?: boolean;
}

const isDevelopment = import.meta.env.DEV;

const sanitizeData = (data: any): any => {
  if (!data || typeof data !== 'object') {
    return data;
  }

  const sensitiveKeys = ['email', 'password', 'token', 'access_token', 'refresh_token', 'session', 'auth'];
  const sanitized = { ...data };

  Object.keys(sanitized).forEach(key => {
    const lowerKey = key.toLowerCase();
    if (sensitiveKeys.some(sensitive => lowerKey.includes(sensitive))) {
      sanitized[key] = '[REDACTED]';
    } else if (typeof sanitized[key] === 'object' && sanitized[key] !== null) {
      sanitized[key] = sanitizeData(sanitized[key]);
    }
  });

  return sanitized;
};

export const secureLog = {
  info: (message: string, data?: any, options: SecureLogOptions = {}) => {
    if (isDevelopment) {
      console.log(`ℹ️ ${message}`, data);
    } else if (options.sanitize !== false) {
      console.log(`ℹ️ ${message}`, data ? sanitizeData(data) : undefined);
    }
  },

  warn: (message: string, data?: any, options: SecureLogOptions = {}) => {
    if (isDevelopment) {
      console.warn(`⚠️ ${message}`, data);
    } else if (options.sanitize !== false) {
      console.warn(`⚠️ ${message}`, data ? sanitizeData(data) : undefined);
    }
  },

  error: (message: string, data?: any, options: SecureLogOptions = {}) => {
    if (isDevelopment) {
      console.error(`❌ ${message}`, data);
    } else if (options.sanitize !== false) {
      console.error(`❌ ${message}`, data ? sanitizeData(data) : undefined);
    }
  },

  debug: (message: string, data?: any) => {
    if (isDevelopment) {
      console.log(`🔍 ${message}`, data);
    }
  },

  auth: {
    stateChange: (event: string, hasUser: boolean) => {
      if (isDevelopment) {
        console.log(`🔐 Auth state change: ${event}, user: ${hasUser ? 'present' : 'none'}`);
      }
    },

    loginAttempt: (provider: string) => {
      console.log(`🔐 Login attempt with ${provider}`);
    },

    loginSuccess: (provider: string) => {
      console.log(`✅ Login successful with ${provider}`);
    },

    loginError: (provider: string, error: any) => {
      const sanitizedError = isDevelopment ? error : sanitizeData(error);
      console.error(`❌ Login failed with ${provider}`, sanitizedError);
    }
  }
};

export default secureLog;