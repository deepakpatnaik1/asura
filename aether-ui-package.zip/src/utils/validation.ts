import { z } from 'zod';

export const messageSchema = z.object({
  text: z.string()
    .trim()
    .min(1, { message: "Message cannot be empty" }),
  
});

export const fileSchema = z.object({
  name: z.string()
    .min(1, { message: "File name cannot be empty" })
    .max(255, { message: "File name must be less than 255 characters" }),
  size: z.number()
    .min(1, { message: "File cannot be empty" })
    .max(50 * 1024 * 1024, { message: "File must be less than 50MB" }),
  type: z.string()
    .min(1, { message: "File type is required" }),
});

export const urlSchema = z.string()
  .url({ message: "Invalid URL format" })
  .max(2048, { message: "URL must be less than 2048 characters" });

export type MessageInput = z.infer<typeof messageSchema>;
export type FileInput = z.infer<typeof fileSchema>;
export type UrlInput = z.infer<typeof urlSchema>;

export const validateMessage = (data: unknown): MessageInput => {
  return messageSchema.parse(data);
};

export const validateFile = (data: unknown): FileInput => {
  return fileSchema.parse(data);
};

export const validateUrl = (data: unknown): UrlInput => {
  return urlSchema.parse(data);
};