import { supabase } from '@/integrations/supabase/client';
import { secureLog } from '@/utils/secureLogging';
import type {
  Todo,
  CreateTodoParams,
  UpdateTodoParams,
  MoveTodoParams,
  GetTodosFilters
} from '@/types/todos';

export async function getTodos(
  userId: string,
  filters?: GetTodosFilters
): Promise<Todo[]> {
  try {
    secureLog.info(`Fetching todos for user: ${userId}`, filters);

    let query = supabase
      .from('todos')
      .select('*')
      .eq('user_id', userId);

    
    if (filters?.listId) {
      query = query.eq('list_id', filters.listId);
    }

    if (filters?.calendarDate) {
      query = query.eq('calendar_date', filters.calendarDate);
    }

    if (filters?.includeCompleted === false) {
      query = query.eq('completed', false);
    }

    query = query.order('position', { ascending: true });

    const { data, error } = await query;

    if (error) {
      secureLog.error(`Failed to fetch todos for ${userId}`, error.message);
      throw new Error(`Failed to fetch todos: ${error.message}`);
    }

    secureLog.info(`Fetched ${data?.length || 0} todos for user ${userId}`);
    return (data || []) as Todo[];

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception fetching todos for ${userId}`, errorMessage);
    throw new Error(`Failed to fetch todos: ${errorMessage}`);
  }
}

export async function getCompletedTodos(
  userId: string,
  daysBack: number = 7
): Promise<Todo[]> {
  try {
    secureLog.info(`Fetching completed todos for user ${userId} (last ${daysBack} days)`);

    
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysBack);
    const cutoffISO = cutoffDate.toISOString();

    const { data, error } = await supabase
      .from('todos')
      .select('*')
      .eq('user_id', userId)
      .eq('completed', true)
      .gte('completed_at', cutoffISO)
      .order('completed_at', { ascending: false });

    if (error) {
      secureLog.error(`Failed to fetch completed todos for ${userId}`, error.message);
      throw new Error(`Failed to fetch completed todos: ${error.message}`);
    }

    secureLog.info(`Fetched ${data?.length || 0} completed todos`);
    return (data || []) as Todo[];

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception fetching completed todos for ${userId}`, errorMessage);
    throw new Error(`Failed to fetch completed todos: ${errorMessage}`);
  }
}

export async function createTodo(params: CreateTodoParams): Promise<Todo> {
  try {
    secureLog.info(`Creating todo for user ${params.user_id}`, {
      text: params.text,
      list_id: params.list_id,
      calendar_date: params.calendar_date
    });

    
    const hasListId = params.list_id !== null && params.list_id !== undefined;
    const hasCalendarDate = params.calendar_date !== null && params.calendar_date !== undefined;

    if (hasListId === hasCalendarDate) {
      throw new Error('Todo must have either list_id OR calendar_date (not both, not neither)');
    }

    const now = new Date().toISOString();

    const { data, error } = await supabase
      .from('todos')
      .insert({
        user_id: params.user_id,
        list_id: params.list_id || null,
        calendar_date: params.calendar_date || null,
        text: params.text,
        date_text: params.date_text || null,
        starred: params.starred || false,
        position: params.position,
        completed: false,
        completed_at: null,
        created_at: now,
        updated_at: now
      })
      .select()
      .single();

    if (error) {
      secureLog.error(`Failed to create todo`, error.message);
      throw new Error(`Failed to create todo: ${error.message}`);
    }

    if (!data) {
      throw new Error('Todo created but no data returned');
    }

    secureLog.info(`Todo created: ${data.id}`);
    return data as Todo;

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception creating todo`, errorMessage);
    throw new Error(`Failed to create todo: ${errorMessage}`);
  }
}

export async function updateTodo(
  todoId: string,
  updates: UpdateTodoParams
): Promise<void> {
  try {
    secureLog.info(`Updating todo: ${todoId}`, updates);

    
    
    const updateData: Record<string, any> = {
      ...updates,
      updated_at: new Date().toISOString()
    };

    if (updates.completed !== undefined) {
      updateData.completed_at = updates.completed ? new Date().toISOString() : null;
    }

    const { error } = await supabase
      .from('todos')
      .update(updateData)
      .eq('id', todoId);

    if (error) {
      secureLog.error(`Failed to update todo ${todoId}`, error.message);
      throw new Error(`Failed to update todo: ${error.message}`);
    }

    secureLog.info(`Todo updated: ${todoId}`);

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception updating todo ${todoId}`, errorMessage);
    throw new Error(`Failed to update todo: ${errorMessage}`);
  }
}

export async function deleteTodo(todoId: string): Promise<void> {
  try {
    secureLog.info(`Deleting todo: ${todoId}`);

    const { error } = await supabase
      .from('todos')
      .delete()
      .eq('id', todoId);

    if (error) {
      secureLog.error(`Failed to delete todo ${todoId}`, error.message);
      throw new Error(`Failed to delete todo: ${error.message}`);
    }

    secureLog.info(`Todo deleted: ${todoId}`);

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception deleting todo ${todoId}`, errorMessage);
    throw new Error(`Failed to delete todo: ${errorMessage}`);
  }
}

export async function moveTodo(
  todoId: string,
  params: MoveTodoParams
): Promise<void> {
  try {
    secureLog.info(`Moving todo: ${todoId}`, params);

    
    const hasToListId = params.toListId !== null && params.toListId !== undefined;
    const hasToCalendarDate = params.toCalendarDate !== null && params.toCalendarDate !== undefined;

    if (hasToListId === hasToCalendarDate) {
      throw new Error('Must move to either list OR calendar (not both, not neither)');
    }

    const updateData: Record<string, any> = {
      list_id: params.toListId || null,
      calendar_date: params.toCalendarDate || null,
      updated_at: new Date().toISOString()
    };

    
    if (params.position !== undefined) {
      updateData.position = params.position;
    }

    const { error } = await supabase
      .from('todos')
      .update(updateData)
      .eq('id', todoId);

    if (error) {
      secureLog.error(`Failed to move todo ${todoId}`, error.message);
      throw new Error(`Failed to move todo: ${error.message}`);
    }

    secureLog.info(`Todo moved: ${todoId}`);

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception moving todo ${todoId}`, errorMessage);
    throw new Error(`Failed to move todo: ${errorMessage}`);
  }
}

export async function toggleComplete(todoId: string): Promise<void> {
  try {
    secureLog.info(`Toggling complete status for todo: ${todoId}`);

    
    const { data: todo, error: fetchError } = await supabase
      .from('todos')
      .select('completed')
      .eq('id', todoId)
      .single();

    if (fetchError || !todo) {
      throw new Error(`Failed to fetch todo for toggle: ${fetchError?.message || 'Not found'}`);
    }

    const newCompleted = !todo.completed;
    const now = new Date().toISOString();

    const { error } = await supabase
      .from('todos')
      .update({
        completed: newCompleted,
        completed_at: newCompleted ? now : null,
        updated_at: now
      })
      .eq('id', todoId);

    if (error) {
      secureLog.error(`Failed to toggle complete status ${todoId}`, error.message);
      throw new Error(`Failed to toggle complete status: ${error.message}`);
    }

    secureLog.info(`Todo ${todoId} completed status toggled to: ${newCompleted}`);

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception toggling complete status ${todoId}`, errorMessage);
    throw new Error(`Failed to toggle complete status: ${errorMessage}`);
  }
}

export async function toggleStar(todoId: string): Promise<void> {
  try {
    secureLog.info(`Toggling star status for todo: ${todoId}`);

    
    const { data: todo, error: fetchError } = await supabase
      .from('todos')
      .select('starred')
      .eq('id', todoId)
      .single();

    if (fetchError || !todo) {
      throw new Error(`Failed to fetch todo for toggle: ${fetchError?.message || 'Not found'}`);
    }

    const newStarred = !todo.starred;

    const { error } = await supabase
      .from('todos')
      .update({
        starred: newStarred,
        updated_at: new Date().toISOString()
      })
      .eq('id', todoId);

    if (error) {
      secureLog.error(`Failed to toggle star status ${todoId}`, error.message);
      throw new Error(`Failed to toggle star status: ${error.message}`);
    }

    secureLog.info(`Todo ${todoId} starred status toggled to: ${newStarred}`);

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception toggling star status ${todoId}`, errorMessage);
    throw new Error(`Failed to toggle star status: ${errorMessage}`);
  }
}

export async function reorderTodos(
  userId: string,
  todoIds: string[],
  listId?: string,
  calendarDate?: string
): Promise<void> {
  try {
    const context = listId ? `list ${listId}` : `calendar ${calendarDate}`;
    secureLog.info(`Reordering ${todoIds.length} todos in ${context}`);

    
    const hasListId = listId !== null && listId !== undefined;
    const hasCalendarDate = calendarDate !== null && calendarDate !== undefined;

    if (hasListId === hasCalendarDate) {
      throw new Error('Must reorder within either list OR calendar (not both, not neither)');
    }

    const updates = todoIds.map((todoId, index) => {
      const query = supabase
        .from('todos')
        .update({
          position: index,
          updated_at: new Date().toISOString()
        })
        .eq('id', todoId)
        .eq('user_id', userId); 

      if (listId) {
        query.eq('list_id', listId);
      } else {
        query.eq('calendar_date', calendarDate);
      }

      return query;
    });

    
    const results = await Promise.all(updates);

    
    const errors = results.filter(result => result.error);
    if (errors.length > 0) {
      const errorMessages = errors.map(r => r.error?.message).join(', ');
      secureLog.error(`Failed to reorder todos`, errorMessages);
      throw new Error(`Failed to reorder todos: ${errorMessages}`);
    }

    secureLog.info(`Successfully reordered ${todoIds.length} todos in ${context}`);

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception reordering todos`, errorMessage);
    throw new Error(`Failed to reorder todos: ${errorMessage}`);
  }
}
