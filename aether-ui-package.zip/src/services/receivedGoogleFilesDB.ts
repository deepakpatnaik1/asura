import { supabase } from '@/integrations/supabase/client';

export interface ReceivedGoogleFile {
  id: string;
  user_id: string;
  google_file_id: string;
  google_file_name: string;
  file_type: 'docs' | 'sheets' | 'slides';
  received_at: string;
  context_file_id: string | null;
}

export async function markGoogleFileAsReceived(
  userId: string,
  googleFileId: string,
  googleFileName: string,
  fileType: 'docs' | 'sheets' | 'slides',
  contextFileId: string
): Promise<void> {
  try {
    const { error } = await supabase
      .from('received_google_files')
      .upsert({
        user_id: userId,
        google_file_id: googleFileId,
        google_file_name: googleFileName,
        file_type: fileType,
        context_file_id: contextFileId,
      }, {
        onConflict: 'user_id,google_file_id',
        ignoreDuplicates: false
      });

    if (error) {
      throw new Error(`Failed to mark file as received: ${error.message}`);
    }

    console.log(`✅ Marked Google file as received: ${googleFileId}`);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error marking file as received:', errorMessage);
    throw error;
  }
}

export async function getReceivedGoogleFileIds(userId: string): Promise<string[]> {
  try {
    const { data, error } = await supabase
      .from('received_google_files')
      .select('google_file_id')
      .eq('user_id', userId);

    if (error) {
      throw new Error(`Failed to fetch received files: ${error.message}`);
    }

    return (data || []).map(record => record.google_file_id);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error fetching received file IDs:', errorMessage);
    throw error;
  }
}

export async function clearReceivedGoogleFiles(userId: string): Promise<void> {
  try {
    const { error } = await supabase
      .from('received_google_files')
      .delete()
      .eq('user_id', userId);

    if (error) {
      throw new Error(`Failed to clear received files: ${error.message}`);
    }

    console.log('✅ Cleared all received Google files for user');
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error clearing received files:', errorMessage);
    throw error;
  }
}

export async function unmarkGoogleFileAsReceived(
  userId: string,
  googleFileId: string
): Promise<void> {
  try {
    const { error } = await supabase
      .from('received_google_files')
      .delete()
      .eq('user_id', userId)
      .eq('google_file_id', googleFileId);

    if (error) {
      throw new Error(`Failed to unmark file as received: ${error.message}`);
    }

    console.log(`✅ Unmarked Google file as received: ${googleFileId}`);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error unmarking file as received:', errorMessage);
    throw error;
  }
}
