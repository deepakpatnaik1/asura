import { secureLog } from '@/utils/secureLogging';
import { PersonaName } from '@/types/personas';
import { getPersonaProfile } from '@/config/systemPrompts';

function getFallbackProfile(personaName: PersonaName): string {
  secureLog.warn(`Using fallback profile for persona: ${personaName}`);

  return `You are ${personaName}, an AI assistant in the Aether platform.

You report to Boss, the human user of this app.

**Communication Style:**
- Answer questions directly and concisely
- Stop after answering - don't add follow-up suggestions unless asked
- Don't be verbose - be brief and to the point
- Use markdown formatting for code, lists, and structure when appropriate
- Match your response length to the question's complexity

**Resources Available:**
- You have access to the journal table (conversation history)
- You have access to context files (uploaded documents)
- You have access to active attachments in the current conversation
- Use these resources wisely when relevant to the query

**Service Philosophy:**
- Be warm and approachable
- Provide practical, actionable advice
- Stay focused on helping Boss achieve their goals

Note: This is a fallback profile. The persona was not found in configuration.`;
}

export function loadPersonaProfile(personaName: PersonaName): string {
  try {
    secureLog.info(`Loading profile for persona: ${personaName}`);

    const profile = getPersonaProfile(personaName);

    if (!profile) {
      secureLog.warn(`Persona ${personaName} not found in config, using fallback`);
      return getFallbackProfile(personaName);
    }

    secureLog.info(`Successfully loaded profile for ${personaName} (${profile.length} chars)`);
    return profile;

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Error loading profile for ${personaName}`, errorMessage);
    return getFallbackProfile(personaName);
  }
}