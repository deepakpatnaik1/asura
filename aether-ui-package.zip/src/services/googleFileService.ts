import { supabase } from '@/integrations/supabase/client';

export interface GoogleToPdfResult {
  success: boolean;
  file_id?: string;
  error?: string;
}

export const convertGoogleDocToPdf = async (
  documentId: string,
  type: 'docs' | 'sheets' | 'slides',
  filename: string
): Promise<GoogleToPdfResult> => {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      throw new Error('No authentication session');
    }

    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const response = await fetch(`${supabaseUrl}/functions/v1/google-to-pdf`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({
        documentId,
        type,
        filename,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Unknown error' }));
      return {
        success: false,
        error: errorData.error || `HTTP ${response.status}`,
      };
    }

    const result = await response.json();
    return result;

  } catch (error) {
    console.error('Google to PDF conversion failed:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
};
