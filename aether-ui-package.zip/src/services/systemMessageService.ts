import { supabase } from '@/integrations/supabase/client';
import type { SystemMessageType } from '@/types/systemMessages';
import type { RealtimeChannel } from '@supabase/supabase-js';

export async function fetchSystemMessages(
  userId: string
): Promise<{ success: boolean; messages?: SystemMessageType[]; error?: string }> {
  try {
    console.log('📥 Fetching system messages for user:', userId);

    
    const threeHoursAgo = new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString();

    const { data, error } = await supabase
      .from('system_messages')
      .select('*')
      .eq('user_id', userId)
      .is('dismissed_at', null) 
      .gt('created_at', threeHoursAgo) 
      .order('created_at', { ascending: true });

    console.log('📥 Fetched messages:', { count: data?.length, data, error });

    if (error) {
      console.error('Failed to fetch system messages:', error);
      return { success: false, error: error.message };
    }

    return { success: true, messages: data || [] };
  } catch (error) {
    console.error('Exception fetching system messages:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

export function subscribeToSystemMessages(
  userId: string,
  callback: (message: SystemMessageType) => void
): RealtimeChannel {
  const subscription = supabase
    .channel('system_messages_updates')
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'system_messages',
        filter: `user_id=eq.${userId}`
      },
      (payload) => {
        const newMessage = payload.new as SystemMessageType;
        
        if (!newMessage.dismissed_at) {
          console.log('New system message:', newMessage);
          callback(newMessage);
        }
      }
    )
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'system_messages',
        filter: `user_id=eq.${userId}`
      },
      (payload) => {
        const updatedMessage = payload.new as SystemMessageType;
        
        if (updatedMessage.dismissed_at) {
          console.log('System message dismissed via realtime:', updatedMessage.id);
          
        }
      }
    )
    .subscribe();

  return subscription;
}

export async function deleteSystemMessage(
  messageId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    console.log('📝 Setting dismissed_at for message:', messageId);

    
    const { data, error } = await supabase
      .from('system_messages')
      .update({ dismissed_at: new Date().toISOString() })
      .eq('id', messageId)
      .select();

    console.log('📝 Update response:', { data, error });

    if (error) {
      console.error('Failed to dismiss system message:', error);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (error) {
    console.error('Exception dismissing system message:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

