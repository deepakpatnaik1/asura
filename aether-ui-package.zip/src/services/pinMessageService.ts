import { supabase } from '@/integrations/supabase/client';

interface TogglePinRequest {
  journal_id: string;
}

interface TogglePinResponse {
  success: true;
  journal_id: string;
  is_pinned: boolean;
  updated_tables: string[];
}

interface ErrorResponse {
  error: string;
  details?: string;
}

export async function togglePinMessage(journalId: string): Promise<{
  success: boolean;
  isPinned?: boolean;
  error?: string;
}> {
  try {
    
    
    const response = await supabase.functions.invoke('toggle-pin-message', {
      body: { journal_id: journalId } as TogglePinRequest
    });

    if (response.error) {
      console.error('[togglePinMessage] API error:', response.error);
      return {
        success: false,
        error: response.error.message || 'Failed to toggle pin'
      };
    }

    const data = response.data as TogglePinResponse | ErrorResponse;

    if ('error' in data) {
      console.error('[togglePinMessage] Backend error:', data.error);
      return {
        success: false,
        error: data.error
      };
    }

    console.log(`✅ Pin toggled: journal ${data.journal_id} → ${data.is_pinned ? 'PINNED' : 'UNPINNED'}`);

    return {
      success: true,
      isPinned: data.is_pinned
    };

  } catch (error) {
    console.error('[togglePinMessage] Exception:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}
