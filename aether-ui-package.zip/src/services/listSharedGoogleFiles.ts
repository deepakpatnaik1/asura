import { supabase } from '@/integrations/supabase/client';

export interface SharedGoogleFile {
  id: string;
  name: string;
  mimeType: string;
  modifiedTime: string;
  type: 'docs' | 'sheets' | 'slides';
}

export interface ListSharedFilesResult {
  success: boolean;
  files?: SharedGoogleFile[];
  error?: string;
}

export const listSharedGoogleFiles = async (): Promise<ListSharedFilesResult> => {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      throw new Error('No authentication session');
    }

    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const response = await fetch(`${supabaseUrl}/functions/v1/list-shared-google-files`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${session.access_token}`,
      },
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Unknown error' }));
      return {
        success: false,
        error: errorData.error || `HTTP ${response.status}`,
      };
    }

    const result = await response.json();
    return result;

  } catch (error) {
    console.error('List shared Google files failed:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
};
