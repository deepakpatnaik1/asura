import { supabase } from '@/integrations/supabase/client';
import { secureLog } from '@/utils/secureLogging';
import type { TodoList, CreateTodoListParams, UpdateTodoListParams } from '@/types/todos';

export async function getTodoLists(userId: string): Promise<TodoList[]> {
  try {
    secureLog.info(`Fetching todo lists for user: ${userId}`);

    const { data, error } = await supabase
      .from('todo_lists')
      .select('*')
      .eq('user_id', userId)
      .order('position', { ascending: true });

    if (error) {
      secureLog.error(`Failed to fetch todo lists for ${userId}`, error.message);
      throw new Error(`Failed to fetch todo lists: ${error.message}`);
    }

    secureLog.info(`Fetched ${data?.length || 0} todo lists for user ${userId}`);
    return (data || []) as TodoList[];

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception fetching todo lists for ${userId}`, errorMessage);
    throw new Error(`Failed to fetch todo lists: ${errorMessage}`);
  }
}

export async function createTodoList(params: CreateTodoListParams): Promise<TodoList> {
  try {
    secureLog.info(`Creating todo list: ${params.name} for user ${params.user_id}`);

    const { data, error } = await supabase
      .from('todo_lists')
      .insert({
        user_id: params.user_id,
        name: params.name,
        position: params.position,
        is_protected: params.is_protected || false,
        is_collapsed: false 
      })
      .select()
      .single();

    if (error) {
      secureLog.error(`Failed to create todo list: ${params.name}`, error.message);
      throw new Error(`Failed to create todo list: ${error.message}`);
    }

    if (!data) {
      throw new Error('Todo list created but no data returned');
    }

    secureLog.info(`Todo list created: ${data.id} - ${data.name}`);
    return data as TodoList;

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception creating todo list: ${params.name}`, errorMessage);
    throw new Error(`Failed to create todo list: ${errorMessage}`);
  }
}

export async function updateTodoList(
  listId: string,
  updates: UpdateTodoListParams
): Promise<void> {
  try {
    secureLog.info(`Updating todo list: ${listId}`, updates);

    const { error } = await supabase
      .from('todo_lists')
      .update(updates)
      .eq('id', listId);

    if (error) {
      secureLog.error(`Failed to update todo list ${listId}`, error.message);
      throw new Error(`Failed to update todo list: ${error.message}`);
    }

    secureLog.info(`Todo list updated: ${listId}`);

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception updating todo list ${listId}`, errorMessage);
    throw new Error(`Failed to update todo list: ${errorMessage}`);
  }
}

export async function deleteTodoList(listId: string): Promise<void> {
  try {
    secureLog.info(`Deleting todo list: ${listId}`);

    

    const { error } = await supabase
      .from('todo_lists')
      .delete()
      .eq('id', listId);

    if (error) {
      secureLog.error(`Failed to delete todo list ${listId}`, error.message);
      throw new Error(`Failed to delete todo list: ${error.message}`);
    }

    secureLog.info(`Todo list deleted: ${listId}`);

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception deleting todo list ${listId}`, errorMessage);
    throw new Error(`Failed to delete todo list: ${errorMessage}`);
  }
}

export async function reorderLists(userId: string, listIds: string[]): Promise<void> {
  try {
    secureLog.info(`Reordering ${listIds.length} lists for user ${userId}`);

    
    const updates = listIds.map((listId, index) =>
      supabase
        .from('todo_lists')
        .update({ position: index })
        .eq('id', listId)
        .eq('user_id', userId) 
    );

    
    const results = await Promise.all(updates);

    
    const errors = results.filter(result => result.error);
    if (errors.length > 0) {
      const errorMessages = errors.map(r => r.error?.message).join(', ');
      secureLog.error(`Failed to reorder lists`, errorMessages);
      throw new Error(`Failed to reorder lists: ${errorMessages}`);
    }

    secureLog.info(`Successfully reordered ${listIds.length} lists`);

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception reordering lists for ${userId}`, errorMessage);
    throw new Error(`Failed to reorder lists: ${errorMessage}`);
  }
}
