import { supabase } from '@/integrations/supabase/client';
import { secureLog } from '@/utils/secureLogging';
import { retryWithBackoff } from '@/utils/retryHelper';

export interface UploadResult {
  success: boolean;
  filePath?: string;
  sanitizedFilename?: string;
  error?: string;
}

export const uploadFileToContextBucket = async (
  file: File,
  userId: string
): Promise<UploadResult> => {
  try {
    secureLog.info(`Starting upload for file: ${file.name}, size: ${file.size}, type: ${file.type}`);

                                                                              
    const sanitizedFilename = file.name
      .replace(/[|<>:"/\\?*]/g, '_')  // Replace forbidden characters with underscore
      .replace(/\s+/g, '_')            // Replace spaces with underscore
      .replace(/_+/g, '_')             // Collapse multiple underscores
      .trim();

    const filePath = `${userId}/${sanitizedFilename}`;
    secureLog.info(`Sanitized filename: ${file.name} -> ${sanitizedFilename}`);

    const { data, error } = await supabase.storage
      .from('files')
      .upload(filePath, file, {
        upsert: true,
        contentType: file.type,
      });

    if (error) {
      secureLog.error(`Upload failed for ${file.name}`, error.message);
      return {
        success: false,
        error: `Failed to upload ${file.name}: ${error.message}`
      };
    }

    secureLog.info(`Successfully uploaded: ${file.name} to ${data.path}`);

    return {
      success: true,
      filePath: data.path,
      sanitizedFilename: sanitizedFilename
    };

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    secureLog.error(`Upload exception for ${file.name}`, errorMessage);

    return {
      success: false,
      error: `Upload failed for ${file.name}: ${errorMessage}`
    };
  }
};

export const uploadMultipleFiles = async (
  files: File[],
  userId: string
): Promise<UploadResult[]> => {
  const results: UploadResult[] = [];

  for (const file of files) {
    const result = await uploadFileToContextBucket(file, userId);
    results.push(result);
  }

  const successCount = results.filter(r => r.success).length;
  const failureCount = results.filter(r => !r.success).length;

  secureLog.info(`Batch upload complete: ${successCount} successful, ${failureCount} failed`);

  return results;
};

export interface ModifiedCall2Result {
  success: boolean;
  description?: string;
  fileType?: string;
  filename?: string;
  error?: string;
}

export const triggerModifiedCall2 = async (
  userId: string,
  contextFileId: string,
  filename: string,
  fileId: string,
  mimeType: string,
  model: string,
  personaName: string,
  existingJournalId?: string | null
): Promise<ModifiedCall2Result> => {
  try {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const modifiedCall2Url = `${supabaseUrl}/functions/v1/modified-call2`;

    secureLog.info(`Triggering Modified-Call2 for file: ${filename} with file_id: ${fileId}${existingJournalId ? ` (updating journal entry ${existingJournalId})` : ''}`);

    const result = await retryWithBackoff(
      async () => {
        const response = await fetch(modifiedCall2Url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`
          },
          body: JSON.stringify({
            userId,
            contextFileId,
            filename,
            fileId,
            mimeType,
            model,
            personaName,
            existingJournalId
          })
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({ error: 'Unknown error' }));
          throw new Error(errorData.error || `HTTP ${response.status}`);
        }

        return response.json();
      },
      { maxRetries: 2, timeoutMs: 60000 }
    );

    if (!result.success) {
      throw new Error(result.error || 'Unknown error');
    }

    const data = result.data;

    secureLog.info(`Modified-Call2 successful for file: ${filename} (${result.attempts} attempts)`);

    return {
      success: true,
      description: data.description,
      fileType: data.fileType,
      filename: data.filename
    };

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Modified-Call2 failed for ${filename}`, errorMessage);

    return {
      success: false,
      error: `Modified-Call2 failed: ${errorMessage}`
    };
  }
};

