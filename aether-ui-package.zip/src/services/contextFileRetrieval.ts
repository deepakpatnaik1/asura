import { supabase } from '@/integrations/supabase/client';
import { secureLog } from '@/utils/secureLogging';
import {
  ContextFile,
  ContextFileRetrievalResult,
  StorageFileMetadata
} from '@/types/contextFiles';

export const retrieveContextFiles = async (userId: string): Promise<ContextFileRetrievalResult> => {
  try {
    secureLog.info(`Starting context file retrieval for user: ${userId}`);

    const { data: contextFileRecords, error } = await supabase
      .from('context_files')
      .select('id, filename, file_type, anthropic_file_id, storage_path')
      .eq('user_id', userId)
      .in('status', ['active', 'processing'])
      .order('created_at', { ascending: false })
      .limit(100);

    if (error) {
      throw new Error(`Failed to query context files: ${error.message}`);
    }

    if (!contextFileRecords || contextFileRecords.length === 0) {
      secureLog.info(`No context files found for user: ${userId}`);
      return {
        success: true,
        files: []
      };
    }

    secureLog.info(`Found ${contextFileRecords.length} context files for user: ${userId}`);

    const contextFiles: ContextFile[] = [];

    for (const record of contextFileRecords) {
      try {
        if (!record.anthropic_file_id) {
          secureLog.error(`Context file ${record.filename} missing anthropic_file_id - skipping`);
          continue;
        }

        const contextFile: ContextFile = {
          filename: record.filename,
          type: record.file_type,
          file_id: record.anthropic_file_id
        };

        contextFiles.push(contextFile);
        secureLog.info(`Successfully loaded context file: ${record.filename} (${record.anthropic_file_id})`);

      } catch (fileError) {
        secureLog.error(
          `Failed to load context file ${record.filename}`,
          fileError instanceof Error ? fileError.message : String(fileError)
        );
      }
    }

    secureLog.info(`Successfully loaded ${contextFiles.length} out of ${contextFileRecords.length} context files`);

    return {
      success: true,
      files: contextFiles
    };

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    secureLog.error('Context file retrieval failed', errorMessage);

    return {
      success: false,
      error: errorMessage
    };
  }
};

export const formatContextFilesForLLM = (contextFiles: ContextFile[]) => {
  return contextFiles.map(file => {
    if (!file.file_id) {
      throw new Error(`Context file ${file.filename} missing file_id - cannot format for LLM`);
    }

    return {
      file_id: file.file_id,
      filename: file.filename,
      type: file.type
    };
  });
};