import { supabase } from '@/integrations/supabase/client';
import { getPersonaProfile } from '@/config/systemPrompts';

interface Message {
  id: string;
  text: string;
  sender: string;
  dbId?: string;
  timestamp?: string;
}

interface ContextFile {
  id: string;
  filename: string;
  anthropic_file_id: string | null;
  description_compressed: string | null;
}

interface TokenCountResult {
  success: boolean;
  tokenCount?: number;
  percentage?: number;
  error?: string;
}

export async function countTokensForMessage(
  currentMessage: string,
  conversationHistory: Message[],
  activeFiles: ContextFile[],
  selectedModel: string,
  selectedPersona: string,
  contextWindowLimit: number
): Promise<TokenCountResult> {
  try {
    
    const systemPrompt = getPersonaProfile(selectedPersona) || '';

    
    const messages: Array<{
      role: 'user' | 'assistant';
      content: string | Array<{ type: string; text?: string; source?: { type: string; file_id: string } }>;
    }> = [];

    
    for (const msg of conversationHistory) {
      if (msg.sender === 'Boss') {
        messages.push({
          role: 'user',
          content: msg.text  
        });
      } else if (msg.sender === 'Gunnar') {
        messages.push({
          role: 'assistant',
          content: msg.text  
        });
      }
    }

    if (currentMessage || activeFiles.length > 0) {
      const currentMessageContent: Array<{
        type: string;
        text?: string;
        source?: { type: string; file_id: string };
      }> = [];

      
      if (currentMessage) {
        currentMessageContent.push({
          type: 'text',
          text: currentMessage
        });
      }

      for (const file of activeFiles) {
        if (file.anthropic_file_id) {
          currentMessageContent.push({
            type: 'document',
            source: {
              type: 'file',
              file_id: file.anthropic_file_id
            }
          });
        }
      }

      if (currentMessageContent.length > 0) {
        messages.push({
          role: 'user',
          content: currentMessageContent
        });
      }
    }

    const { data, error } = await supabase.functions.invoke('count-tokens', {
      body: {
        model: selectedModel,
        system: systemPrompt,
        messages: messages
      }
    });

    if (error) {
      console.error('Token counting error:', error);
      return {
        success: false,
        error: error.message || 'Failed to count tokens'
      };
    }

    const tokenCount = data?.input_tokens || 0;
    const percentage = Math.round((tokenCount / contextWindowLimit) * 100);

    return {
      success: true,
      tokenCount,
      percentage
    };

  } catch (error) {
    console.error('Token counting service error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}
