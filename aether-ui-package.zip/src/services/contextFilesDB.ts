import { supabase } from '@/integrations/supabase/client';
import { secureLog } from '@/utils/secureLogging';
import type { ContextFileRecord, FileStatus } from '@/types/contextFiles';

export async function createContextFileRecord(
  userId: string,
  filename: string,
  fileType: 'image' | 'pdf' | 'text' | 'code' | 'spreadsheet' | 'other',
  storagePath: string,
  title?: string,
  anthropicFileId?: string,
  googleFileId?: string
): Promise<ContextFileRecord> {
  try {
    secureLog.info(`Creating context_files record for: ${filename}`);

    if (googleFileId) {
      const { data: existingFile, error: checkError } = await supabase
        .from('context_files')
        .select('*')
        .eq('user_id', userId)
        .eq('google_file_id', googleFileId)
        .maybeSingle();

      if (checkError) {
        secureLog.error(`Failed to check for existing Google file`, checkError.message);
        throw new Error(`Failed to check for existing file: ${checkError.message}`);
      }

      if (existingFile) {
        secureLog.info(`Found existing context_files record for Google file, reactivating: ${existingFile.id}`);

        const { data: updatedFile, error: updateError } = await supabase
          .from('context_files')
          .update({
            status: 'processing',
            anthropic_file_id: anthropicFileId || existingFile.anthropic_file_id,
            filename: filename,
            title: title || existingFile.title,
            updated_at: new Date().toISOString()
          })
          .eq('id', existingFile.id)
          .select()
          .single();

        if (updateError) {
          secureLog.error(`Failed to reactivate context_files record`, updateError.message);
          throw new Error(`Failed to reactivate context file: ${updateError.message}`);
        }

        secureLog.info(`Reactivated context file record: ${updatedFile.id}`);
        return updatedFile as ContextFileRecord;
      }
    }

    if (!googleFileId) {
      const existingFile = await findExistingContextFile(userId, filename, fileType);
      if (existingFile) {
        secureLog.info(`Found existing context_files record for ${filename}, reactivating: ${existingFile.id}`);

        if (existingFile.storage_path && existingFile.storage_path !== storagePath) {
          secureLog.info(`Deleting old storage file: ${existingFile.storage_path}`);
          const { error: deleteError } = await supabase.storage
            .from('files')
            .remove([existingFile.storage_path]);

          if (deleteError) {
            secureLog.error(`Failed to delete old storage file: ${existingFile.storage_path}`, deleteError.message);
          } else {
            secureLog.info(`Deleted old storage file: ${existingFile.storage_path}`);
          }
        }

        const { data: updatedFile, error: updateError } = await supabase
          .from('context_files')
          .update({
            status: 'processing',
            anthropic_file_id: anthropicFileId || null,
            storage_path: storagePath,
            title: title || null,
            google_file_id: googleFileId || null,
            updated_at: new Date().toISOString()
          })
          .eq('id', existingFile.id)
          .select()
          .single();

        if (updateError) {
          secureLog.error(`Failed to reactivate context_files record`, updateError.message);
          throw new Error(`Failed to reactivate context file: ${updateError.message}`);
        }

        secureLog.info(`Reactivated context file record: ${updatedFile.id}`);
        return updatedFile as ContextFileRecord;
      }
    }

    const { data, error } = await supabase
      .from('context_files')
      .insert({
        user_id: userId,
        filename: filename,
        file_type: fileType,
        status: 'processing',
        storage_path: storagePath,
        anthropic_file_id: anthropicFileId || null,
        title: title || null,
        description: null,
        journal_entry_id: null,
        google_file_id: googleFileId || null
      })
      .select()
      .single();

    if (error) {
      secureLog.error(`Failed to create context_files record for ${filename}`, error.message);
      throw new Error(`Failed to create context file record: ${error.message}`);
    }

    if (!data) {
      throw new Error('Context file record created but no data returned');
    }

    secureLog.info(`Context file record created: ${data.id}`);
    return data as ContextFileRecord;

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception creating context file record for ${filename}`, errorMessage);
    throw new Error(`Failed to create context file record: ${errorMessage}`);
  }
}

   
                                                                             
                                                       
  
                                            
                                          
                                                                                           
                                                                                                      
                                        
   
export async function findExistingContextFile(
  userId: string,
  filename: string,
  fileType: 'image' | 'pdf' | 'text' | 'code' | 'spreadsheet' | 'other'
): Promise<{ id: string; journal_entry_id: string | null; storage_path: string } | null> {
  const { data, error } = await supabase
    .from('context_files')
    .select('id, journal_entry_id, storage_path')
    .eq('user_id', userId)
    .eq('filename', filename)
    .eq('file_type', fileType)
    .neq('status', 'deleted')
    .maybeSingle();

  if (error) {
    secureLog.error('Error checking for existing file:', error);
    throw new Error(`Failed to check for existing file: ${error.message}`);
  }

  return data;
}

export async function updateFileStatus(
  fileId: string,
  status: FileStatus
): Promise<void> {
  try {
    secureLog.info(`Updating file status: ${fileId} -> ${status}`);

    const { error } = await supabase
      .from('context_files')
      .update({
        status: status,
        updated_at: new Date().toISOString()
      })
      .eq('id', fileId);

    if (error) {
      secureLog.error(`Failed to update file status for ${fileId}`, error.message);
      throw new Error(`Failed to update file status: ${error.message}`);
    }

    secureLog.info(`File status updated: ${fileId} -> ${status}`);

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception updating file status for ${fileId}`, errorMessage);
    throw new Error(`Failed to update file status: ${errorMessage}`);
  }
}

export async function updateFileDescription(
  fileId: string,
  description: string,
  journalEntryId: string
): Promise<void> {
  try {
    secureLog.info(`Updating file description for: ${fileId}`);

    const { error } = await supabase
      .from('context_files')
      .update({
        description: description,
        journal_entry_id: journalEntryId,
        status: 'active',
        updated_at: new Date().toISOString()
      })
      .eq('id', fileId);

    if (error) {
      secureLog.error(`Failed to update file description for ${fileId}`, error.message);
      throw new Error(`Failed to update file description: ${error.message}`);
    }

    secureLog.info(`File description updated: ${fileId}`);

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception updating file description for ${fileId}`, errorMessage);
    throw new Error(`Failed to update file description: ${errorMessage}`);
  }
}

export async function getActiveFiles(userId: string): Promise<ContextFileRecord[]> {
  try {
    secureLog.info(`Fetching active files for user: ${userId}`);

    const { data, error } = await supabase
      .from('context_files')
      .select('*')
      .eq('user_id', userId)
      .in('status', ['active', 'processing', 'failed'])
      .order('created_at', { ascending: false });

    if (error) {
      secureLog.error(`Failed to fetch active files for ${userId}`, error.message);
      throw new Error(`Failed to fetch active files: ${error.message}`);
    }

    secureLog.info(`Fetched ${data?.length || 0} active files for user ${userId}`);
    return (data || []) as ContextFileRecord[];

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception fetching active files for ${userId}`, errorMessage);
    throw new Error(`Failed to fetch active files: ${errorMessage}`);
  }
}

export async function getInactiveFiles(userId: string): Promise<ContextFileRecord[]> {
  try {
    secureLog.info(`Fetching inactive files for user: ${userId}`);

    const { data, error } = await supabase
      .from('context_files')
      .select('*')
      .eq('user_id', userId)
      .eq('status', 'inactive')
      .order('updated_at', { ascending: false });

    if (error) {
      secureLog.error(`Failed to fetch inactive files for ${userId}`, error.message);
      throw new Error(`Failed to fetch inactive files: ${error.message}`);
    }

    secureLog.info(`Fetched ${data?.length || 0} inactive files for user ${userId}`);
    return (data || []) as ContextFileRecord[];

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception fetching inactive files for ${userId}`, errorMessage);
    throw new Error(`Failed to fetch inactive files: ${errorMessage}`);
  }
}

export async function deleteContextFile(fileId: string): Promise<void> {
  try {
    secureLog.info(`Deleting context file: ${fileId}`);

    const { data: fileRecord, error: fetchError } = await supabase
      .from('context_files')
      .select('*')
      .eq('id', fileId)
      .single();

    if (fetchError || !fileRecord) {
      throw new Error(`Failed to fetch file record for deletion: ${fetchError?.message || 'Record not found'}`);
    }

    if (fileRecord.journal_entry_id) {
      secureLog.info(`Deleting associated journal entry: ${fileRecord.journal_entry_id}`);

      const { error: journalError } = await supabase
        .from('journal')
        .delete()
        .eq('id', fileRecord.journal_entry_id);

      if (journalError) {
        secureLog.error(`Failed to delete journal entry ${fileRecord.journal_entry_id}`, journalError.message);
      } else {
        secureLog.info(`Deleted journal entry: ${fileRecord.journal_entry_id}`);
      }
    }

    if (fileRecord.storage_path && fileRecord.storage_path.trim() !== '') {
      const { error: storageError } = await supabase.storage
        .from('files')
        .remove([fileRecord.storage_path]);

      if (storageError) {
        secureLog.error(`Failed to delete file from storage: ${fileRecord.storage_path}`, storageError.message);
      } else {
        secureLog.info(`Deleted file from storage: ${fileRecord.storage_path}`);
      }
    } else {
      secureLog.info(`Skipping storage deletion (no storage_path): ${fileId}`);
    }

    const { error: dbError } = await supabase
      .from('context_files')
      .delete()
      .eq('id', fileId);

    if (dbError) {
      secureLog.error(`Failed to delete context file record ${fileId}`, dbError.message);
      throw new Error(`Failed to delete context file from database: ${dbError.message}`);
    }

    secureLog.info(`Context file deleted: ${fileId}`);

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception deleting context file ${fileId}`, errorMessage);
    throw new Error(`Failed to delete context file: ${errorMessage}`);
  }
}

export async function updateAnthropicFileId(
  contextFileId: string,
  anthropicFileId: string
): Promise<void> {
  try {
    secureLog.info(`Updating anthropic_file_id for context file: ${contextFileId}`);

    const { error } = await supabase
      .from('context_files')
      .update({
        anthropic_file_id: anthropicFileId,
        updated_at: new Date().toISOString()
      })
      .eq('id', contextFileId);

    if (error) {
      secureLog.error(
        `Failed to update anthropic_file_id for ${contextFileId}`,
        error.message
      );
      throw new Error(`Failed to update anthropic_file_id: ${error.message}`);
    }

    secureLog.info(`Anthropic file_id updated: ${contextFileId} -> ${anthropicFileId}`);

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(
      `Exception updating anthropic_file_id for ${contextFileId}`,
      errorMessage
    );
    throw new Error(`Failed to update anthropic_file_id: ${errorMessage}`);
  }
}

export async function findExistingJournalEntry(
  userId: string,
  googleFileId: string
): Promise<string | null> {
  try {
    secureLog.info(`Checking for existing journal entry for Google file: ${googleFileId}`);

    const { data, error } = await supabase
      .from('context_files')
      .select('journal_entry_id')
      .eq('user_id', userId)
      .eq('google_file_id', googleFileId)
      .not('journal_entry_id', 'is', null)
      .order('updated_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) {
      secureLog.error(`Failed to check for existing journal entry`, error.message);
      throw new Error(`Failed to check for existing journal entry: ${error.message}`);
    }

    if (data?.journal_entry_id) {
      secureLog.info(`Found existing journal entry: ${data.journal_entry_id}`);
      return data.journal_entry_id;
    }

    secureLog.info(`No existing journal entry found for Google file: ${googleFileId}`);
    return null;

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    secureLog.error(`Exception checking for existing journal entry`, errorMessage);
    throw new Error(`Failed to check for existing journal entry: ${errorMessage}`);
  }
}
