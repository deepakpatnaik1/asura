export interface FileAttachment {
  type: 'file';
  file: File;
  id: string;
}

export interface URLAttachment {
  type: 'url';
  url: string;
  title?: string;
  id: string;
}

export type Attachment = FileAttachment | URLAttachment;

export interface AttachmentContent {
  content?: string | MultimodalContent[];
  filename: string;
  type: string;
  file_id?: string;
}

export interface MultimodalContent {
  type: 'text' | 'image_url' | 'file' | 'input_file';
  text?: string;
  image_url?: {
    url: string;
  };
  file?: {
    data: string;
    mime_type: string;
    filename: string;
  };
  file_id?: string;
  file_type?: string;
}

export interface MessageContent {
  type: 'text' | 'image_url' | 'input_file';
  text?: string;
  image_url?: {
    url: string;
  };
  file_id?: string;
}

export interface LLMRequest {
  message: string;
  model: string;
  attachment?: AttachmentContent;
  authToken: string;
  apiKey: string;
  personaName?: string;
  timezoneOffset?: string;  
}

export interface LLMResponse {
  content: string;
  isComplete: boolean;
  error?: string;
}

export interface LLMStreamChunk {
  content?: string;
  error?: string;
  done?: boolean;
}

export interface ModelConfig {
  model: string;
  maxCompletionTokens: number;
  temperature?: number;
  stream: boolean;
}

export interface LLMServiceConfig {
  apiUrl: string;
  models: Record<string, Omit<ModelConfig, 'model'>>;
}

export interface StreamingOptions {
  onChunk?: (chunk: LLMStreamChunk) => void;
  onError?: (error: Error) => void;
  onComplete?: () => void;
}

export interface ILLMService {
  sendMessage(request: LLMRequest): AsyncIterator<LLMResponse>;
  supportsStreaming(model: string): boolean;
  getModelConfig(model: string): ModelConfig;
}

export enum LLMErrorType {
  AUTHENTICATION = 'authentication',
  NETWORK = 'network',
  MODEL_NOT_SUPPORTED = 'model_not_supported',
  STREAMING = 'streaming',
  PARSING = 'parsing',
  UNKNOWN = 'unknown'
}

export class LLMError extends Error {
  constructor(
    public readonly type: LLMErrorType,
    message: string,
    public readonly cause?: Error
  ) {
    super(message);
    this.name = 'LLMError';
  }
}

export interface ResponseHandler {
  canHandle(contentType: string): boolean;
  handle(response: Response): AsyncIterator<LLMResponse>;
}
