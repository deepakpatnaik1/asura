
import { ModelConfig, LLMServiceConfig, LLMError, LLMErrorType } from './types';

export class LLMConfig {
  private static readonly MODEL_CONFIGS: Record<string, Omit<ModelConfig, 'model'>> = {
    'claude-sonnet-4-5': {
      maxCompletionTokens: 8096,
      stream: true
    },
    'claude-haiku-4-5': {
      maxCompletionTokens: 8096,
      stream: true
    }
  };

  static getModelConfig(requestedModel: string): ModelConfig {
    const config = this.MODEL_CONFIGS[requestedModel];

    if (!config) {
      throw new LLMError(
        LLMErrorType.MODEL_NOT_SUPPORTED,
        `Unsupported model: ${requestedModel}. Supported models: ${Object.keys(this.MODEL_CONFIGS).join(', ')}`
      );
    }

    return {
      model: requestedModel,
      ...config
    };
  }

  static supportsStreaming(model: string): boolean {
    return this.MODEL_CONFIGS[model]?.stream ?? false;
  }

  static getSupportedModels(): string[] {
    return Object.keys(this.MODEL_CONFIGS);
  }

  static isClaudeModel(model: string): boolean {
    return model.startsWith('claude-');
  }

  static createServiceConfig(apiUrl: string): LLMServiceConfig {
    return {
      apiUrl,
      models: this.MODEL_CONFIGS
    };
  }

  static validateModel(model: string): void {
    if (!model || typeof model !== 'string') {
      throw new LLMError(
        LLMErrorType.MODEL_NOT_SUPPORTED,
        'Model identifier must be a non-empty string'
      );
    }

    if (!this.MODEL_CONFIGS[model]) {
      throw new LLMError(
        LLMErrorType.MODEL_NOT_SUPPORTED,
        `Model "${model}" is not supported`
      );
    }
  }

  static getAPIParameters(model: string): Record<string, string | number | boolean> {
    const config = this.getModelConfig(model);

    const params: Record<string, string | number | boolean> = {
      model: config.model,
      max_completion_tokens: config.maxCompletionTokens,
      stream: config.stream
    };

    if (config.temperature !== undefined) {
      params.temperature = config.temperature;
    }

    return params;
  }
}