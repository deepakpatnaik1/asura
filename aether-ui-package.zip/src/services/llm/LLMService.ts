
import {
  ILLMService,
  LLMRequest,
  LLMResponse,
  ModelConfig,
  LLMError,
  LLMErrorType,
  AttachmentContent,
  MultimodalContent,
  MessageContent
} from './types';
import { LLMConfig } from './LLMConfig';
import { StreamingUtils } from './StreamingHandler';
import { loadPersonaProfile } from '../personaService';

export class LLMService implements ILLMService {
  async* sendMessage(request: LLMRequest): AsyncIterator<LLMResponse> {
    this.validateRequest(request);

    try {
      const modelConfig = this.getModelConfig(request.model);

      const requestBody = await this.buildRequestBody(request, modelConfig);

      const response = await this.makeRequest(request, requestBody);

      yield* StreamingUtils.createStreamIterator(response);

    } catch (error) {
      if (error instanceof LLMError) {
        throw error;
      }

      throw new LLMError(
        LLMErrorType.UNKNOWN,
        'Unexpected error during LLM request',
        error instanceof Error ? error : new Error(String(error))
      );
    }
  }

  supportsStreaming(model: string): boolean {
    return LLMConfig.supportsStreaming(model);
  }

  getModelConfig(model: string): ModelConfig {
    return LLMConfig.getModelConfig(model);
  }

  private validateRequest(request: LLMRequest): void {
    if (!request.message || typeof request.message !== 'string') {
      throw new LLMError(
        LLMErrorType.UNKNOWN,
        'Message must be a non-empty string'
      );
    }

    if (!request.authToken || typeof request.authToken !== 'string') {
      throw new LLMError(
        LLMErrorType.AUTHENTICATION,
        'Authentication token is required'
      );
    }

    if (!request.apiKey || typeof request.apiKey !== 'string') {
      throw new LLMError(
        LLMErrorType.AUTHENTICATION,
        'API key is required'
      );
    }

    LLMConfig.validateModel(request.model);
  }

  private async buildRequestBody(request: LLMRequest, modelConfig: ModelConfig): Promise<Record<string, string | object>> {
    const messageContent = this.buildMessageContent(request);

    const messages: Array<{role: string; content: string | MessageContent[]}> = [];

    if (request.personaName) {
      const personaProfile = loadPersonaProfile(request.personaName);
      messages.push({
        role: 'developer',
        content: personaProfile
      });
    }

    messages.push({
      role: 'user',
      content: messageContent
    });

    const body: Record<string, string | object> = {
      messages,
      model: request.model,
      personaName: request.personaName,
      timezoneOffset: request.timezoneOffset
    };

    return body;
  }

  private buildMessageContent(request: LLMRequest): MessageContent[] {
    const content: MessageContent[] = [
      {
        type: 'text',
        text: request.message
      }
    ];

    if (request.attachment) {
      const attachmentContent = this.transformAttachmentContent(request.attachment);
      if (attachmentContent.length > 0) {
        content.push(...attachmentContent);
      }
    }

    return content;
  }

  private transformAttachmentContent(attachment: AttachmentContent): MessageContent[] {
    const content: MessageContent[] = [];

    if (Array.isArray(attachment.content)) {
      attachment.content.forEach((item: MultimodalContent) => {
        if (item.type === 'text') {
          return;
        } else if (item.type === 'input_file' && item.file_id) {
          content.push({
            type: 'input_file',
            file_id: item.file_id
          });
        }
      });
    } else if (attachment.file_id) {
      content.push({
        type: 'input_file',
        file_id: attachment.file_id
      });
    }

    return content;
  }

  private async makeRequest(request: LLMRequest, requestBody: Record<string, string | object>): Promise<Response> {
    const apiUrl = this.buildApiUrl();

    console.log('🚀 LLM API call to chat-ai at:', new Date().toISOString(), '| Message:', request.message.substring(0, 50) + '...');

    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${request.authToken}`,
          'apikey': request.apiKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        throw new LLMError(
          LLMErrorType.NETWORK,
          `HTTP error! status: ${response.status}`
        );
      }

      return response;
    } catch (error) {
      if (error instanceof LLMError) {
        throw error;
      }

      throw new LLMError(
        LLMErrorType.NETWORK,
        'Failed to make request to LLM API',
        error instanceof Error ? error : new Error(String(error))
      );
    }
  }

  private buildApiUrl(): string {
    if (typeof window !== 'undefined' && typeof import.meta?.env !== 'undefined') {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      if (supabaseUrl) {
        return `${supabaseUrl}/functions/v1/chat-ai`;
      }
    }

    throw new LLMError(
      LLMErrorType.NETWORK,
      'API URL not configured - VITE_SUPABASE_URL environment variable required'
    );
  }
}

export class LLMServiceFactory {
  static create(): ILLMService {
    return new LLMService();
  }

  static createWithConfig(config?: Record<string, unknown>): ILLMService {
    return new LLMService();
  }
}

export class LLMUtils {
  static async sendTextMessage(
    message: string,
    model: string,
    authToken: string,
    apiKey: string
  ): Promise<string> {
    const service = LLMServiceFactory.create();
    const request: LLMRequest = {
      message,
      model,
      authToken,
      apiKey
    };

    return await StreamingUtils.collectAll(service.sendMessage(request));
  }

  static async sendMessageWithAttachment(
    message: string,
    model: string,
    attachment: { content: string; filename: string; type: string },
    authToken: string,
    apiKey: string
  ): Promise<string> {
    const service = LLMServiceFactory.create();
    const request: LLMRequest = {
      message,
      model,
      attachment,
      authToken,
      apiKey
    };

    return await StreamingUtils.collectAll(service.sendMessage(request));
  }
}