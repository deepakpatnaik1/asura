
import { LLMResponse, LLMStreamChunk, ResponseHandler, LLMError, LLMErrorType } from './types';
import { replaceEmDashes } from '@/utils/textTransforms';

export class SSEResponseHandler implements ResponseHandler {
  canHandle(contentType: string): boolean {
    return contentType?.includes('text/event-stream') ?? false;
  }

  async* handle(response: Response): AsyncIterator<LLMResponse> {
    const reader = response.body?.getReader();
    if (!reader) {
      throw new LLMError(
        LLMErrorType.STREAMING,
        'Unable to read streaming response - no reader available'
      );
    }

    const decoder = new TextDecoder();
    let accumulatedResponse = '';

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6).trim();

            if (data === '[DONE]') {
              if (accumulatedResponse.trim()) {
                yield {
                  content: accumulatedResponse,
                  isComplete: true
                };
              }
              return;
            }

            try {
              const parsed: LLMStreamChunk = JSON.parse(data);

              if (parsed.error) {
                throw new LLMError(
                  LLMErrorType.STREAMING,
                  parsed.error
                );
              }

              if (parsed.content) {
                accumulatedResponse += replaceEmDashes(parsed.content);

                yield {
                  content: accumulatedResponse,
                  isComplete: false
                };
              }
            } catch (parseError) {
              console.warn('Failed to parse SSE data:', data);
            }
          }
        }
      }

      if (accumulatedResponse.trim()) {
        yield {
          content: accumulatedResponse,
          isComplete: true
        };
      } else {
        throw new LLMError(
          LLMErrorType.STREAMING,
          'No content received from streaming response'
        );
      }
    } finally {
      reader.releaseLock();
    }
  }
}

export class JSONResponseHandler implements ResponseHandler {
  canHandle(contentType: string): boolean {
  }

  async* handle(response: Response): AsyncIterator<LLMResponse> {
    try {
      const responseData = await response.json();

      if (responseData.error) {
        throw new LLMError(
          LLMErrorType.NETWORK,
          responseData.error
        );
      }

      const content = responseData.response;
      if (!content) {
        throw new LLMError(
          LLMErrorType.PARSING,
          'No response field in JSON data'
        );
      }

      yield {
        content: replaceEmDashes(content),
        isComplete: true
      };
    } catch (error) {
      if (error instanceof LLMError) {
        throw error;
      }

      throw new LLMError(
        LLMErrorType.PARSING,
        'Failed to parse JSON response',
        error instanceof Error ? error : new Error(String(error))
      );
    }
  }
}

export class ResponseHandlerFactory {
  private static handlers: ResponseHandler[] = [
    new SSEResponseHandler(),
    new JSONResponseHandler()
  ];

  static getHandler(contentType: string): ResponseHandler {
    for (const handler of this.handlers) {
      if (handler.canHandle(contentType)) {
        return handler;
      }
    }

    return new JSONResponseHandler();
  }
}

export class StreamingUtils {
  static async* createStreamIterator(response: Response): AsyncIterator<LLMResponse> {
    const contentType = response.headers.get('content-type') || '';
    const handler = ResponseHandlerFactory.getHandler(contentType);

    yield* handler.handle(response);
  }

  static async collectAll(iterator: AsyncIterator<LLMResponse>): Promise<string> {
    let finalContent = '';

    for await (const response of iterator) {
      finalContent = response.content;
      if (response.isComplete) {
        break;
      }
    }

    return finalContent;
  }

  static async* withErrorHandling(
    iterator: AsyncIterator<LLMResponse>,
    onError?: (error: Error) => void
  ): AsyncIterator<LLMResponse> {
    try {
      yield* iterator;
    } catch (error) {
      const llmError = error instanceof LLMError
        ? error
        : new LLMError(
            LLMErrorType.UNKNOWN,
            'Unexpected error during streaming',
            error instanceof Error ? error : new Error(String(error))
          );

      if (onError) {
        onError(llmError);
      }

      throw llmError;
    }
  }
}