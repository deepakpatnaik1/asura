
export { LLMService, LLMServiceFactory, LLMUtils } from './LLMService';

export { LLMConfig } from './LLMConfig';

export {
  SSEResponseHandler,
  JSONResponseHandler,
  ResponseHandlerFactory,
  StreamingUtils
} from './StreamingHandler';

export type {
  ILLMService,
  LLMRequest,
  LLMResponse,
  LLMStreamChunk,

  ModelConfig,
  LLMServiceConfig,

  FileAttachment,
  URLAttachment,
  Attachment,
  AttachmentContent,

  StreamingOptions,
  ResponseHandler
} from './types';

export { LLMError, LLMErrorType } from './types';

export const SUPPORTED_MODELS = {
  CLAUDE_SONNET_4_5: 'claude-sonnet-4-5'
} as const;

export type SupportedModel = typeof SUPPORTED_MODELS[keyof typeof SUPPORTED_MODELS];

export const LLMQuickStart = {
  createTextRequest: (
    message: string,
    model: SupportedModel,
    authToken: string,
    apiKey: string
  ): LLMRequest => ({
    message,
    model,
    authToken,
    apiKey
  }),

  createFileRequest: (
    message: string,
    model: SupportedModel,
    attachment: AttachmentContent,
    authToken: string,
    apiKey: string
  ): LLMRequest => ({
    message,
    model,
    attachment,
    authToken,
    apiKey
  }),

  getDefaultModel: (): SupportedModel => SUPPORTED_MODELS.CLAUDE_SONNET_4_5,

  supportsStreaming: (model: SupportedModel): boolean => {
    return LLMConfig.supportsStreaming(model);
  }
};