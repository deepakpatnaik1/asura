import { useState, useEffect } from "react";
import ChatInterface from "@/components/ChatInterface";
import Whiteboard from "@/components/Whiteboard";
import ColorSwatches from "@/components/ColorSwatches";

type PaneType = 'blue' | 'orange' | 'brown' | 'yellow' | 'emerald' | 'red';

const Index = () => {
  const [activePane, setActivePane] = useState<PaneType | null>(() => {
    
    try {
      const saved = localStorage.getItem('activePane');
      if (!saved) return 'blue';
      const parsed = JSON.parse(saved);
      return parsed as PaneType | null;
    } catch {
      return 'blue';
    }
  });

  
  useEffect(() => {
    localStorage.setItem('activePane', JSON.stringify(activePane));
  }, [activePane]);

  const togglePane = (pane: PaneType) => {
    setActivePane(activePane === pane ? null : pane);
  };

  const chatWidth = activePane ? 'w-1/2' : 'w-full';
  const whiteboardWidth = activePane ? 'w-1/2' : 'w-0';

  return (
    <div className="flex h-screen w-screen overflow-hidden">
      {}
      <div className={`${chatWidth} h-full overflow-hidden transition-all duration-200`}>
        <ChatInterface />
      </div>

      {}
      <div className={`${whiteboardWidth} h-full overflow-hidden transition-all duration-200`}>
        <Whiteboard activePane={activePane} togglePane={togglePane} />
      </div>

      {}
      <ColorSwatches activePane={activePane} togglePane={togglePane} />
    </div>
  );
};

export default Index;
